# observe: Technical Design

This document explains how observe works under the hood, from the initial fork to the final report. It is organized as a high-level architecture overview followed by a component-by-component deep dive.

For motivation, goals, and behavioral semantics, see [CONTEXT.md](CONTEXT.md).

---

## 1. High-Level Architecture

observe is structured as a classic ptrace tracer: a parent process (the tracer) observes a child process tree (the tracees) via the Linux ptrace API. The key performance enabler is a **seccomp-BPF filter** installed in the child before exec, which limits ptrace stops to only the ~45 file-related syscalls that observe cares about.

```
┌─────────────────────────────────────────────────────────┐
│  observe (tracer process)                               │
│                                                         │
│  main.rs       parse CLI, fork, print report            │
│  tracer.rs     waitpid loop, event dispatch             │
│  syscall.rs    classify syscalls, entry/exit handlers   │
│  proc_helpers  path resolution, fd cache, hashing       │
│  snapshot.rs   copy-before-write, manifest, revert      │
│  state.rs      all mutable tracer state                 │
└──────────────────────────┬──────────────────────────────┘
                           │  ptrace
┌──────────────────────────▼──────────────────────────────┐
│  traced process tree (tracees)                          │
│                                                         │
│  child.rs      (initial child only, before exec)        │
│  seccomp.rs    BPF filter: TRACE file syscalls, ALLOW   │
│                rest — installed before exec              │
└─────────────────────────────────────────────────────────┘
```

Data flows through observe in four stages:

1. **Startup:** fork, seccomp install, exec, set ptrace options.
2. **Event loop:** waitpid delivers events; each is dispatched to a handler that updates in-memory state.
3. **Shutdown:** all processes exit (or SIGTERM received); manifest is written if `--snapshot-dir` was given.
4. **Report:** filtered read/write sets and pre-hashes are formatted and printed.

---

## 2. Startup and Process Model

### 2.1 main.rs — fork

After parsing CLI arguments, `main()` calls `nix::unistd::fork()`. The parent becomes the tracer; the child calls `child::run_child()` and never returns.

```rust
// main.rs
match unsafe { nix::unistd::fork()? } {
    ForkResult::Child => { child::run_child(&c_args); }
    ForkResult::Parent { child } => { tracer::run_tracer(child, ...)?; }
}
```

### 2.2 child.rs — traceme, seccomp, exec

The child performs three actions in strict order before calling exec:

```rust
// child.rs
ptrace::traceme()?;                   // (1) allow parent to trace us
seccomp::install_filter()?;          // (2) install the syscall filter
raise(Signal::SIGSTOP)?;             // (3) pause so parent can set options
execvp(&argv[0], argv);              // (4) exec the user's command
```

The `SIGSTOP` is crucial: it gives the parent a chance to call `ptrace::setoptions()` before the child exec's and starts generating seccomp stops. Without this pause, seccomp events could arrive before ptrace options are configured, causing them to be mishandled.

Error handling for exec failures follows bash conventions: exit 127 for ENOENT (command not found), 126 for EACCES (permission denied).

### 2.3 tracer.rs — initial setup

The parent waits for the child's SIGSTOP via `wait_initial_stop()`, then sets ptrace options:

```rust
// tracer.rs
let opts = ptrace::Options::PTRACE_O_TRACESYSGOOD  // PtraceSyscall stops carry 0x80 flag
    | PTRACE_O_TRACEEXEC                            // get PTRACE_EVENT_EXEC
    | PTRACE_O_TRACEFORK                            // get PTRACE_EVENT_FORK
    | PTRACE_O_TRACEVFORK                           // get PTRACE_EVENT_VFORK
    | PTRACE_O_TRACECLONE                           // get PTRACE_EVENT_CLONE
    | PTRACE_O_TRACESECCOMP                         // get PTRACE_EVENT_SECCOMP
    | PTRACE_O_EXITKILL;                            // kill tracees when tracer exits
```

`PTRACE_O_EXITKILL` is a safety net: if observe is killed (SIGKILL or crash), all tracees are killed automatically rather than running untethered.

---

## 3. Seccomp BPF Filter (`seccomp.rs`)

### 3.1 What it does

The seccomp filter is a small BPF program that the kernel evaluates on every syscall before it executes. It returns one of two verdicts:

- `SECCOMP_RET_TRACE`: generate a `PTRACE_EVENT_SECCOMP` stop in the tracer before the syscall runs.
- `SECCOMP_RET_ALLOW`: let the syscall proceed without any tracer involvement.

### 3.2 BPF program structure

The filter is a linear program with this shape:

```
[0]  LD   seccomp_data.nr          // load syscall number into accumulator
[1]  JEQ  syscall_0, jt=N, jf=0   // if match: jump to TRACE; else: fall through
[2]  JEQ  syscall_1, jt=N-1, jf=0
...
[N]  JEQ  syscall_N-1, jt=1, jf=0
[N+1] RET  SECCOMP_RET_ALLOW       // default: allow
[N+2] RET  SECCOMP_RET_TRACE       // matched: trace
```

Each `JEQ` instruction checks one syscall number. On a match, `jt` is the jump offset to land on the `RET TRACE` instruction at the end; on a non-match, `jf=0` falls through to the next comparison. This structure avoids any backward jumps and is efficiently evaluated by the kernel's BPF JIT.

### 3.3 Traced syscalls

The `TRACED_SYSCALLS` array in `seccomp.rs` contains 45 syscall numbers grouped by purpose:

| Group | Syscalls |
|-------|---------|
| File open | `open`, `openat`, `openat2`, `creat` |
| Path truncation | `truncate` |
| Path-based metadata | `newfstatat`, `statx`, `access`, `faccessat`, `faccessat2`, `readlink`, `readlinkat` |
| Directory and link operations | `rename`, `renameat`, `renameat2`, `link`, `linkat`, `symlink`, `symlinkat`, `unlink`, `unlinkat`, `rmdir`, `mkdir`, `mkdirat` |
| Permissions and timestamps | `chmod`, `fchmod`, `fchmodat`, `chown`, `fchown`, `lchown`, `fchownat`, `utimensat` |
| Cross-fd transfers | `sendfile`, `copy_file_range` |
| fd management | `close`, `close_range`, `dup`, `dup2`, `dup3` |

### 3.4 Why read/write/mmap/fstat are excluded

These high-volume syscalls were in an earlier version of the filter and caused ~1.50× overhead from ptrace round-trips on pipe I/O. They are correctly handled without interception:

- **read/readv/pread/getdents:** tracked at `open()` exit — a file can only be read if opened with read access.
- **write/writev/pwrite:** tracked at `open()` exit — the snapshot and hash are captured before the tracee resumes from open, before any `write()` can occur.
- **ftruncate/fallocate:** the fd was already opened with write intent; snapshot taken at open time.
- **fstat/fstatfs:** the file was already recorded at open time.
- **mmap:** anonymous mmaps (fd=-1) are the vast majority and irrelevant. File-backed mmaps require a prior open, which is intercepted.

---

## 4. Event Loop (`tracer.rs`)

### 4.1 Main loop structure

The tracer runs a `waitpid(None, WNOHANG=false, __WALL)` loop. `None` means wait for any traced process; `__WALL` includes threads. Each iteration delivers one of several `WaitStatus` variants:

```rust
// tracer.rs
loop {
    let status = match waitpid(None, Some(WaitPidFlag::__WALL)) {
        Ok(s) => s,
        Err(Errno::EINTR) => { /* SIGTERM check */ break or continue; }
        Err(e) => return Err(e),
    };
    match status {
        WaitStatus::PtraceEvent(pid, _, evt) => { /* fork/exec/seccomp */ }
        WaitStatus::PtraceSyscall(pid)       => { /* syscall exit stop */ }
        WaitStatus::Stopped(pid, sig)        => { /* signal delivery */ }
        WaitStatus::Exited(pid, code)        => { /* process exit */ }
        WaitStatus::Signaled(pid, sig, _)    => { /* killed by signal */ }
        _ => {}
    }
}
```

### 4.2 PtraceEvent dispatch

`PTRACE_EVENT_FORK` / `VFORK` / `CLONE`: A new child was created. `ptrace::getevent()` returns the child's pid. The child is added to `state.live`, ptrace options are set on it, and both parent and child are resumed.

A race exists: the child may deliver its own initial SIGSTOP before the `PTRACE_EVENT_FORK` arrives in the parent. The `WaitStatus::Stopped` handler covers this by calling `ptrace::setoptions()` on first-seen pids.

`PTRACE_EVENT_EXEC`: The tracee exec'd a new program. Two actions happen:
1. `state.fd_cache.remove_pid(pid)` — clears all stale fd→path cache entries. O_CLOEXEC file descriptors are closed by the kernel on exec; their fd numbers can be reused by the new program. Without this flush, `fd_cache.resolve()` would return the pre-exec path for what is actually a different file.
2. `/proc/<pid>/exe` is read and the path is added to `read_paths` (the exec'd binary is a read).

`PTRACE_EVENT_SECCOMP`: A file-related syscall hit the filter. Registers are read with `ptrace::getregs()`, a `SysEnter` struct is built, and `handle_entry()` is called. If the handler returns `true` (exit stop needed), `ptrace::syscall()` is called and the pid is added to `state.awaiting_exit`; otherwise `ptrace::cont()` resumes without an exit stop.

### 4.3 PtraceSyscall (exit stop)

This arrives only for pids in `state.awaiting_exit`. The registered `SysEnter` from `state.last_enter` is retrieved and `handle_exit()` is called with the syscall's return value (`regs.rax as i64`). The pid is removed from `awaiting_exit`, and `ptrace::cont()` resumes the tracee.

### 4.4 Signal delivery stops

Signals received by a tracee cause a `WaitStatus::Stopped` event. `SIGSTOP` is swallowed (not re-injected) — it's either the initial stop or a stop from a newly forked child. All other signals are passed through to the tracee via `ptrace::cont(pid, Some(sig))`.

If a pid is in `awaiting_exit` when a signal arrives, `ptrace::syscall()` is used instead of `ptrace::cont()` so the syscall-exit stop is not lost.

### 4.5 Process exit

`WaitStatus::Exited` and `WaitStatus::Signaled` trigger `state.remove_pid(pid)`, which cleans up `live`, `awaiting_exit`, `last_enter`, and `fd_cache` entries for that pid. When `state.live` becomes empty, the loop exits.

If the exiting pid is the initial child (the one that exec'd the user command), its exit code is recorded.

### 4.6 SIGTERM handling

A POSIX signal handler sets `SIGTERM_RECEIVED: AtomicBool`. The `sigaction` struct deliberately does **not** set `SA_RESTART`, so the blocking `waitpid` call returns `EINTR`. The loop then checks the flag and breaks, allowing a clean shutdown and manifest write.

```rust
// tracer.rs
static SIGTERM_RECEIVED: AtomicBool = AtomicBool::new(false);

unsafe extern "C" fn handle_sigterm(_: libc::c_int) {
    SIGTERM_RECEIVED.store(true, Ordering::Relaxed);
}
```

---

## 5. Syscall Classification and Handling (`syscall.rs`)

### 5.1 SysEnter

Every intercepted syscall is captured in a `SysEnter` struct at the seccomp stop:

```rust
// syscall.rs
pub struct SysEnter {
    pub nr: i64,        // orig_rax: the syscall number
    pub args: [u64; 6], // rdi, rsi, rdx, r10, r8, r9
}
```

The struct is cloned into `state.last_enter[pid]` so it's available at the exit stop, where the return value is in `rax` but the original arguments are no longer guaranteed to be in registers.

### 5.2 SyscallKind classification

`classify(nr: i64) -> SyscallKind` maps each syscall number to a high-level category:

| `SyscallKind` | Syscalls | Entry only? |
|--------------|---------|-------------|
| `Open` | open, openat, openat2, creat | No — exit needed (fd, return value) |
| `PathMeta` | newfstatat, statx, access, faccessat, faccessat2, readlink, readlinkat | Yes |
| `PathTrunc` | truncate | Yes |
| `Rename` | rename, renameat, renameat2 | No — exit confirms success |
| `Link` | link, linkat, symlink, symlinkat | No |
| `Unlink` | unlink, unlinkat, rmdir | No |
| `Mkdir` | mkdir, mkdirat | No |
| `Chmod` | chmod, fchmod, fchmodat, chown, fchown, lchown, fchownat, utimensat | Yes |
| `CrossFd` | sendfile, copy_file_range | Yes |
| `Close` | close, close_range | Conditional (see below) |
| `Dup` | dup, dup2, dup3 | No — exit gives new fd |

### 5.3 handle_entry — what happens at syscall entry

**PathMeta** (`handle_path_meta`): Resolves the path via `resolve_tracee_path()` to a `/proc/<pid>/root/...` host path. Calls `is_readable_node()` (a stat-based check) before `resolve_to_real_path()` (which opens the file). This guard is critical: opening a named FIFO with `O_RDONLY` blocks indefinitely because the tracee is stopped by ptrace and cannot act as a writer. `is_readable_node` returns false for FIFOs, sockets, and devices, preventing the deadlock. `readlink`/`readlinkat` use `best_effort_resolve` + `symlink_metadata` to record the symlink itself, not its target.

**PathTrunc** (`handle_path_trunc`): Hashes and snapshots the file *before* `truncate()` zeroes it. After the truncation succeeds, the file is empty — the pre-truncation content can only be captured at entry.

**CrossFd** (`handle_cross_fd`): Resolves both fds from the fd cache. Records the read fd in `read_paths` and hashes/snapshots/records the write fd in `write_paths`.

**Chmod** (`handle_chmod`): Handles the full family of permission/ownership/timestamp syscalls. Special cases:
- `fchmod`/`fchown`: fd-based; look up from fd cache.
- `lchown`: operates on the symlink itself — uses `best_effort_resolve` + `symlink_metadata`.
- `utimensat` with `AT_EMPTY_PATH`: fd-based, similar to fchmod.
- `utimensat`/`fchownat` with `AT_SYMLINK_NOFOLLOW`: operates on the symlink itself.
- Default: follows symlinks via `resolve_to_real_path`.

All variants call `snapshot::maybe_snapshot_metadata()` to capture current mode/uid/gid/mtime before the change.

**Open** (`handle_open_entry`): Handles the cases that must be resolved at entry, before the kernel acts:
- `O_TRUNC` on an existing file: hash and snapshot the content now; after the open returns, the file is empty.
- `O_CREAT` on a new path: record `Nonexistent` in `pre_hashes` (and call `snapshot_nonexistent`) so the exit handler doesn't try to hash the freshly created empty file. The path key is produced by `resolve_new_file_real_path()` (canonicalizes the parent directory) and then `follow_dangling_symlink()` if the resolved path is itself a dangling symlink.

**Rename/Unlink** (`handle_rename_entry`, `handle_unlink_entry`): Snapshot the targets at entry. After a successful rename or unlink, the original content is gone. The handlers use `best_effort_resolve` to locate the targets, then call the appropriate snapshot function (`maybe_snapshot_host_path`, `snapshot_existing_dir`, `snapshot_existing_symlink`).

**Close optimization:** For `SYS_close`, `handle_entry` returns `state.fd_cache.is_tracked(pid, fd)` — the exit stop is only requested when the fd has a cached path. If it's not tracked (a pipe, socket, or epoll fd), eviction would be a no-op and the round-trip is skipped. `close_range` always needs the exit stop since it operates on a range.

### 5.4 handle_exit — what happens at syscall exit

**Open** (`handle_open_exit`): Called only on success (`ret >= 0`). The new fd is resolved via `fd_cache.resolve(pid, fd)`, which populates the cache by reading `/proc/<pid>/fd/<fd>`. The path is classified:
- If `flags_imply_write()` is true (O_WRONLY, O_RDWR, O_TRUNC, or O_CREAT): the file is a write. If hash is enabled and the path isn't in `pre_hashes` yet, hash it now. Then call `snapshot::maybe_snapshot_fd()`. Add to `write_paths`. Additionally, if O_RDWR, add to `read_paths` (files opened O_RDWR are both read and written, but `read()` is not intercepted so this must be recorded at open time).
- Otherwise: add to `read_paths`.

**Dup** (`handle_dup_exit`): On success, copies the fd cache entry from `old_fd` to `new_fd`. For `dup2`/`dup3` where `new_fd` was already open to a different file, the old entry is silently overwritten (the kernel closed `new_fd` as part of the dup2).

**Close** (`handle_close_exit`): On `EBADF`, returns without evicting (the fd was never open). For all other return values — including `EIO` on network filesystems where the fd *is* closed despite the error — evicts from the cache. For `close_range`, skips eviction only on error (the syscall is atomic; on failure, no fds are closed).

**Rename/Link/Unlink/Mkdir** exits: On success, record the relevant paths in `read_paths`/`write_paths`. For rename, the old path is a read (it was consumed) and the new path is a write. For unlink/rmdir, the removed path is a write.

---

## 6. Path Resolution (`proc_helpers.rs`)

Path resolution is the most subtle part of observe. The tracer must map between three representations:

| Representation | Example | Use |
|---------------|---------|-----|
| Tracee path | `../foo/bar` | What the tracee passes as a syscall argument |
| Host proc path | `/proc/1234/root/home/user/foo/bar` | What the tracer can open/stat |
| Real path | `/home/user/foo/bar` | What appears in the report |

### 6.1 resolve_tracee_path

Converts a tracee-relative path to a host-accessible `/proc` path:

```rust
// proc_helpers.rs
pub fn resolve_tracee_path(pid, dirfd, tracee_path) -> Option<String> {
    if path.is_absolute()      { format!("/proc/{}/root{}", pid, tracee_path) }
    if dirfd == AT_FDCWD       { format!("/proc/{}/cwd/{}", pid, tracee_path) }
    if dirfd >= 0              { format!("/proc/{}/fd/{}/{}", pid, dirfd, tracee_path) }
}
```

This function never touches the filesystem — it's pure string construction. The resulting path is then passed to `is_readable_node()` or `resolve_to_real_path()`.

### 6.2 resolve_to_real_path

Opens the host proc path and reads `/proc/self/fd/<ourfd>` to get the canonical real path:

```rust
pub fn resolve_to_real_path(host_proc_path) -> Option<String> {
    let file = fs::File::open(host_proc_path)?;         // follows kernel symlinks
    let link = format!("/proc/self/fd/{}", file.as_raw_fd());
    fs::read_link(link)                                 // reads our own fd symlink
}
```

This is the authoritative path: the kernel resolves all symlinks in the host proc path and reports the canonical real path via `/proc/self/fd/`. It's used for path-meta and chmod handlers where the "real" path (not the tracee's lexical path) is what matters.

**Limitation:** It opens the file, which blocks on FIFOs. Hence the `is_readable_node()` guard before every call.

### 6.3 best_effort_resolve

Resolves a path to a real path without opening the leaf. Works for unlinked files and dangling symlinks. It reads `/proc/<pid>/cwd` or `/proc/<pid>/fd/<dirfd>` (symlinks, non-blocking) and joins with the tracee's relative path, then normalizes:

```rust
pub fn best_effort_resolve(pid, dirfd, tracee_path) -> Option<String> {
    let base = read_link("/proc/<pid>/cwd or /fd/<dirfd>")?;
    Some(normalize_path(&base.join(tracee_path)))
}
```

Used for: rename/unlink/link exit handlers (where the path may no longer exist), readlink/lchown (must not follow the leaf symlink), and as a fallback when `resolve_new_file_real_path` fails.

### 6.4 resolve_new_file_real_path

Used specifically for the `O_CREAT` case at open entry, where the file doesn't exist yet. It canonicalizes the **parent directory** (via `resolve_to_real_path`) and appends the filename:

```rust
pub fn resolve_new_file_real_path(pid, dirfd, tracee_path) -> Option<String> {
    let parent_host = resolve_tracee_path(pid, dirfd, parent_of(tracee_path))?;
    let canonical_parent = resolve_to_real_path(&parent_host)?;
    Some(canonical_parent.join(filename))
}
```

This produces the same key that `fd_cache.resolve(pid, fd)` returns at open exit (which reads `/proc/<pid>/fd/<fd>`, always canonical). Matching keys at entry and exit is necessary for correct pre-hash and snapshot deduplication.

### 6.5 follow_dangling_symlink

Handles the case where the `O_CREAT` path is itself a dangling symlink. The kernel follows the symlink chain when creating the file, so the canonical path of the created file is the chain's terminal target, not the symlink:

```rust
pub fn follow_dangling_symlink(path) -> Option<String> {
    loop {
        match symlink_metadata(current) {
            Ok(m) if m.is_symlink() => { current = resolve(read_link(current)); }
            Ok(_) => return None,   // exists as non-symlink — not dangling
            Err(_) => return Some(current) if depth > 0 else None,
        }
    }
}
```

Returns `None` for ordinary nonexistent paths (caller uses the path directly), symlink loops, or paths that already exist. Returns `Some(terminal)` only when a dangling chain was followed.

### 6.6 normalize_path

Pure string normalization (no filesystem access): removes `.` components and resolves `..` against the preceding normal component. Used by `best_effort_resolve` and `follow_dangling_symlink` to clean up joined paths.

---

## 7. FD Cache (`proc_helpers.rs`)

### 7.1 Structure

```rust
pub struct FdPathCache {
    map: HashMap<(Pid, i32), String>,  // (pid, fd) → real path
}
```

The cache is populated lazily: `resolve(pid, fd)` reads `/proc/<pid>/fd/<fd>` on first access and caches the result. Subsequent calls for the same `(pid, fd)` return immediately.

The kernel appends ` (deleted)` to the symlink target when a file is unlinked but still open. `normalize_proc_fd_target` strips this suffix so the path in the report matches what existed on disk.

### 7.2 Lifecycle

| Event | Cache operation |
|-------|----------------|
| `open()` succeeds | `resolve(pid, fd)` → populate |
| `dup()`/`dup2()`/`dup3()` succeeds | `insert(pid, new_fd, old_path)` |
| `close()` succeeds (or fails non-EBADF) | `remove(pid, fd)` |
| `close_range()` succeeds | `remove_range(pid, first, last)` |
| Process exits | `remove_pid(pid)` — evict all entries |
| `PTRACE_EVENT_EXEC` | `remove_pid(pid)` — flush stale O_CLOEXEC entries |
| `PTRACE_EVENT_FORK`/`CLONE` | no action — child starts with empty cache |

The exec flush (added after discovering Bug 12) is critical: O_CLOEXEC fds are closed by the kernel on exec. If the cache retains their entries and the new program reuses those fd numbers, `resolve()` returns the pre-exec path for what is actually a different file.

### 7.3 is_tracked

`is_tracked(pid, fd)` checks whether a `(pid, fd)` entry exists in the cache. Used by the close optimization: `handle_entry` only requests an exit stop for `close()` if the fd is tracked (has a cached path), since eviction of an untracked fd would be a no-op.

---

## 8. Tracer State (`state.rs`)

All mutable tracer state lives in `TracerState`:

```rust
pub struct TracerState {
    pub live: HashSet<Pid>,               // currently traced pids
    pub awaiting_exit: HashSet<Pid>,      // pids where ptrace::syscall() was called
    pub last_enter: HashMap<Pid, SysEnter>, // captured entry regs for each awaiting pid
    pub fd_cache: FdPathCache,

    pub read_paths: HashSet<String>,
    pub write_paths: HashSet<String>,
    pub hash_writes: bool,
    pub pre_hashes: HashMap<String, PreWrite>,   // path → pre-write state
    pub inode_hashes: HashMap<(u64,u64), PreWrite>, // (dev,ino) → pre-write (for dedup)

    pub snapshot_dir: Option<PathBuf>,
    pub snapshot_entries: Vec<SnapshotEntry>,       // ordered; written to manifest
    pub snapshotted_inodes: HashMap<(u64,u64), usize>, // (dev,ino) → index into entries
    pub snapshotted_paths: HashSet<String>,         // content-snapshotted paths (dedup)
    pub metadata_snapshotted: HashSet<String>,      // metadata-snapshotted paths (separate dedup)
    pub filter_noisy: bool,
}
```

**Two separate dedup sets for snapshots:** `snapshotted_paths` gates content snapshots (File, Nonexistent, Directory, Symlink), and `metadata_snapshotted` gates metadata snapshots (Metadata). These are intentionally separate so that `chmod` followed by `write` on the same file correctly records both: the metadata change in a Metadata entry and the file content in a File entry.

**`PreWrite` enum:**

```rust
pub enum PreWrite {
    Nonexistent,     // file didn't exist before first write (O_CREAT on new path)
    Unreadable,      // file existed but tracer couldn't read it
    Hash(u64),       // xxh3 hash of content before first write
}
```

---

## 9. Pre-Write Hashing

When `--hash` is set, observe records the content state of each written file before the first modifying syscall.

### 9.1 When hashing happens

| Scenario | When | How |
|----------|------|-----|
| `open()` with `O_TRUNC` on existing file | Entry (before kernel truncates) | `maybe_prehash_host_path` via `/proc/<pid>/root/<path>` |
| `open()` with `O_CREAT` on nonexistent path | Entry | Record `Nonexistent` directly |
| `open()` with `O_WRONLY`/`O_RDWR` on existing file (no O_TRUNC) | Exit (after fd is available) | `hash_fd` via `/proc/<pid>/fd/<fd>` |
| `truncate(path, ...)` | Entry | `maybe_prehash_host_path` |
| `sendfile`/`copy_file_range` write side | Entry | `maybe_prehash_fd` |

### 9.2 Inode deduplication

Hard links: two paths share the same `(dev, ino)`. Hashing the file content once and propagating the `PreWrite` value to all aliasing paths:

```rust
// syscall.rs — maybe_prehash_fd
let id = file_id_from_fd(pid, fd);   // (dev, ino)
if let Some(&existing) = state.inode_hashes.get(&id) {
    state.pre_hashes.insert(path, existing);  // reuse
    return;
}
// hash and store in both maps
```

### 9.3 Hashing implementation

`xxh3_stream` in `proc_helpers.rs` streams the file through an `Xxh3` hasher using `io::copy`, which calls the `Write` impl on the hasher:

```rust
fn xxh3_stream<R: Read>(mut reader: R) -> io::Result<u64> {
    let mut hasher = Xxh3::new();
    io::copy(&mut reader, &mut hasher)?;
    Ok(hasher.digest())
}
```

The tracee is stopped at the ptrace pause during hashing, so the file content is stable.

---

## 10. Snapshotting and Revert (`snapshot.rs`)

### 10.1 Snapshot entry types

```rust
pub enum SnapshotKind {
    File(String),              // content copied; relative path within snapshot dir
    Nonexistent,               // path didn't exist; revert: delete
    Directory,                 // directory existed; revert: recreate
    Symlink(String),           // symlink deleted; target stored; revert: recreate symlink
    Metadata { mode, uid, gid, mtime_sec, mtime_nsec },  // revert: restore attrs
    Unreadable,                // copy failed; revert: warn and skip
}
```

### 10.2 Collection

Four public functions are called from `syscall.rs` at appropriate points:

**`maybe_snapshot_fd(state, pid, fd, path)`**: Used for file writes detected at `open()` exit. Resolves via `/proc/<pid>/fd/<fd>`. Checks `snapshotted_paths` and `snapshotted_inodes` for dedup, then calls `do_snapshot_file()`.

**`maybe_snapshot_host_path(state, host_proc_path, real_path)`**: Used when the file is accessible via a host path directly (O_TRUNC at open entry, path-based truncate, rename/unlink source). Same dedup checks, same `do_snapshot_file()`.

**`snapshot_nonexistent(state, path)`**: Records a path as nonexistent (will be created). No file copy needed.

**`snapshot_existing_dir(state, path)`** and **`snapshot_existing_symlink(state, path, target)`**: Record a directory or symlink before removal.

**`maybe_snapshot_metadata(state, real_path)`**: Called by `handle_chmod`. Uses `std::fs::symlink_metadata` to capture current mode/uid/gid/mtime. Uses the separate `metadata_snapshotted` dedup set so a metadata snapshot doesn't block a later content snapshot.

### 10.3 do_snapshot_file — the core copy helper

```rust
fn do_snapshot_file(state, snapshot_dir, real_path, source_path, file_id) {
    if let Some(id) = file_id {
        if let Some(&idx) = state.snapshotted_inodes.get(&id) {
            // Hard-link dedup: reuse the existing entry's kind
            state.snapshot_entries.push(SnapshotEntry { path: real_path, kind: clone_kind(idx) });
            return;
        }
        // New inode: copy file and record index
        let kind = copy_file(source_path, dest).map_or(Unreadable, |_| File(filename));
        state.snapshotted_inodes.insert(id, snapshot_entries.len());
        state.snapshot_entries.push(...);
    } else {
        // Can't get inode: copy without dedup
    }
}
```

Filenames in `snapshot_dir/files/` are percent-encoded real paths (`path_to_filename`), making the flat directory layout unambiguous and filesystem-safe.

### 10.4 Noisy-path filtering

`is_noisy_path(path)` returns true for `/tmp/...`, `/proc/...`, `/dev/...`, `pipe:...`, `socket:...`, and `anon_inode:...`. All snapshot collection functions check `state.filter_noisy && is_noisy_path(path)` early and return without doing anything. This prevents expensive copies of multi-gigabyte temp files.

### 10.5 Manifest writing

`write_manifest(snapshot_dir, entries)` serializes the `snapshot_entries` vector to JSON atomically:

```
snapshot_dir/manifest.json.tmp  →  snapshot_dir/manifest.json
```

The atomic rename ensures that a partially written manifest is never visible to `observe revert`.

### 10.6 Revert

`revert(snapshot_dir)` reads `manifest.json` and processes entries in **reverse order** — later writes (or creations) are undone first, restoring the filesystem in the correct dependency order:

| Entry kind | Revert action |
|------------|--------------|
| `File` | `fs::copy(snapshot_file, path)` |
| `Nonexistent` | `fs::remove_file(path)` or `fs::remove_dir(path)` (best-effort) |
| `Directory` | `fs::create_dir_all(path)` |
| `Symlink` | Remove existing, then `std::os::unix::fs::symlink(target, path)` |
| `Metadata` | `lchown`, `chmod`, `utimensat` with `AT_SYMLINK_NOFOLLOW` |
| `Unreadable` | Print warning, skip |

`restore_metadata` uses `lchown` (not `chown`) and `utimensat` with `AT_SYMLINK_NOFOLLOW` so that symlinks themselves (not their targets) have their attributes restored.

---

## 11. CLI and Report Generation (`main.rs`)

### 11.1 Argument parsing

observe uses a minimal hand-written parser (no external crate). The `--` separator is required when using flags; without it all arguments are treated as the command:

```
observe [flags] -- <command> [args...]
observe <command> [args...]        # also works when no flags needed
```

`parse_flag_value(flags, "--output")` scans `flags.windows(2)` for the first pair where `pair[0] == "--output"` and returns `pair[1]` as a `PathBuf`.

### 11.2 Post-tracing filter

After `tracer::run_tracer()` returns, `filter_paths()` removes noisy paths from `read_paths`, `write_paths`, and `pre_hashes` when `--no-filter` was not set. This is the **report-side** filter. The **collection-side** filter in `snapshot.rs` independently guards snapshot operations. Both must stay in sync with `is_noisy_path()`.

### 11.3 Report format

**Plain text** (default):
```
--- observe: file access report ---
Reads:
  /path/to/file_a
  /path/to/file_b
Writes:
  /path/to/output.txt (pre-hash: 1a2b3c4d5e6f7890)
  /path/to/new.txt (new file)
```

**JSON** (`--json`): Built by `build_json_report()`. Write entries are either plain strings (no `--hash`) or objects with `"path"` and `"pre_hash"` fields:

```json
{
  "reads": ["/path/to/file_a", "/path/to/file_b"],
  "writes": [
    {"path": "/path/to/output.txt", "pre_hash": "1a2b3c4d5e6f7890"},
    {"path": "/path/to/new.txt",    "pre_hash": "nonexistent"}
  ]
}
```

Both formats sort their entries alphabetically.

---

## 12. Reading Tracee Memory (`proc_helpers.rs`)

Syscall arguments include pointers to strings in the tracee's address space. `read_tracee_cstr(pid, addr)` reads them:

**Fast path — `process_vm_readv`:** Reads up to 4096 bytes from the tracee in one cross-process call. NUL search is limited to `buf[..bytes_read]` (not the full buffer) to avoid false termination from zero-initialized tail bytes.

**Fallback — `ptrace::read` word-by-word:** Used when `process_vm_readv` fails or doesn't find a NUL. Reads 8 bytes at a time via ptrace and scans for NUL. Handles paths longer than 4096 bytes up to a 1 MiB safety limit.

```rust
// proc_helpers.rs
pub fn read_tracee_cstr(pid: Pid, addr: u64) -> Result<String> {
    // fast path: process_vm_readv
    let bytes_read = process_vm_readv(...);
    if bytes_read > 0 {
        if let Some(nul) = buf[..bytes_read].iter().position(|&b| b == 0) {
            return Ok(String::from_utf8_lossy(&buf[..nul]));
        }
    }
    // fallback: ptrace word-by-word
    ...
}
```

For `openat2`, the flags are in a `struct open_how` pointed to by the third argument. `read_open_how_flags(pid, ptr)` reads the 8-byte `flags` field at offset 0 of that struct using `ptrace::read`.

---

## 13. Performance Design

observe's ~1.06× overhead vs. bash comes from a combination of design choices:

| Optimization | Mechanism | Impact |
|-------------|-----------|--------|
| Selective seccomp filter | Only ~45 syscalls trigger ptrace stops | Eliminates stops on read/write/mmap/fstat — the dominant syscalls in pipe-heavy workloads |
| Entry-only for cheap syscalls | `ptrace::cont()` for PathMeta/Chmod/PathTrunc/CrossFd | Halves the ptrace round-trips for those groups |
| close() optimization | Skip exit stop for untracked fds | Reduces overhead for programs that close many fds |
| fd cache | Avoids repeated `/proc/<pid>/fd/` reads | Makes per-syscall dispatch O(1) for cached fds |
| In-memory dedup | HashSet for paths, HashMap for inodes | O(1) duplicate suppression; no repeated file copies |
| Atomic manifest write | Rename after write | No fsync overhead in the critical path |

The seccomp filter uses a linear scan of 45 `JEQ` instructions. This has O(n) worst-case complexity per syscall, but n=45 is small and the BPF JIT makes each instruction extremely cheap. An alternative (hash table BPF map) would complicate the filter and is not needed at this scale.

---

## 14. Key Invariants and Subtle Interactions

### Entry vs. exit timing for snapshots

| Syscall | Snapshot at entry | Reason |
|---------|------------------|--------|
| `open` with `O_TRUNC` | Yes | Kernel truncates atomically with the open — no exit chance |
| `truncate(path)` | Yes | Same reason: path-based truncation at entry |
| `rename`/`unlink` source | Yes | File disappears after a successful syscall |
| `open` with `O_WRONLY` (no TRUNC) | No (at exit) | File still intact; fd not available until exit |
| `sendfile`/`copy_file_range` write side | Yes (at entry) | Content is about to be overwritten |

### pre_hashes key must match fd_cache key

At open entry, `pre_hashes[path] = Nonexistent` is stored under a lexically-resolved key (from `resolve_new_file_real_path` or `best_effort_resolve`). At open exit, `fd_cache.resolve(pid, fd)` reads `/proc/<pid>/fd/<fd>`, which always returns the kernel-canonical path. If any component of the path is a symlink, these can differ. Two fixes ensure they match:

1. `resolve_new_file_real_path` opens the parent directory to canonicalize it (so directory-component symlinks are resolved).
2. `follow_dangling_symlink` handles the case where the leaf itself is a dangling symlink (O_CREAT through a dangling symlink creates the file at the symlink's target, not at the symlink path).

### metadata_snapshotted vs snapshotted_paths

A common sequence is `chmod file; write to file`. If `snapshotted_paths` were used for both metadata and content snapshots, the chmod would add the path, and the subsequent write snapshot would see the path as already covered and skip it — leaving no File entry in the manifest, so the file content can't be reverted. The solution is `metadata_snapshotted` as a separate dedup set: metadata snapshots record there, content snapshots record in `snapshotted_paths`, and neither blocks the other.
