# Project Context: observe

This document captures the motivations, design goals, and behavioral semantics for **observe**. It is the right starting point for understanding why the project exists, what guarantees it makes, and how it fits into the broader ecosystem.

For a technical deep-dive into how each component is implemented, see [DESIGN.md](DESIGN.md).

---

## 1. Overview and Goals

**observe** is a command-line utility that **traces which files an arbitrary command reads and writes**, using ptrace and seccomp-BPF on Linux. It runs the user's command under tracing, records all file-related accesses in memory, and at the end prints a single report: the set of paths read and the set of paths written. The traced command's stdout and side effects are completely unchanged; only the report is produced (on stderr), and the command's exit code is forwarded as observe's exit code.

**Core goal:** Run any command (e.g. `observe -- make -j4` or `observe -- python3 script.py`) and get a clear, end-of-run summary of file I/O — not a stream of every syscall like raw strace, but a digested read/write path report.

**Target platform:** Ubuntu 22.04 (kernel 5.15, x86_64). All syscalls and ptrace/seccomp behavior are written for this environment.

---

## 2. Motivations and Background

### 2.1 Relationship to `try`

observe is designed as a lightweight alternative to [try](https://github.com/binpash/try), a tool that uses overlayfs to sandbox commands and detect filesystem changes.

`try` works by mounting an overlayfs over the real filesystem so writes land in an upper directory, running the command in a user-namespace sandbox, and then scanning the upper directory to classify what changed. It can commit or discard those changes atomically.

observe is intended as a lighter alternative for two try-based workflows:

**Workflow 1 — try as a "run and roll back" tool:** try provides revert by discarding uncommitted changes. observe provides the same "run and roll back" semantics without overlayfs overhead using `--snapshot-dir`: it copies files before their first write and can later restore them with `observe revert <dir>`.

**Workflow 2 — `try + strace` for file-access auditing:** try is sometimes used with strace to detect file effects without committing:
```sh
try -- strace -yf --seccomp-bpf --trace=fork,clone,%file -o /tmp/trace.log -- <command>
```
This produces a verbose raw syscall log that requires significant post-processing. observe replaces this entire pipeline: it traces the same syscalls internally and emits a clean, deduplicated, sorted read/write report with no sandboxing overhead and no log parsing step.

**Comparison:**

| | `try` (with revert) | `try + strace` | `observe` |
|---|---|---|---|
| **Sandboxing / isolation** | Yes (overlayfs) | Yes (overlayfs) | No — changes are real |
| **Needs root / sudo** | Yes (for cleanup) | Yes | No |
| **Startup overhead** | Slower (overlay setup) | Slower | Fast |
| **Output** | Structured change list | Raw verbose syscall log | Clean deduplicated read/write report |
| **Pre-write state** | Full filesystem snapshot in upperdir | N/A | `--hash` (xxh3 fingerprint) or `--snapshot-dir` (full copy-before-write) |
| **Revert capability** | Yes (don't commit = discard) | Yes (don't commit = discard) | Yes — `--snapshot-dir` + `observe revert` |

### 2.2 Inspiration from strace

The idea is similar to using `strace -yf --seccomp-bpf --trace=fork,clone,%file` directly — but instead of logging every call, observe tracks accesses in memory and prints a single summary when the command finishes. This keeps output manageable and makes it easy to see "what did this command touch?"

### 2.3 Use cases

- **Understanding build/script I/O:** What files does `make` actually read and write? Which inputs does a Python script depend on?
- **Auditing file access:** Verify that a command only touches the files it's supposed to.
- **Dependency tracking:** Identify the read set of a command for incremental build systems (see incr integration below).
- **Lightweight snapshots:** Capture filesystem state before a command runs, then roll back with `observe revert`.

---

## 3. Semantics and Behavior

### 3.1 What counts as "read" and "write"

**Reads** include any access that observes file content or metadata without modifying it:
- `open`/`openat`/`openat2`/`creat` with `O_RDONLY` or `O_RDWR` flags
- Directory opens (appear as `O_RDONLY` opens)
- `newfstatat`, `statx`, `access`, `faccessat`, `faccessat2`
- `readlink`, `readlinkat`
- The read side of `sendfile` / `copy_file_range`
- The executed binary itself (via `PTRACE_EVENT_EXEC` and `/proc/<pid>/exe`)

Note: `read()`, `pread64()`, `mmap()`, `getdents()` etc. are **not** intercepted by the seccomp filter; reads are inferred from `open()` flags instead. This is correct because a file can only be read if opened with read access.

**Writes** include any modification of file content or metadata:
- `open`/`openat`/`openat2`/`creat` with `O_WRONLY`, `O_RDWR`, `O_TRUNC`, or `O_CREAT` flags
- `truncate` (path-based)
- `sendfile` / `copy_file_range` (write side)
- `rename`/`renameat`/`renameat2` — new path is written
- `link`/`linkat`/`symlink`/`symlinkat` — new path is written
- `unlink`/`unlinkat`/`rmdir`
- `mkdir`/`mkdirat`
- `chmod`/`fchmod`/`fchmodat`, `chown`/`fchown`/`lchown`/`fchownat`, `utimensat`

Note: `write()`, `ftruncate()`, `fallocate()` etc. are **not** intercepted; write tracking is based on `open()` flags, and the pre-write hash/snapshot is captured at `open()` exit time.

### 3.2 Path filtering

By default, **noisy or transient paths** are excluded from the report:

- `/tmp`, `/proc`, `/dev` and everything under them
- Paths starting with `pipe:`, `socket:`, or `anon_inode:`

Use `--no-filter` to disable this filtering and include all paths.

**Rationale:** These paths are run-specific, device/pipe/socket names, or kernel abstractions; excluding them keeps the report focused on real filesystem paths. The same filter is applied at snapshot collection time so large sort temporaries written to `/tmp` are never expensively copied.

### 3.3 Pre-write hashing (`--hash`)

When `--hash` is set, observe records a **pre-write fingerprint** for each file that is written:

- **Mechanics:** At the first write to a file (at syscall entry, while the tracee is paused), the tracer reads the file via `/proc/<pid>/fd/<fd>` and computes an **xxh3** 64-bit hash. Each `(dev, ino)` pair is hashed at most once; hard links share a value.
- **O_TRUNC handling:** The hash is captured at open **entry** (before the kernel zeroes the file), since truncation is atomic with the open call.
- **New files:** Reported as `(new file)` in text output and `"pre_hash": "nonexistent"` in JSON.
- **Unreadable files:** Reported as `(unreadable)`.

### 3.4 Snapshot and revert (`--snapshot-dir`)

`--snapshot-dir <dir>` activates copy-before-modification snapshotting. At the same ptrace pause used for hashing, files are copied to `<dir>/files/` before the write proceeds. At the end of the run, a `manifest.json` is written atomically describing every snapshotted path and how to undo it. `observe revert <dir>` reads the manifest and reverses the changes in reverse order.

| Operation | What is captured | Revert action |
|-----------|-----------------|---------------|
| Write to existing file | File content before first write | Restore content from snapshot |
| Create new file (`O_CREAT`) | Nothing to copy | Delete the created path |
| Truncate (`O_TRUNC`) | File content before open | Restore content |
| Delete file (`unlink`) | File content before deletion | Restore content |
| `rename` old path | Content / symlink target / dir | Restore old path |
| `rename` new path (if it existed) | Content / symlink target / dir | Restore new path |
| `rename` new path (if it didn't exist) | Nothing | Delete the path |
| `mkdir` | Nothing | Remove the dir (best-effort) |
| `rmdir` | Nothing | Recreate the dir |
| `symlink` | Nothing | Remove the symlink |
| `unlink` of a symlink | Symlink target | Recreate the symlink |
| `chmod` / `chown` / `utimensat` | mode/uid/gid/mtime via lstat | Restore via lchown/chmod/utimensat |
| Non-regular files (pipes, sockets) | Skipped | Nothing |

**Hard-link dedup:** the same inode is snapshotted at most once, keyed by `(dev, ino)`. Additional paths that alias the same inode reference the same snapshot file.

**Metadata tracking:** Metadata-only snapshots (from chmod/chown) use a separate dedup set from content snapshots so that `chmod` followed by `write` on the same file correctly captures both the metadata and the content independently.

### 3.5 Output and exit code

- **Report destination:** stderr only; stdout of the traced command is untouched.
- **Exit code:** observe exits with the tracee's exit code. If the initial child is killed by a signal, observe exits with 128 + signal number.
- **Formats:** Plain text (sorted reads, then writes, with optional pre-hash annotations) or JSON (`--json`) with `reads` array and `writes` array.
- **Output file:** `--output <file>` writes the report as JSON to a file instead of printing to stderr.

### 3.6 Multi-process tracing

All forked/cloned children are traced automatically (seccomp is inherited across fork/clone/exec). The report is the union of file accesses across all processes in the traced tree. The exit code is that of the initial tracee (the process that exec'd the user command).

### 3.7 Kill safety

- **Tracee killed** (the typical case for cached build systems): observe detects the death via `waitpid`, exits the event loop, and writes the manifest normally.
- **SIGTERM to observe:** A signal handler sets an atomic flag; the blocking `waitpid` call returns `EINTR`; the loop breaks and the manifest is written with whatever was collected. `PTRACE_O_EXITKILL` ensures tracees are killed when observe exits.
- **SIGKILL to observe:** Cannot be caught. The manifest will be incomplete or missing.

---

## 4. Architecture and Design Decisions

### 4.1 Process model

```
observe (tracer)                       child (tracee)
    │                                      │
    ├─ fork() ─────────────────────────────┤
    │                                      ├─ ptrace::traceme()
    │                                      ├─ install seccomp filter
    │                                      ├─ raise(SIGSTOP) ──────────► [paused]
    ├─ waitpid (initial stop)              │
    ├─ ptrace::setoptions(...)             │
    ├─ ptrace::cont() ────────────────────►│
    │                                      ├─ execvp(user command)
    │◄─ PTRACE_EVENT_EXEC ─────────────────│
    │                                      │   [running under seccomp filter]
    │◄─ PTRACE_EVENT_SECCOMP ──────────────│   (file-related syscall)
    ├─ handle_entry(...)                   │
    ├─ ptrace::cont() or syscall()         │
    │◄─ PtraceSyscall (exit stop) ─────────│   (if syscall() was used)
    ├─ handle_exit(...)                    │
    ├─ ptrace::cont() ────────────────────►│
    │         ... repeats ...              │
    │◄─ Exited(pid, code) ─────────────────│
    ├─ write manifest (if --snapshot-dir)  │
    └─ print report; exit(code)            │
```

### 4.2 Seccomp + ptrace hybrid

The key insight is that seccomp-BPF and ptrace complement each other:

- **seccomp-BPF** filters at the kernel level, generating ptrace stops only for the ~45 file-related syscalls in `TRACED_SYSCALLS`. All other syscalls (read, write, mmap, fstat, getdents, etc.) pass through without any tracer involvement.
- **ptrace** catches those filtered syscalls in the tracer for inspection, path resolution, hashing, and snapshotting.

This combination keeps overhead low: a pipeline with heavy pipe I/O calls `read()` and `write()` hundreds of thousands of times, but those never reach the tracer at all.

### 4.3 Hybrid entry/exit strategy

Not every intercepted syscall needs both the entry and exit stops. Two distinct resume strategies are used:

- **`ptrace::cont()`** — resume without requesting a syscall-exit stop. Used when entry arguments are sufficient (path-meta, truncate, sendfile, chmod). The tracer does its work at entry and moves on.
- **`ptrace::syscall()`** — resume while requesting a syscall-exit stop. Used when the return value is needed: the new fd from open/dup, the success/failure of rename/unlink/mkdir.

For `close()`, the exit stop is only requested when the fd is in the fd cache (i.e., it has a tracked path). Untracked fds (pipes, sockets, epoll fds) skip the exit stop entirely, since eviction from the cache would be a no-op anyway.

### 4.4 Why read()/write() are not intercepted

Removing `read`, `write`, `mmap`, `getdents`, `ftruncate`, and their variants from the seccomp filter was the primary performance optimization, reducing overhead from ~1.50× to ~1.06× vs. baseline bash. Correctness is preserved because:

1. **Read tracking:** every file opened `O_RDONLY` or `O_RDWR` is added to `read_paths` at `open()` exit. A file can only be read if it was opened with read access.
2. **Write tracking and snapshotting:** every file opened for writing is snapshotted and hashed at `open()` exit, before the tracee resumes and before any `write()` can happen.
3. **ftruncate:** the fd was already opened with write intent; the snapshot and hash were taken at open time.
4. **mmap:** file-backed writable mmaps require a prior `open()` with write intent, which is already intercepted.

### 4.5 Path resolution strategy

Paths are never resolved from the tracer's own view of the filesystem (which could differ in namespaces). Instead, they are always resolved through `/proc/<pid>/`, which reflects the tracee's view:

- Absolute tracee paths → `/proc/<pid>/root/<path>`
- Relative paths from cwd → `/proc/<pid>/cwd/<relative_path>`
- Relative paths from a dirfd → `/proc/<pid>/fd/<dirfd>/<relative_path>`
- Open fd → `/proc/<pid>/fd/<fd>` (symlink to the real path)

The fd cache (`FdPathCache`) stores resolved real paths so that subsequent operations on a cached fd (sendfile, fchmod, close) don't need to re-read from `/proc`.

### 4.6 Destructive syscall handling

For syscalls that destroy or replace filesystem state — `rename`, `unlink`, `rmdir` — snapshotting happens at **entry** (before the kernel acts), while read/write path recording happens at **exit** (after success is confirmed). This ensures:

- The file content is captured before it's gone.
- Failed syscalls don't produce spurious snapshot entries.

---

## 5. Integration with incr

observe is intended to be used with [incr](https://github.com/binpash/incr) as a lightweight alternative to the `try + strace` pipeline incr currently uses for dependency tracking.

incr currently uses strace to produce `(read_set, write_set)` for each command it runs. observe's `--json` output provides the same information directly, without strace log parsing. The planned integration points are:

- `command.rs`: Add a `RuntimeType::Observe` that runs `observe --json -o <file> -- <cmd>`
- `execution/mod.rs`: Parse observe's JSON output into `(read_set, write_set)`
- `config.rs`: Add `TraceType::Observe` and `OBSERVE_COMMAND`

The `--snapshot-dir` + `observe revert` mechanism provides the same "run and roll back" semantics as try's sandbox without needing overlayfs or root privileges, at the cost of writes touching the real filesystem.

---

## 6. Performance

observe adds roughly **1.06× overhead** vs. plain bash on the benchmark suite (six Koala benchmarks: covid, weather, oneliners, nlp, unixfun, file-mod). With `--snapshot-dir` enabled, overhead is ~1.07×. By comparison, try (overlayfs) runs at 1.28× and try+strace at 1.37×.

The benchmark suite lives in `evaluation/` and can be run with `bash run.sh --small`. Six modes are measured: bash (baseline), observe, observe+snapshot, try, and try+strace.

Key optimizations driving the low overhead:

1. **Selective seccomp filter:** only ~45 syscalls trigger ptrace stops; read/write/mmap/fstat/getdents pass through freely.
2. **Entry-only handling:** path-meta, truncate, sendfile, and chmod operations resume with `ptrace::cont()` — no exit stop, no second round-trip.
3. **close() optimization:** untracked fds skip the exit stop.
4. **In-memory state:** all path sets are hash sets; dedup by `(dev, ino)` for hashing and snapshotting.

---

## 7. Development Notes

### Adding a new traced syscall

Two places must be updated together or behavior breaks:

1. **`seccomp.rs`** — add the syscall number to `TRACED_SYSCALLS` so the BPF filter generates a `PTRACE_EVENT_SECCOMP` stop for it.
2. **`syscall.rs`** — add a branch to `classify()` mapping the syscall number to a `SyscallKind`, and implement entry/exit handling in `handle_entry`/`handle_exit`.

If only `seccomp.rs` is updated, seccomp stops arrive but fall through to `SyscallKind::Other` (no-op). If only `syscall.rs` is updated, the handler code is dead — the syscall never stops.

### Adding a new CLI flag

Parse the flag in `main.rs`, pass it into `tracer::run_tracer()` (extend the signature or add a config struct), and store it in `TracerState`. Output formatting lives in `print_report` / `build_json_report` in `main.rs`.

### Critical invariants

1. **stderr only:** the report is always printed to stderr. stdout belongs to the traced command.
2. **Exit code forwarding:** observe exits with the tracee's exit code (or 128 + signal number). Never use observe's own exit code for errors that the caller shouldn't see.
3. **`awaiting_exit` discipline:** `state.awaiting_exit` contains exactly the set of pids for which `ptrace::syscall()` was called after a seccomp stop. The next stop for those pids is a `PtraceSyscall` exit stop — it must not be re-dispatched as a new entry.
4. **Snapshot filtering at collection time:** noisy-path filtering (`state.filter_noisy`) is applied inside `snapshot.rs` at the point of collection. Do not add a second filter pass in `main.rs` for snapshots.
5. **fd cache flush on exec:** `PTRACE_EVENT_EXEC` evicts all fd cache entries for the exec'd pid. O_CLOEXEC fds are closed by the kernel on exec; stale cache entries for those fd numbers would corrupt path attribution when the new program reuses them.

### Common pitfalls

- Do not add a syscall to the seccomp filter without handling it in `syscall.rs`.
- Do not emit report data to stdout.
- Evict the fd cache on `close`/`close_range` and update it on `dup`/`dup2`/`dup3`.
- Snapshot destructive operations (`rename`, `unlink`, `rmdir`) at entry, not exit.
- Use `is_readable_node()` (stat-based) before `resolve_to_real_path()` (opens the file). Opening a named FIFO with `O_RDONLY` blocks indefinitely if there is no writer — calling `open()` on a FIFO while the tracee is stopped causes a deadlock.
- `lchown` and `readlink` operate on the symlink itself — use `best_effort_resolve` + `symlink_metadata`, not `resolve_to_real_path` (which follows symlinks).

---

## 8. Bug History

Significant semantic bugs fixed during development:

1. **`read_tracee_cstr` short-read truncation** (`proc_helpers.rs`): `process_vm_readv` short reads at page boundaries left zero-initialized bytes, causing false NUL termination. Fix: limit NUL search to the bytes actually read.

2. **`unlinkat` with `AT_REMOVEDIR` not snapshotted** (`syscall.rs`): `handle_unlink_entry` only checked `SYS_rmdir`; `unlinkat(dirfd, path, AT_REMOVEDIR)` (used by `rm -rf`) fell through silently. Fix: check the `AT_REMOVEDIR` flag on `unlinkat`.

3. **`readlink` and `lchown` following symlinks** (`syscall.rs`): both syscalls operate on the symlink itself, but `resolve_to_real_path` followed symlinks. Fix: use `best_effort_resolve` + `symlink_metadata`.

4. **`utimensat`/`fchownat` with `AT_SYMLINK_NOFOLLOW` and `AT_EMPTY_PATH`** (`syscall.rs`): these flags indicate non-default resolution; the code always followed symlinks or mishandled the empty-path fd case. Fix: detect the flags and dispatch accordingly.

5. **`json_escape` missing control characters** (`main.rs`): only `\` and `"` were escaped, producing invalid JSON for filenames containing control characters. Fix: escape `\n`, `\r`, `\t` and encode remaining controls as `\u00XX`.

6. **`close_range` cast truncation** (`proc_helpers.rs`): the `last` argument was cast from u64 to i32, corrupting values in `[0x80000000, 0xFFFFFFFE]`. Fix: treat any negative cast result as "close all from first upward."

7. **Metadata snapshot blocking content snapshot** (`snapshot.rs`, `state.rs`): `maybe_snapshot_metadata` added paths to `snapshotted_paths`, preventing a later `maybe_snapshot_fd` from capturing file content. Fix: use a separate `metadata_snapshotted` set.

8. **O_CREAT path key mismatch** (`syscall.rs`, `proc_helpers.rs`): when directory components of a new file's path are symlinks, the entry-time key (lexical) diverged from the exit-time key (canonical fd path). Fix: introduced `resolve_new_file_real_path` which canonicalizes the parent directory, and `follow_dangling_symlink` for the leaf symlink case.

9. **Named FIFO deadlock** (`syscall.rs`): removed `is_readable_node` guard caused `resolve_to_real_path` to call `open(O_RDONLY)` on FIFOs, blocking forever since the tracee was stopped. Fix: restored the stat-based guard before any open call.

10. **O_RDWR files not recorded in `read_paths`** (`syscall.rs`): after removing `read()` interception, files opened O_RDWR were no longer implicitly added to `read_paths`. Fix: explicitly add them at `open()` exit.

11. **`close()` EIO leaving stale fd cache entry** (`syscall.rs`): any non-zero return from `close()` was treated the same as `EBADF` (skip eviction), but `close()` can return `EIO` on network filesystems while still closing the fd. Fix: only skip eviction for `EBADF`; evict on all other return values.

12. **fd cache not flushed on exec** (`tracer.rs`): O_CLOEXEC fds from before an exec remained in the cache; if the new program reused those fd numbers, the stale path was attributed to the new file. Fix: call `fd_cache.remove_pid(pid)` in the `PTRACE_EVENT_EXEC` handler.

---

## 9. Implementation Summary

**Language and dependencies:** Rust. Key crates: `nix` (ptrace, signal, process), `anyhow` (error handling), `libc` (seccomp BPF structs, syscall numbers, prctl, process_vm_readv), `xxhash-rust` (xxh3 hashing), `serde` + `serde_json` (snapshot manifest serialization).

**Source files:**

| File | Responsibility |
|------|---------------|
| `main.rs` | CLI parsing, fork, path filtering, report printing; `observe revert` dispatch; manifest write after run |
| `child.rs` | traceme, seccomp installation, exec |
| `tracer.rs` | waitpid loop, event dispatch, SIGTERM handler |
| `syscall.rs` | `SysEnter`, `classify`, `handle_entry`/`handle_exit`; all read/write/snapshot/hash logic |
| `proc_helpers.rs` | `FdPathCache`, path resolution, tracee memory reading, file identity, hashing |
| `state.rs` | `TracerState`, `PreWrite`, `SnapshotKind`, `SnapshotEntry` |
| `snapshot.rs` | `maybe_snapshot_*`, `write_manifest` (atomic), `revert`, `is_noisy_path`, `path_to_filename` |
| `seccomp.rs` | BPF program construction and installation |

**Tests:** 367 assertions across 32 test files covering basic read/write tracking, exit code forwarding, `--hash` (new/existing/append/O_TRUNC/multi-write), mkdir/symlink/hardlink/rename/unlink/rmdir, multi-process, Python programs, JSON output, path filtering, snapshot/revert (files, dirs, symlinks, metadata, kill safety, noisy-path filtering, chmod-then-write ordering), seccomp correctness, fd lifecycle (dup2, dup3, close_range, fd reuse, exec/O_CLOEXEC), and dangling symlink O_CREAT handling.
