# observe

A command-line utility that traces which files a command reads and writes using ptrace + seccomp-BPF. Runs an arbitrary command and prints the set of file paths it interacted with. Optionally saves pre-write snapshots to disk and can revert all filesystem changes after the fact.

## Usage

```
observe [flags] -- <command> [args...]
observe revert <snapshot-dir>
```

The `--` separator is **required** when using flags. Without `--`, all arguments are treated as the command.

```bash
# With flags (-- required)
observe --hash -- python3 script.py input.txt output.txt
observe --json --no-filter -- make -j4
observe --snapshot-dir /tmp/snap -- ./build.sh

# Without flags (-- optional)
observe -- gcc -o main main.c
observe gcc -o main main.c        # also works

# Revert a previous run
observe revert /tmp/snap
```

## Flags

| Flag | Description |
|------|-------------|
| `--hash` | Compute xxh3 hash of each file before its first modification. Reports the pre-write fingerprint alongside each written path. New files are marked as `(new file)`. |
| `--json` | Output the report as JSON instead of plain text. |
| `--no-filter` | Include `/tmp`, `/proc`, `/dev`, `pipe:`, `socket:`, and `anon_inode:` paths in the report and snapshot. These are filtered out by default. |
| `--snapshot-dir <dir>` | Before each file's first write, copy its current content into `<dir>/files/`. Write a `manifest.json` at the end listing every snapshotted path and how to restore it. Run `observe revert <dir>` afterward to undo all changes. |

## Subcommands

| Subcommand | Description |
|------------|-------------|
| `observe revert <dir>` | Restore the filesystem to the state it was in before the snapshotted run. Reads `<dir>/manifest.json` and applies changes in reverse order: restores file content, removes created files/dirs/links, recreates removed dirs/symlinks, restores metadata. |

## Output

The report is printed to **stderr** so it doesn't interfere with the traced command's stdout. The traced command's exit code is forwarded as observe's exit code.

```
$ observe --hash -- cp original.txt copy.txt
--- observe: file access report ---
Reads:
  /etc/ld.so.cache
  /home/user/original.txt
  /usr/bin/cp
  /usr/lib/x86_64-linux-gnu/libc.so.6
Writes:
  /home/user/copy.txt (new file)
```

With `--json`:

```json
{
  "reads": ["/home/user/original.txt", "..."],
  "writes": [
    {"path": "/home/user/copy.txt", "pre_hash": "nonexistent"}
  ]
}
```

With `--snapshot-dir /tmp/snap`:

```
$ observe --snapshot-dir /tmp/snap -- bash -c "echo hi > out.txt"
$ cat /tmp/snap/manifest.json
{
  "entries": [
    {"path": "/home/user/out.txt", "kind": "nonexistent"}
  ]
}
$ observe revert /tmp/snap   # removes out.txt
```

## Snapshot and revert

`--snapshot-dir` captures filesystem state *before* any write, so the run can be fully undone:

- **Existing file overwritten** → content is copied into `<dir>/files/`; revert restores it.
- **New file created** (`O_CREAT` on a nonexistent path) → recorded as `nonexistent`; revert deletes it.
- **File deleted** (`unlink`) → content copied before deletion; revert restores it.
- **Directory created** (`mkdir`) → recorded as `nonexistent`; revert removes it.
- **Directory removed** (`rmdir`) → recorded as `directory`; revert recreates it.
- **Symlink created** → recorded as `nonexistent`; revert removes it.
- **Symlink deleted** → target recorded; revert recreates the symlink.
- **Rename** → both old and new paths snapshotted before the rename executes.
- **Metadata change** (`chmod`/`chown`/`utimensat`) → mode/uid/gid/mtime captured; revert restores them.
- **Hard links** → content copied once per inode; both paths reference the same snapshot file.
- **Non-regular files** (pipes, sockets) → silently skipped; revert will not affect them.

**Noisy-path filtering:** By default, `/tmp`, `/proc`, `/dev`, and pseudo-files are excluded from both the report *and* the snapshot, so large sort temporaries written to `/tmp` are never expensively copied. Use `--no-filter` to override.

**Kill safety:** If the traced command is killed mid-run (e.g. by an orchestrator that detects cached results), observe detects the death via `waitpid` and writes the manifest normally. If observe's own process receives `SIGTERM`, a signal handler interrupts the event loop and the manifest is written with whatever was collected before the signal. `SIGKILL` to observe cannot be caught; the manifest will be incomplete or missing in that case.

## Build

```bash
cargo build --release
```

## Test

```bash
cargo build --release
bash tests/run_tests.sh            # run all tests
bash tests/run_tests.sh snapshot   # run only snapshot-related tests
bash tests/run_tests.sh hash       # run only hash-related tests
```

## Benchmarks

Performance benchmarks comparing observe against [try](https://github.com/binpash/try) (overlayfs-based sandbox) and try+strace (the pipeline observe replaces) are in `evaluation/`. Six benchmark suites are adapted from the [Koala shell benchmark suite](https://github.com/binpash/benchmarks): covid, weather, oneliners, nlp, unixfun, and file-mod.

```bash
cd evaluation
bash run.sh --min                          # fast run with bundled/tiny inputs
bash run.sh --small                        # larger inputs (downloads needed)
bash run.sh --small -b oneliners,nlp       # run specific benchmarks
bash run.sh --small -m bash,observe,try    # run specific modes
bash run.sh --small --granularity per-cmd  # per-command granularity (like incr)
python3 analysis/plots.py                  # generate PDF plots (whole granularity)
python3 analysis/plots.py --granularity both  # include per-cmd vs whole comparison
```

Results on `--small` inputs (geomean overhead vs bash):

| Mode | Overhead |
|------|----------|
| observe | **1.06×** |
| observe+snapshot | 1.07× |
| try | 1.28× |
| try+strace | 1.37× |

observe adds negligible overhead (~6%) compared to bash and is faster than try for per-command use. The seccomp filter is optimized to exclude high-volume but uninformative syscalls (read, write, mmap, getdents, etc.), since all tracking is based on open() flags.

## How it works

1. **Fork:** the child installs a seccomp-BPF filter that triggers ptrace stops only for file-related syscalls (open, stat, rename, unlink, mkdir, close, dup, sendfile, chmod, etc.), then execs the target command. High-volume but low-information syscalls (read, write, mmap, getdents, ftruncate) are **not** intercepted.
2. **Event loop:** the parent runs a `waitpid` loop, dispatching by event type. Syscalls that only need entry args (stat, truncate, chmod, sendfile) resume immediately with `ptrace::cont`. Syscalls that need the return value (open, dup, rename, unlink, mkdir) use `ptrace::syscall` to also catch the exit. `close()` only waits for exit when the fd is tracked (skipping untracked pipe/socket fds).
3. **Read/write inference from open() flags:** since `read()` and `write()` are not intercepted, reads are inferred from O_RDONLY and O_RDWR flags at `open()` exit; writes from O_WRONLY, O_RDWR, O_TRUNC, O_CREAT flags. This is correct because a file can only be read/written if opened with the corresponding flags.
4. **Path resolution:** file descriptors are resolved to paths via `/proc/<pid>/fd/<fd>` and cached. Path-based syscalls are resolved through `/proc/<pid>/root` and `/proc/<pid>/cwd`.
5. **Pre-write hash (`--hash`):** files are hashed through `/proc/<pid>/fd/<fd>` at `open()` exit (while the tracee is paused). Each inode is hashed at most once. O_TRUNC hashing happens at `open()` *entry* (before the kernel truncates).
6. **Snapshot (`--snapshot-dir`):** at the same ptrace pause used for hashing, the file is copied to `<dir>/files/<encoded-path>` before the write proceeds. Destructive operations (rename, unlink, rmdir) are snapshotted at syscall *entry*, before the kernel acts. Metadata changes capture mode/uid/gid/mtime via `lstat`. A `manifest.json` is written atomically at the end.
7. **SIGTERM safety:** a signal handler sets a flag; the `waitpid` call returns `EINTR`, the loop breaks, and the manifest is written before the tracer exits.
