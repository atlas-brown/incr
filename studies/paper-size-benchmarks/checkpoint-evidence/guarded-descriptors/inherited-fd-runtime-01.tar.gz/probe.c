#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
int main(int n,char **v){int fd=atoi(v[2]); char c='x'; if(!strcmp(v[1],"read")){if(read(fd,&c,1)!=1)return 2;} else if(!strcmp(v[1],"pread")){if(pread(fd,&c,1,0)!=1)return 3;} else if(!strcmp(v[1],"dup")){int d=dup(fd);if(d<0||read(d,&c,1)!=1)return 4;} else if(!strcmp(v[1],"mmap")){char *p=mmap(0,1,PROT_READ,MAP_PRIVATE,fd,0);if(p==MAP_FAILED)return 5;c=*p;munmap(p,1);} else if(!strcmp(v[1],"fork")){if(!fork()){if(read(fd,&c,1)!=1)_exit(6);write(1,&c,1);_exit(0);}int s;wait(&s);return WEXITSTATUS(s);} write(1,&c,1);return 0;}
