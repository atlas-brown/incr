# Study unannotated-paper-final-01

Suite: paper. Profile: paper.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

186/276 invocations; 186 valid. Complete: False.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 52 | 7.192× | 3.684× | 28.958× |
| original | 52 | 1.770× | 1.334× | 18.783× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 40.875 | 109.397 | 27.573 | 0.374× | 1.482× |
| word-freq | 10.607 | 5.955 | 4.038 | 1.781× | 2.626× |
| nlp-ngrams | 57.374 | 66.345 | 50.157 | 0.865× | 1.144× |
| poet | 200.527 | 82.010 | 53.191 | 2.445× | 3.770× |
| nlp-uppercase | 30.916 | 27.029 | 23.244 | 1.144× | 1.330× |
| covid | 38.831 | 27.113 | 21.060 | 1.432× | 1.844× |
| nginx-analysis | 222.810 | 58.600 | 40.690 | 3.802× | 5.476× |
| spell | 638.629 | 208.385 | 210.770 | 3.065× | 3.030× |
| bio | 289.967 | 263.285 | 299.025 | 1.101× | 0.970× |
| weather | 45.787 | 16.733 | 17.256 | 2.736× | 2.653× |
| beginner | pending | pending | pending | pending | pending |
| unixfun | pending | pending | pending | pending | pending |
| dpt | pending | pending | pending | pending | pending |

Historical comparison: 38/124 matched version/mode timings differ by more than 2× and require review. Actual input sizes, annotation policy and environment must be reconciled before attributing differences.

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
