# Study replay-final-paper-01

Suite: paper. Profile: paper.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

749/828 invocations; 748 valid. Complete: False.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 69 | 6.081× | 3.280× | 28.578× |
| original | 69 | 1.685× | 1.304× | 20.024× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 40.826 | 111.346 | 27.458 | 0.367× | 1.487× |
| word-freq | 10.763 | 5.990 | 4.257 | 1.797× | 2.529× |
| nlp-ngrams | 58.883 | 64.217 | 50.267 | 0.917× | 1.171× |
| poet | 189.533 | 82.028 | 53.443 | 2.311× | 3.546× |
| nlp-uppercase | 32.590 | 26.946 | 23.525 | 1.209× | 1.385× |
| covid | 39.070 | 27.623 | 21.364 | 1.414× | 1.829× |
| nginx-analysis | 224.967 | 58.733 | 41.190 | 3.830× | 5.462× |
| spell | 636.343 | 207.119 | 208.168 | 3.072× | 3.057× |
| bio | 286.738 | 262.009 | 168.186 | 1.094× | 1.705× |
| weather | 46.894 | 16.257 | 17.194 | 2.885× | 2.727× |
| beginner | 173.355 | 78.073 | 90.496 | 2.220× | 1.916× |
| unixfun | 98.515 | 109.647 | 112.009 | 0.898× | 0.880× |
| dpt | pending | pending | pending | pending | pending |

Historical comparison: 57/174 matched version/mode timings differ by more than 2× and require review. Actual input sizes, annotation policy and environment must be reconciled before attributing differences.

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
