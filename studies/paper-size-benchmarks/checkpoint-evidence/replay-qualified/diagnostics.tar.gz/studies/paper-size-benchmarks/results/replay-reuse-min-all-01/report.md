# Study replay-reuse-min-all-01

Suite: paper. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

276/276 invocations; 276 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 78 | 0.859× | 0.349× | 12.252× |
| original | 78 | 8.945× | 5.772× | 38.609× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 1.990 | 15.435 | 1.967 | 0.129× | 1.012× |
| word-freq | 3.427 | 3.650 | 1.525 | 0.939× | 2.248× |
| nlp-ngrams | 0.072 | 11.670 | 0.540 | 0.006× | 0.134× |
| poet | 0.061 | 3.750 | 0.214 | 0.016× | 0.286× |
| nlp-uppercase | 0.030 | 3.436 | 0.397 | 0.009× | 0.074× |
| covid | 0.111 | 5.286 | 0.340 | 0.021× | 0.327× |
| nginx-analysis | 0.485 | 13.271 | 3.972 | 0.037× | 0.122× |
| spell | 0.169 | 5.102 | 0.599 | 0.033× | 0.283× |
| bio | 2.507 | 47.260 | 3.461 | 0.053× | 0.724× |
| weather | 0.035 | 2.167 | 0.137 | 0.016× | 0.256× |
| beginner | 0.157 | 6.976 | 0.595 | 0.022× | 0.264× |
| unixfun | 0.052 | 4.844 | 0.284 | 0.011× | 0.181× |
| dpt | 602.944 | 295.496 | 271.287 | 2.040× | 2.223× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
