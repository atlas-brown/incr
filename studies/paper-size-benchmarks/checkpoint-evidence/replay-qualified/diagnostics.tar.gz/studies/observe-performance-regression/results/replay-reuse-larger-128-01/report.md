# Study replay-reuse-larger-128-01

Suite: paper. Profile: scaled.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

84/84 invocations; 84 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 10 | 6.422× | 3.853× | 20.201× |
| original | 10 | 1.552× | 1.499× | 2.192× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| word-freq | 47.019 | 19.186 | 18.011 | 2.451× | 2.611× |
| poet | 104.137 | 34.696 | 30.831 | 3.001× | 3.378× |
| covid | 13.095 | 13.189 | 7.173 | 0.993× | 1.826× |
| weather | 6.087 | 5.537 | 2.610 | 1.099× | 2.332× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
