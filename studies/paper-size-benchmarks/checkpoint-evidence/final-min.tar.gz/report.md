# Study final-cleanup-min-01

Suite: paper. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

246/246 invocations; 246 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 69 | 0.586× | 0.256× | 18.002× |
| original | 69 | 9.542× | 6.884× | 27.213× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 1.946 | 15.281 | 1.967 | 0.127× | 0.990× |
| word-freq | 3.611 | 3.229 | 1.499 | 1.118× | 2.410× |
| nlp-ngrams | 0.065 | 11.482 | 0.570 | 0.006× | 0.114× |
| poet | 0.061 | 3.696 | 0.201 | 0.017× | 0.305× |
| nlp-uppercase | 0.031 | 3.914 | 0.317 | 0.008× | 0.096× |
| covid | 0.106 | 4.792 | 0.302 | 0.022× | 0.351× |
| nginx-analysis | 0.450 | 12.845 | 3.944 | 0.035× | 0.114× |
| spell | 0.183 | 5.035 | 0.610 | 0.036× | 0.301× |
| bio | 2.542 | 45.401 | 4.705 | 0.056× | 0.540× |
| weather | 0.034 | 2.945 | 0.138 | 0.012× | 0.249× |
| beginner | 0.159 | 6.981 | 0.576 | 0.023× | 0.276× |
| unixfun | 0.053 | 4.641 | 0.272 | 0.011× | 0.195× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
