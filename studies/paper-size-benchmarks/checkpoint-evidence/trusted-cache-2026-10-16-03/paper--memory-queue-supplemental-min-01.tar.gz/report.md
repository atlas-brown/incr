# Study memory-queue-supplemental-min-01

Suite: supplemental. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

15/15 invocations; 15 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 2 | 0.399× | 0.285× | 0.677× |
| original | 2 | 2.155× | 2.055× | 2.805× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| web-search | 2.029 | 10.933 | 2.094 | 0.186× | 0.969× |
| weather-tufte | 6.947 | 18.050 | 10.587 | 0.385× | 0.656× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
