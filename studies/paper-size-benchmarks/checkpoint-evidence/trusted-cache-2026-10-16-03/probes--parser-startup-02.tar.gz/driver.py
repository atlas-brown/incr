import json,os,shutil,statistics,sys,tempfile
from pathlib import Path
root=Path.cwd();sys.path[:0]=[str(root/'studies/paper-size-benchmarks/harness'),str(root/'studies/observe-performance-regression/harness')]
from common import WORK,atomic_json,remove_owned,supervise,file_hash
from study import lock
from provenance import fingerprint,verify
with lock():
 result=root/'studies/observe-performance-regression/results/parser-startup-02';result.mkdir()
 fingerprint(root,result,Path(__file__))
 old=root/'studies/observe-performance-regression/.work/parser-before/insert.py'
 shutil.copy2(old,result/'insert-before.py');old=result/'insert-before.py';old_hash=file_hash(old)
 owned=Path(tempfile.mkdtemp(prefix='parser-probe-',dir=WORK));rows=[]
 try:
  env={key:os.environ[key] for key in ('HOME','USER','PATH') if key in os.environ};env.update(PYTHONPATH=str(root/'src/scripts'),LC_ALL='C',PYTHONDONTWRITEBYTECODE='1')
  worker='import json,subprocess,sys,time;start=time.perf_counter();p=subprocess.Popen(sys.argv[2:],close_fds=True);status=p.wait();open(sys.argv[1],"w").write(json.dumps({"elapsed_sec":time.perf_counter()-start}));sys.exit(status)'
  reference=None
  for repetition in range(12):
   for mode in (('before','after') if repetition%2==0 else ('after','before')):
    capture=owned/'capture'
    if capture.exists():remove_owned(capture)
    timing=owned/'timing.json'
    script=old if mode=='before' else root/'src/scripts/insert.py'
    argv=[str(root/'qualification/.venv/bin/python'),str(script),str(root/'evaluation/benchmarks/word-freq/scripts/wf.sh'),'--sys-path',str(root/'target/release/incr'),'--observe-path',str(root.parent/'observe/target/release/observe')]
    row=supervise([sys.executable,'-c',worker,str(timing),*argv],cwd=root,env=env,capture=capture,timeout=10,reserve=8*1024**3,budget=32*1024**3)
    actual=[row['returncode'],row['stdout_sha256'],row['stderr_sha256']]
    if reference is None:reference=actual
    row.update(mode=mode,repetition=repetition,command_elapsed_sec=json.loads(timing.read_text())['elapsed_sec'],valid=not row['failure'] and actual==reference and row['returncode']==0)
    rows.append(row);atomic_json(result/'measurements.json',rows)
  verify(root,result,Path(__file__))
  assert file_hash(old)==old_hash
  summary={'valid':all(row['valid'] for row in rows),'samples':len(rows),'median_sec':{mode:statistics.median(row['command_elapsed_sec'] for row in rows if row['mode']==mode) for mode in ('before','after')}}
  atomic_json(result/'summary.json',summary);shutil.copy2(__file__,result/'driver.py');print(summary)
 finally:remove_owned(owned)
