# Study replay-reuse-min-bio-02

Suite: paper. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

21/21 invocations; 21 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 6 | 1.099× | 0.889× | 2.086× |
| original | 6 | 16.266× | 12.921× | 46.574× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| bio | 2.892 | 46.798 | 3.631 | 0.062× | 0.796× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
