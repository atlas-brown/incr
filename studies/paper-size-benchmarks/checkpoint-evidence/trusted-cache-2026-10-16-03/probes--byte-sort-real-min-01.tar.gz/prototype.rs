// Diagnostic only: plain C-locale GNU-sort semantics on bounded inputs.
use std::io::{self, Read, Write};
fn main() -> io::Result<()> {
    let mut data = Vec::new();
    io::stdin().take(64 * 1024 * 1024 + 1).read_to_end(&mut data)?;
    if data.len() > 64 * 1024 * 1024 { return Err(io::Error::other("diagnostic input limit")); }
    let mut records: Vec<(u32, u32)> = Vec::new();
    let mut start = 0;
    for (index, &byte) in data.iter().enumerate() {
        if byte == b'\n' {
            if records.len() >= 8 * 1024 * 1024 { return Err(io::Error::other("diagnostic record limit")); }
            records.push((start as u32, index as u32)); start = index + 1;
        }
    }
    if start < data.len() { records.push((start as u32, data.len() as u32)); }
    records.sort_unstable_by(|&(a,b), &(c,d)| data[a as usize..b as usize].cmp(&data[c as usize..d as usize]));
    let stdout = io::stdout();
    let mut output = io::BufWriter::with_capacity(65536, stdout.lock());
    for (start, end) in records {
        output.write_all(&data[start as usize..end as usize])?;
        output.write_all(b"\n")?;
    }
    output.flush()
}
