# Study native-transform-min-01

Profile: min.
Native shell transformation: enabled, with Python fallback.

36/36 invocations; 36 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 9 | 0.337× | 0.321× | 0.468× |
| original | 9 | 2.892× | 2.884× | 3.344× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
