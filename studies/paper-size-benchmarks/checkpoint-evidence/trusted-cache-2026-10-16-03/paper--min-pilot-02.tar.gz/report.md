# Study min-pilot-02

Profile: min.

27/27 invocations; 27 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 7 | 1.268× | 0.716× | 5.812× |
| original | 7 | 2.429× | 1.808× | 6.114× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
