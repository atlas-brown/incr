import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path('/users/jxia3/atlas/incr')
DOSSIER=ROOT/'studies/paper-size-benchmarks/results/unannotated-checkpoint-01'
BASH=ROOT/'studies/bash-parity-audit-2026-10-08'
source_paths=[ROOT/'incr.sh',ROOT/'src/scripts/insert.py',ROOT/'target/release/incr',ROOT.parent/'observe/target/release/observe']
source_paths += sorted((ROOT/'studies/paper-size-benchmarks/harness').glob('*.py'))
source_paths += sorted((BASH/'harness').glob('*.py'))
source_paths += [BASH/'corpus-provenance.json',BASH/'corpus-provenance-5.1.16.json']
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
active_stage='starting'
def record(state,stage,**extra):
    value=dict(state=state,stage=stage,pid=os.getpid(),updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,**extra)
    pending=DOSSIER/'qualification-queue.json.pending';pending.write_text(json.dumps(value,indent=2)+'\n');pending.replace(DOSSIER/'qualification-queue.json')
def step(label,command):
    global active_stage
    active_stage=label
    for path,digest in sources.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:raise RuntimeError('Source changed before '+label+': '+path)
    log=DOSSIER/(label+'.log')
    if log.exists():raise RuntimeError('Preserve existing stage evidence: '+str(log))
    record('running',label,command=command,log=str(log))
    with log.open('w') as stream:
        subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
    record('passed',label,log=str(log))
def require_bash(directory,count):
    value=json.loads((directory/'summary.json').read_text())
    if (not value['complete'] or value['groups']!=count or value['cold_matches']!=count or value['warm_matches']!=count or value['failures'] or value['regressions'].keys()!={'live','final'}):
        raise RuntimeError('Incomplete Bash qualification: '+str(directory))
try:
    current=BASH/'results/function-locations-system-bash-full-01'
    step('function-locations-system-bash-full',[str(BASH/'run.sh'),'--shell','/bin/bash','--bash-build',str(ROOT/'qualification/.work/bash-5.1.16'),'--corpus-provenance',str(BASH/'corpus-provenance-5.1.16.json'),'--native-transform','--assume-directory-access','--output',str(current)])
    require_bash(current,82)
    step('function-locations-system-independent-analysis',[sys.executable,str(BASH/'harness/analyze.py'),str(current)])
    default=BASH/'results/function-locations-defaults-full-01'
    step('function-locations-default-bash-full',[str(BASH/'run.sh'),'--output',str(default)])
    require_bash(default,83)
    step('function-locations-default-independent-analysis',[sys.executable,str(BASH/'harness/analyze.py'),str(default)])
    step('general-128-mib',[sys.executable,'studies/observe-performance-regression/harness/scale.py','--id','general-unannotated-128-01','--only','word-freq,poet,covid,weather','--mib','128','--repetitions','2','--native-transform','--assume-directory-access'])
    step('dpt-minimum',[sys.executable,'studies/paper-size-benchmarks/harness/study.py','run','--profile','min','--only','dpt','--run-id','general-unannotated-dpt-min-01','--repetitions','1','--native-transform','--assume-directory-access'])
    step('dpt-independent-monitor',[sys.executable,'studies/paper-size-benchmarks/harness/monitor.py','studies/paper-size-benchmarks/results/general-unannotated-dpt-min-01'])
    monitor=json.loads((ROOT/'studies/paper-size-benchmarks/results/general-unannotated-dpt-min-01/monitor.json').read_text())
    if monitor['health']!='ok':raise RuntimeError('DPT terminal monitor attention')
    record('complete','qualification-queue')
except BaseException as error:
    record('failed',active_stage,error=repr(error))
    raise
