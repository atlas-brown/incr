import datetime, hashlib, json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path('/users/jxia3/atlas/incr')
DOSSIER=ROOT/'studies/paper-size-benchmarks/results/unannotated-checkpoint-01'
BASH=ROOT/'studies/bash-parity-audit-2026-10-08'
PID=2065884
start=Path(f'/proc/{PID}/stat').read_text().split()[21]
source_paths=[ROOT/'incr.sh', ROOT/'src/scripts/insert.py', ROOT/'target/release/incr',ROOT.parent/'observe/target/release/observe']
source_paths += sorted((ROOT/'studies/paper-size-benchmarks/harness').glob('*.py'))
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
def record(state,stage,**extra):
    value=dict(state=state,stage=stage,pid=os.getpid(),updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,**extra)
    pending=DOSSIER/'qualification-queue.json.pending';pending.write_text(json.dumps(value,indent=2)+'\n');pending.replace(DOSSIER/'qualification-queue.json')
def step(label,command,env=None):
    for path,digest in sources.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:raise RuntimeError('Runtime source changed before '+label+': '+path)
    record('running',label,command=command)
    log=DOSSIER/(label+'.log')
    with log.open('w') as stream:
        subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
    record('passed',label,log=str(log))
try:
    record('waiting','system-bash-full',waiting_pid=PID,waiting_starttime=start)
    while True:
        try:
            if Path(f'/proc/{PID}/stat').read_text().split()[21]!=start:break
        except FileNotFoundError:break
        time.sleep(5)
    current=BASH/'results/parser-fallback-system-bash-full-01'
    summary=json.loads((current/'summary.json').read_text())
    if not summary['complete'] or summary['groups']!=83 or summary['regressions'].keys()!={'live','final'}:raise RuntimeError('System Bash suite incomplete')
    step('strict-comparator-tests',[sys.executable,'-m','unittest','discover','-s',str(BASH/'harness'),'-p','test_*.py','-v'])
    step('study-harness-tests',[sys.executable,'-m','unittest','discover','-s','studies/paper-size-benchmarks/harness','-p','test_*.py','-v'])
    step('supplemental-harness-tests',[sys.executable,'-m','unittest','discover','-s','studies/paper-size-benchmarks/harness','-p','test_*.py','-v'],env=dict(os.environ,INCR_BENCH_SUITE='supplemental'))
    step('system-bash-independent-analysis',[sys.executable,str(BASH/'harness/analyze.py'),str(current)])
    default=BASH/'results/parser-fallback-defaults-full-01'
    step('default-bash-full',[str(BASH/'run.sh'),'--output',str(default)])
    step('default-bash-independent-analysis',[sys.executable,str(BASH/'harness/analyze.py'),str(default)])
    step('general-128-mib',[sys.executable,'studies/observe-performance-regression/harness/scale.py','--id','general-unannotated-128-01','--only','word-freq,poet,covid,weather','--mib','128','--repetitions','2','--native-transform','--assume-directory-access'])
    step('dpt-minimum',[sys.executable,'studies/paper-size-benchmarks/harness/study.py','run','--profile','min','--only','dpt','--run-id','general-unannotated-dpt-min-01','--repetitions','1','--native-transform','--assume-directory-access'])
    step('dpt-independent-monitor',[sys.executable,'studies/paper-size-benchmarks/harness/monitor.py','studies/paper-size-benchmarks/results/general-unannotated-dpt-min-01'])
    monitor=json.loads((ROOT/'studies/paper-size-benchmarks/results/general-unannotated-dpt-min-01/monitor.json').read_text())
    if monitor['health']!='ok':raise RuntimeError('DPT terminal monitor attention')
    record('complete','qualification-queue')
except BaseException as error:
    record('failed','queue',error=repr(error))
    raise
