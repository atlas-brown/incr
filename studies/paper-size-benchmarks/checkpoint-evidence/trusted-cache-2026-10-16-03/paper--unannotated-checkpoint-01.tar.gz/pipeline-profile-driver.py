"""Instrumented diagnostic only; exact workload oracle, separate from primary numbers."""
from pathlib import Path
import datetime, json, os, sys, time
ROOT=Path('/users/jxia3/atlas/incr')
DOSSIER=ROOT/'studies/paper-size-benchmarks/results/unannotated-checkpoint-01'
WAIT_PID=2223413
wait_start=Path(f'/proc/{WAIT_PID}/stat').read_text().split()[21]
status_path=DOSSIER/'pipeline-profile-queue.json'
def status(state,**extra):
    data=dict(state=state,pid=os.getpid(),updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra)
    pending=status_path.with_suffix('.pending');pending.write_text(json.dumps(data,indent=2)+'\n');pending.replace(status_path)
try:
    status('waiting',waiting_pid=WAIT_PID)
    while True:
        try:
            if Path(f'/proc/{WAIT_PID}/stat').read_text().split()[21]!=wait_start:break
        except FileNotFoundError:break
        time.sleep(5)
    prior=json.loads((DOSSIER/'qualification-queue.json').read_text())
    if prior['state']!='complete':raise RuntimeError('Qualification queue did not finish successfully')
    sys.path.insert(0,str(ROOT/'studies/observe-performance-regression/harness'))
    import scale
    from provenance import fingerprint, verify
    from types import SimpleNamespace
    import tempfile, shutil
    import study
    from common import WORK, atomic_json, file_hash, remove_owned
    with study.lock():
        run=ROOT/'studies/observe-performance-regression/results/general-unannotated-profile-128-01'
        run.mkdir(parents=True,exist_ok=False)
        shutil.copy2(Path(__file__),run/'diagnostic-driver.py')
        fingerprint(ROOT,run,Path(__file__))
        status('running',run=str(run))
        args=SimpleNamespace(profile='scaled',only='word-freq',repetitions=1,modes=('bash','original','observe'),annotations=False,reserve_gib=8,work_budget_gib=32,native_transform=True,assume_directory_access=True)
        atomic_json(run/'configuration.json',dict(vars(args),started=study.now(),profiling=True,scope='Instrumented phase diagnostic only; not primary performance samples'))
        build=study.freeze(run)
        owned=Path(tempfile.mkdtemp(prefix='pipeline-profile-',dir=WORK))
        profiles=run/'profiles';profiles.mkdir()
        base_environment=study.environment
        def profiled_environment(*arguments,**keywords):
            return dict(base_environment(*arguments,**keywords),INCR_PROFILE_DIR=str(profiles))
        study.environment=profiled_environment
        try:
            data=owned/'word-freq'
            recipe=scale.replicate(WORK/'data/min/word-freq/inputs/text.txt',data/'inputs/text.txt',128*1024**2)
            primary=json.loads((ROOT/'studies/observe-performance-regression/results/general-unannotated-128-01/inputs/word-freq.json').read_text())
            if recipe['sha256']!=primary['sha256'] or recipe['bytes']!=primary['bytes']:raise RuntimeError('Profile input differs from primary larger diagnostic')
            atomic_json(run/'inputs/word-freq.json',dict(recipe,input_bytes=recipe['bytes'],models=[]))
            benchmark=dict(study.selected('word-freq')[0],timeout_scaled=300)
            references={}
            for mode in args.modes:
                sequence=study.execute_sequence(run,benchmark,mode,0,args,build,data,references)
                study.report(run)
                if not sequence['valid']:raise RuntimeError('Profile output validation failed: '+mode)
            records=[]
            for path in sorted(profiles.glob('*.json')):
                item=json.loads(path.read_text());item['file']=path.name
                item['arguments']=[bytes(a).decode('utf-8',errors='surrogateescape') for a in item['arguments_bytes']]
                records.append(item)
            if not records:raise RuntimeError('No candidate phase records')
            atomic_json(run/'phase-records.json',{'scope':'Nested phase timings and concurrently executing processes must not be summed as wall time. Replay denotes a cache hit; capture_save denotes a miss.','records':records})
            summary=study.report(run)
            if not summary['complete']:raise RuntimeError('Incomplete profile diagnostic')
            verify(ROOT,run,Path(__file__))
            atomic_json(run/'status.json',{'state':'complete','updated':study.now(),'valid_invocations':summary['valid_invocations']})
            status('complete',run=str(run),profile_records=len(records))
        finally:
            study.environment=base_environment
            remove_owned(owned)
except BaseException as error:
    status('failed',error=repr(error))
    raise
