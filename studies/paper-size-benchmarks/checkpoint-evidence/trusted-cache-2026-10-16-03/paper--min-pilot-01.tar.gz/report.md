# Study min-pilot-01

Profile: min.

27/27 invocations; 27 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 7 | 0.726× | 0.715× | 1.029× |
| original | 7 | 2.970× | 1.758× | 7.916× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
