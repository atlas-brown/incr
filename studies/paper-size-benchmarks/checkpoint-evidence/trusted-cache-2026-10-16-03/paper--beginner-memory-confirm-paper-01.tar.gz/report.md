# Study beginner-memory-confirm-paper-01

Suite: paper. Profile: paper.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

42/42 invocations; 42 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 12 | 3.761× | 3.450× | 5.324× |
| original | 12 | 1.117× | 1.093× | 1.451× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| beginner | 195.907 | 77.281 | 71.419 | 2.535× | 2.743× |

Historical comparison: 16/28 matched version/mode timings differ by more than 2× and require review. Actual input sizes, annotation policy and environment must be reconciled before attributing differences.

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
