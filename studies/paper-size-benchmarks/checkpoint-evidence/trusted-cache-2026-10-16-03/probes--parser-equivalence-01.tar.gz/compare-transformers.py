import importlib.util,json,sys,types
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'src/scripts'))
def load(name,path,previous=False):
 module=types.ModuleType(name);module.__file__=str(path);sys.modules[name]=module
 source=path.read_text()
 if previous: source=source.replace('[*prefix_words, *transformed.arguments]', '[*copy.deepcopy(prefix_words), *transformed.arguments]')
 exec(compile(source,str(path),'exec'),module.__dict__)
 return module
old=load('insert_before',root/'studies/observe-performance-regression/.work/parser-before/insert.py',True)
new=load('insert_after',root/'src/scripts/insert.py')
rows=[]
for bench in json.loads((root/'studies/paper-size-benchmarks/manifest.json').read_text())['benchmarks']:
 for script in bench['scripts']:
  path=root/'evaluation/benchmarks'/bench['name']/'scripts'/script
  args=types.SimpleNamespace(path=str(path),bash=False,identity=False,incr_command='/example/bin/incr',try_path='/example/try.sh',cache_path='/example/cache',observe_path='/example/observe')
  answers=[]
  for module in (old,new):
   try: answers.append(('ok',module.transform_script(args)))
   except Exception as error: answers.append((type(error).__name__,str(error)))
  rows.append({'family':bench['name'],'script':script,'equal':answers[0]==answers[1],'status':answers[1][0]})
result={'valid':all(row['equal'] and row['status']=='ok' for row in rows),'samples':len(rows),'rows':rows}
(root/'studies/observe-performance-regression/.work/parser-equivalence.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['valid'],result['samples']);sys.exit(0 if result['valid'] else 1)
