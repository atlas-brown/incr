# Study scaled-eight-01

Profile: scaled.

36/36 invocations; 36 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 9 | 2.297× | 1.189× | 8.164× |
| original | 9 | 1.056× | 1.002× | 2.198× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
