# Study scaled-thirtytwo-native-01

Profile: scaled.
Native shell transformation: enabled, with Python fallback.

72/72 invocations; 72 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 9 | 5.349× | 3.002× | 17.155× |
| original | 9 | 1.239× | 1.157× | 2.737× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
