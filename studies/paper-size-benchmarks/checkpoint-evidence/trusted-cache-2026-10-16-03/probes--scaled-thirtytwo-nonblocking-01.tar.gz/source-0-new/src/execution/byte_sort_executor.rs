//! Bounded specialization of plain byte-order stdin sorting.
//!
//! In C/POSIX locale, plain sort orders newline-delimited records by unsigned
//! bytes and terminates the last record with a newline. No option parsing,
//! numeric/locale comparison, or external file effects are reproduced here.
//! Inputs exceeding either bound resume the existing traced GNU executor with
//! the already-consumed prefix, preserving all bytes and normal backpressure.
use anyhow::Result;
use std::collections::{HashMap, HashSet};
use std::fs::File;
use std::io::{self, ErrorKind, Read, Write};
use std::path::Path;
use xxhash_rust::xxh3::Xxh3;

use crate::cache::{CacheData, batch_cache::CacheCursor};
use crate::command::Command;
use crate::config::{BUFFER_SIZE, Config, TraceType};
use crate::execution::{dependency, run, stream_executor};
use crate::ops::{self, ExitCode};

const MAX_BYTES: usize = 64 * 1024 * 1024;
const MAX_RECORDS: usize = 8 * 1024 * 1024;
const _: () = assert!(MAX_BYTES <= u32::MAX as usize && MAX_RECORDS <= u32::MAX as usize);

enum Collected {
    Complete {
        bytes: Vec<u8>,
        records: usize,
        hash: u64,
    },
    Fallback(Vec<u8>),
}

pub(crate) fn eligible(command: &Command) -> bool {
    command.standard_tool
        && command.name == "sort"
        && (command.arguments.is_empty()
            || command.arguments.as_slice() == ["-u"]
            || command.arguments.as_slice() == ["--unique"])
        && matches!(
            command.environment.get("LC_ALL").map(String::as_str),
            Some("C" | "POSIX")
        )
        && !command
            .environment
            .keys()
            .any(|name| name.starts_with("LD_") || name == "GLIBC_TUNABLES")
        && !Path::new("/etc/ld.so.preload").exists()
}

fn collect(mut source: impl Read, max_bytes: usize, max_records: usize) -> Result<Collected> {
    // Reserve virtual address space once; physical pages are committed only as
    // input arrives. Avoid Vec doubling beyond the bound when detecting overflow.
    let mut bytes = Vec::new();
    if bytes.try_reserve_exact(max_bytes + BUFFER_SIZE).is_err() {
        return Ok(Collected::Fallback(bytes));
    }
    let mut records = 0;
    let mut hash = Xxh3::new();
    let mut buffer = [0; BUFFER_SIZE];
    loop {
        let length = match source.read(&mut buffer) {
            Ok(0) => break,
            Ok(length) => length,
            Err(error) if error.kind() == ErrorKind::Interrupted => continue,
            Err(error) => return Err(error.into()),
        };
        records += buffer[..length].iter().filter(|&&byte| byte == b'\n').count();
        bytes.extend_from_slice(&buffer[..length]);
        if bytes.len() > max_bytes || records > max_records {
            return Ok(Collected::Fallback(bytes));
        }
        hash.update(&buffer[..length]);
    }
    if bytes.last().is_some_and(|&byte| byte != b'\n') {
        records += 1;
    }
    if records > max_records {
        return Ok(Collected::Fallback(bytes));
    }
    Ok(Collected::Complete {
        bytes,
        records,
        hash: hash.digest(),
    })
}

enum SortedRecords<'a> {
    Plain(Vec<(u32, u32)>),
    Counted(Vec<(&'a [u8], u32)>),
}

fn counted_records(bytes: &[u8], max_unique: usize) -> Option<Vec<(&[u8], u32)>> {
    // Standard randomized hashing compares the complete bytes, including NULs.
    // The final lexical sort makes output independent of hash iteration order.
    let mut counts: HashMap<&[u8], u32> = HashMap::new();
    for (index, record) in bytes.split_inclusive(|&byte| byte == b'\n').enumerate() {
        let line = record.strip_suffix(b"\n").unwrap_or(record);
        if let Some(count) = counts.get_mut(line) {
            *count += 1;
        } else {
            if counts.len() >= max_unique {
                return None;
            }
            counts.try_reserve(1).ok()?;
            counts.insert(line, 1);
        }
        // Avoid building a large dictionary for mostly unique/already sorted
        // records. The sample changes strategy, never sorting semantics.
        if index == 1023 && counts.len() > 768 {
            return None;
        }
    }
    let mut records = Vec::new();
    records.try_reserve_exact(counts.len()).ok()?;
    records.extend(counts);
    records.sort_unstable_by(|a, b| a.0.cmp(b.0));
    Some(records)
}

fn sort_records(
    bytes: &[u8],
    count: usize,
) -> std::result::Result<SortedRecords<'_>, std::collections::TryReserveError> {
    // 512K dictionary entries plus its compact output list and bounded input
    // stay below the plain index path's ~128 MiB payload/index bound. The map
    // is dropped before allocating a plain index if this attempt is declined.
    if count >= 1024
        && let Some(records) = counted_records(bytes, 512 * 1024)
    {
        return Ok(SortedRecords::Counted(records));
    }
    let mut records = Vec::new();
    records.try_reserve_exact(count)?;
    let mut start = 0;
    for (index, &byte) in bytes.iter().enumerate() {
        if byte == b'\n' {
            records.push((start as u32, index as u32));
            start = index + 1;
        }
    }
    if start < bytes.len() {
        records.push((start as u32, bytes.len() as u32));
    }
    debug_assert_eq!(records.len(), count);
    records.sort_unstable_by(|&(a, b), &(c, d)| {
        bytes[a as usize..b as usize].cmp(&bytes[c as usize..d as usize])
    });
    Ok(SortedRecords::Plain(records))
}

fn write_sorted(
    bytes: &[u8],
    records: SortedRecords<'_>,
    unique: bool,
    mut output: impl Write,
) -> Result<()> {
    let mut emit = |line: &[u8], count: u32| -> io::Result<()> {
        for _ in 0..count {
            output.write_all(line)?;
            output.write_all(b"\n")?;
        }
        Ok(())
    };
    match records {
        SortedRecords::Plain(records) => {
            let mut previous = None;
            for (start, end) in records {
                let line = &bytes[start as usize..end as usize];
                if !unique || previous != Some(line) {
                    emit(line, 1)?;
                    previous = Some(line);
                }
            }
        }
        SortedRecords::Counted(records) => {
            for (line, count) in records {
                emit(line, if unique { 1 } else { count })?;
            }
        }
    }
    output.flush()?;
    Ok(())
}

pub(crate) fn execute(config: &Config, command: &Command) -> Result<ExitCode> {
    let input = ops::profile::measure("byte_sort_input", || {
        collect(io::stdin().lock(), MAX_BYTES, MAX_RECORDS)
    })?;
    let Collected::Complete { bytes, records, hash } = input else {
        let Collected::Fallback(prefix) = input else {
            unreachable!()
        };
        return stream_executor::execute_with_prefix(config, command, &prefix);
    };
    // This specialization has no file effects and needs no speculative
    // candidate index. Keep the original tracing config for every GNU fallback.
    let mut cache_config = config.clone();
    cache_config.trace_type = TraceType::Nothing;
    let cache = CacheCursor::from_hash(&cache_config, command, hash)?;
    cache.create_directory()?;
    if let Some(data) = cache.load_data()?
        && dependency::check_cache_valid(&cache, &data)?
    {
        drop(bytes);
        return run::replay(config, &cache, &data, &run::OutputMetadata::default());
    }
    let sorted = ops::profile::measure("byte_sort_sort", || sort_records(&bytes, records));
    let Ok(sorted) = sorted else {
        // Allocation pressure is a reason to use GNU sort's external-memory
        // implementation, not to abort or leave a partial answer behind.
        drop(cache);
        return stream_executor::execute_with_prefix(config, command, &bytes);
    };
    cache.clean()?;
    let output = io::BufWriter::with_capacity(BUFFER_SIZE, File::create(cache.get_stdout_file())?);
    ops::profile::measure("byte_sort_sort_write", || {
        write_sorted(&bytes, sorted, !command.arguments.is_empty(), output)
    })?;
    File::create(cache.get_stderr_file())?;
    // This implementation consumes only the keyed input bytes. It does not run
    // the external comparator or read locale files, loader configuration or TMPDIR.
    let data = CacheData {
        exit_code: 0,
        replay_barriers: Vec::new(),
        read_dependencies: HashMap::new(),
        write_outputs: HashSet::new(),
        compressed_output: false,
    };
    cache.save_data(&data)?;
    drop(bytes);
    run::replay(config, &cache, &data, &run::OutputMetadata::default())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    #[test]
    fn overflow_preserves_the_entire_consumed_prefix_and_remaining_input() -> Result<()> {
        struct Fragmented<'a>(Cursor<&'a [u8]>);
        impl Read for Fragmented<'_> {
            fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
                let length = bytes.len().min(2);
                self.0.read(&mut bytes[..length])
            }
        }
        for (input, max_bytes, max_records, remaining) in [
            (b"a\nb\nc\nlast".as_slice(), 3, 100, true),
            (b"a\nb\nc\nlast".as_slice(), 100, 2, true),
            (b"a\nb\nc\nlast".as_slice(), 100, 3, false),
        ] {
            let mut source = Fragmented(Cursor::new(input));
            let Collected::Fallback(mut prefix) = collect(&mut source, max_bytes, max_records)? else {
                panic!("expected fallback")
            };
            assert_eq!((source.0.position() as usize) < input.len(), remaining);
            source.read_to_end(&mut prefix)?;
            assert_eq!(prefix, input);
        }
        Ok(())
    }

    #[test]
    fn counting_preserves_duplicates_and_declines_unique_or_oversized_dictionaries() -> Result<()> {
        let input = b"z\n\0\xff\n\n".repeat(2048);
        let Collected::Complete { bytes, records, .. } = collect(Cursor::new(&input), input.len(), 10000)?
        else {
            panic!("unexpected fallback")
        };
        let sorted = sort_records(&bytes, records)?;
        assert!(matches!(&sorted, SortedRecords::Counted(_)));
        let mut actual = Vec::new();
        write_sorted(&bytes, sorted, false, &mut actual)?;
        let mut expected = b"\n".repeat(2048);
        expected.extend_from_slice(&b"\0\xff\n".repeat(2048));
        expected.extend_from_slice(&b"z\n".repeat(2048));
        assert_eq!(actual, expected);
        assert!(counted_records(&input, 2).is_none());
        let unique = (0..2048).map(|index| format!("{index}\n")).collect::<String>();
        assert!(counted_records(unique.as_bytes(), 10000).is_none());
        Ok(())
    }

    #[test]
    fn exact_bound_empty_and_unterminated_records() -> Result<()> {
        for (input, expected, records) in [
            (b"".as_slice(), b"".as_slice(), 0),
            (b"\n\n".as_slice(), b"\n\n".as_slice(), 2),
            (b"b\na".as_slice(), b"a\nb\n".as_slice(), 2),
            (b"\xff\n\0\n".as_slice(), b"\0\n\xff\n".as_slice(), 2),
        ] {
            let Collected::Complete {
                bytes,
                records: count,
                hash,
            } = collect(Cursor::new(input), input.len(), records)?
            else {
                panic!("unexpected fallback")
            };
            assert_eq!(hash, ops::data::hash_bytes(input));
            let mut output = Vec::new();
            write_sorted(&bytes, sort_records(&bytes, count)?, false, &mut output)?;
            assert_eq!(output, expected);
        }
        Ok(())
    }
}
