# Study scaled-thirtytwo-nonblocking-01

Profile: scaled.

48/48 invocations; 48 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 6 | 1.323× | 1.239× | 1.840× |
| original | 6 | 0.963× | 0.956× | 1.067× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
