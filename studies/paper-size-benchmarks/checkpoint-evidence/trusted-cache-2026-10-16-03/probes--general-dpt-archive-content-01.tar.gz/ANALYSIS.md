# General content-input diagnostic

This is a one-image, two-version diagnostic of the supplied real-model ZIP
extraction workflow, not a full-dataset or repeated performance estimate.
Annotations are disabled. All six outputs validate against native Bash;
`provenance-check.json` confirms unchanged guarded sources and binaries.

| Mode | First version (s) | Edited version (s) |
| --- | ---: | ---: |
| Bash | 59.325 | 58.164 |
| Original Incr | 72.124 | 0.616 |
| Incr + Observe | 69.770 | 0.175 |

Before the opt-in general content-input policy, the corresponding Observe edited
version took 16.323s in `general-dpt-archive-02`, versus original 0.631s. Identical
archive extraction changes ctime and caused needless classification recomputation.
The new candidate's warm segment and classify profiles explicitly record replay;
classify candidate validation takes 19.5ms, followed by 0.065ms replay. These
nested per-process phases must not be summed as end-to-end wall time.

The candidate's edited-version 3.52x improvement over original is a single-sample
observation. Cold model computation still dominates total sequence time. No
claim of a similarly large total-sequence speedup follows from this diagnostic.
Generic `general-archive-content-01` separately confirms that changed same-size
content at a preserved mtime invalidates the candidate, while the baseline's
historical mtime assumption returns stale bytes in that intentional fault probe.
