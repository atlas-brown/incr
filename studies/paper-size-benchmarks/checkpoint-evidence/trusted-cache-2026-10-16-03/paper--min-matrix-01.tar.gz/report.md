# Study min-matrix-01

Profile: min.

186/249 invocations; 185 valid. Complete: False.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 51 | 0.477× | 0.460× | 0.731× |
| original | 51 | 1.122× | 0.862× | 7.565× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
