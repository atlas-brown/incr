# Study general-min-01

Profile: min.
Native shell transformation: enabled, with Python fallback.

246/246 invocations; 246 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 69 | 0.494× | 0.260× | 11.792× |
| original | 69 | 3.880× | 2.728× | 17.165× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
