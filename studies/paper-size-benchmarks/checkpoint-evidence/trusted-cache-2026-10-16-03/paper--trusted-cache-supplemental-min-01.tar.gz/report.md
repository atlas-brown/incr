# Study trusted-cache-supplemental-min-01

Suite: supplemental. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

15/15 invocations; 15 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 2 | 0.432× | 0.336× | 0.703× |
| original | 2 | 2.489× | 2.313× | 3.408× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| web-search | 2.087 | 11.151 | 2.337 | 0.187× | 0.893× |
| weather-tufte | 7.017 | 18.669 | 10.267 | 0.376× | 0.683× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
