# Study memory-queue-min-all-01

Suite: paper. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

276/276 invocations; 276 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 78 | 0.843× | 0.353× | 10.407× |
| original | 78 | 9.061× | 5.778× | 47.060× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 1.978 | 15.534 | 1.899 | 0.127× | 1.042× |
| word-freq | 3.329 | 3.283 | 1.583 | 1.014× | 2.103× |
| nlp-ngrams | 0.070 | 12.165 | 0.557 | 0.006× | 0.126× |
| poet | 0.057 | 3.731 | 0.217 | 0.015× | 0.265× |
| nlp-uppercase | 0.028 | 3.531 | 0.303 | 0.008× | 0.094× |
| covid | 0.114 | 4.908 | 0.304 | 0.023× | 0.373× |
| nginx-analysis | 0.506 | 12.788 | 3.919 | 0.040× | 0.129× |
| spell | 0.183 | 5.290 | 0.622 | 0.035× | 0.294× |
| bio | 2.426 | 46.385 | 3.414 | 0.052× | 0.711× |
| weather | 0.032 | 2.144 | 0.143 | 0.015× | 0.223× |
| beginner | 0.154 | 7.017 | 0.587 | 0.022× | 0.263× |
| unixfun | 0.053 | 4.728 | 0.283 | 0.011× | 0.186× |
| dpt | 606.682 | 294.794 | 273.172 | 2.058× | 2.221× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
