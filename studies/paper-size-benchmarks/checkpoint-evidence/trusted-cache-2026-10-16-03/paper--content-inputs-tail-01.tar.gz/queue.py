import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path('/users/jxia3/atlas/incr')
DOSSIER=ROOT/'studies/paper-size-benchmarks/results/content-inputs-tail-01'
BASH=ROOT/'studies/bash-parity-audit-2026-10-08'
source_paths=[ROOT/'incr.sh',ROOT/'src/scripts/insert.py',ROOT/'target/release/incr',ROOT.parent/'observe/target/release/observe']
source_paths += sorted((ROOT/'studies/paper-size-benchmarks/harness').glob('*.py'))
source_paths += sorted((BASH/'harness').glob('*.py'))
source_paths += [BASH/'corpus-provenance.json',BASH/'corpus-provenance-5.1.16.json']
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
active_stage='starting'
def record(state,stage,**extra):
    value=dict(state=state,stage=stage,pid=os.getpid(),updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,**extra)
    pending=DOSSIER/'qualification-queue.json.pending';pending.write_text(json.dumps(value,indent=2)+'\n');pending.replace(DOSSIER/'qualification-queue.json')
def step(label,command):
    global active_stage
    active_stage=label
    for path,digest in sources.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:raise RuntimeError('Source changed before '+label+': '+path)
    log=DOSSIER/(label+'.log')
    if log.exists():raise RuntimeError('Preserve existing stage evidence: '+str(log))
    record('running',label,command=command,log=str(log))
    with log.open('w') as stream:
        subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
    record('passed',label,log=str(log))
def require_bash(directory,count):
    value=json.loads((directory/'summary.json').read_text())
    if (not value['complete'] or value['groups']!=count or value['cold_matches']!=count or value['warm_matches']!=count or value['failures'] or value['regressions'].keys()!={'live','final'}):
        raise RuntimeError('Incomplete Bash qualification: '+str(directory))
try:
    import time
    record('waiting','waiting-main-qualification',waiting_pid=2524647)
    while Path('/proc/2524647').exists(): time.sleep(5)
    prior=ROOT/'studies/paper-size-benchmarks/results/content-inputs-qualification-02/qualification-queue.json'
    if json.loads(prior.read_text())['state']!='complete':raise RuntimeError('Main qualification did not complete successfully')
    step('content-inputs-dpt-minimum',[sys.executable,'studies/paper-size-benchmarks/harness/study.py','run','--profile','min','--only','dpt','--run-id','content-inputs-dpt-min-01','--repetitions','1','--native-transform','--assume-directory-access','--content-validated-inputs'])
    step('content-inputs-dpt-three',[sys.executable,str(DOSSIER/'dpt-three-driver.py')])
    step('content-inputs-supplemental',[ '/usr/bin/env','INCR_BENCH_SUITE=supplemental',sys.executable,'studies/paper-size-benchmarks/harness/study.py','run','--profile','min','--only','web-search,weather-tufte','--run-id','content-inputs-supplemental-min-01','--repetitions','2','--native-transform','--assume-directory-access','--content-validated-inputs'])
    record('complete','qualification-tail')
except BaseException as error:
    record('failed',active_stage,error=repr(error))
    raise
