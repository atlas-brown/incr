fn byte_radix_sort(records: &mut [(u32,u32)], bytes: &[u8]) {
    const SMALL: usize = 64;
    const MAX_DEPTH: usize = 32;
    let mut pending = Vec::with_capacity(257 * MAX_DEPTH + 1);
    pending.push((0, records.len(), 0));
    while let Some((begin,end,depth)) = pending.pop() {
        let values = &mut records[begin..end];
        if values.len() <= SMALL || depth >= MAX_DEPTH {
            values.sort_unstable_by(|&(a,b), &(c,d)| bytes[a as usize+depth..b as usize].cmp(&bytes[c as usize+depth..d as usize]));
            continue;
        }
        let key = |(start,end): (u32,u32)| {
            let position = start as usize + depth;
            if position < end as usize { bytes[position] as usize + 1 } else { 0 }
        };
        let mut counts = [0usize;257];
        for &record in values.iter() { counts[key(record)] += 1; }
        let mut starts = [0usize;257];
        for bucket in 1..257 { starts[bucket] = starts[bucket-1] + counts[bucket-1]; }
        let mut next = starts;
        for bucket in 0..257 {
            let limit = starts[bucket]+counts[bucket];
            while next[bucket] < limit {
                let actual = key(values[next[bucket]]);
                if actual == bucket { next[bucket] += 1; }
                else {
                    debug_assert!(next[actual] < starts[actual]+counts[actual]);
                    values.swap(next[bucket],next[actual]);
                    next[actual] += 1;
                }
            }
        }
        for bucket in 1..257 {
            if counts[bucket] > 1 {
                pending.push((begin+starts[bucket], begin+starts[bucket]+counts[bucket], depth+1));
            }
        }
    }
}

// Diagnostic only: plain C-locale GNU-sort semantics on bounded inputs.
use std::io::{self, Read, Write};
fn main() -> io::Result<()> {
    let mut data = Vec::new();
    io::stdin().take(64 * 1024 * 1024 + 1).read_to_end(&mut data)?;
    if data.len() > 64 * 1024 * 1024 { return Err(io::Error::other("diagnostic input limit")); }
    let mut records: Vec<(u32, u32)> = Vec::new();
    let mut start = 0;
    for (index, &byte) in data.iter().enumerate() {
        if byte == b'\n' {
            if records.len() >= 8 * 1024 * 1024 { return Err(io::Error::other("diagnostic record limit")); }
            records.push((start as u32, index as u32)); start = index + 1;
        }
    }
    if start < data.len() { records.push((start as u32, data.len() as u32)); }
    byte_radix_sort(&mut records, &data);
    let stdout = io::stdout();
    let mut output = io::BufWriter::with_capacity(65536, stdout.lock());
    for (start, end) in records {
        output.write_all(&data[start as usize..end as usize])?;
        output.write_all(b"\n")?;
    }
    output.flush()
}
