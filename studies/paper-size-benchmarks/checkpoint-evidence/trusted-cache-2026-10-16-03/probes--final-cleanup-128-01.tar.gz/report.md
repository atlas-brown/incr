# Study final-cleanup-128-01

Suite: paper. Profile: scaled.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

42/42 invocations; 42 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 10 | 6.801× | 4.009× | 21.055× |
| original | 10 | 1.513× | 1.465× | 2.064× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| word-freq | 44.775 | 19.213 | 17.431 | 2.331× | 2.569× |
| poet | 103.706 | 34.027 | 30.850 | 3.048× | 3.362× |
| covid | 13.678 | 13.667 | 7.268 | 1.001× | 1.882× |
| weather | 5.922 | 5.195 | 2.514 | 1.140× | 2.356× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
