# Study content-inputs-128-01

Suite: paper. Profile: scaled.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

84/84 invocations; 84 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 10 | 6.536× | 3.868× | 20.317× |
| original | 10 | 1.473× | 1.426× | 2.165× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| word-freq | 45.237 | 19.405 | 18.007 | 2.331× | 2.512× |
| poet | 106.518 | 33.844 | 30.736 | 3.147× | 3.466× |
| covid | 13.048 | 13.492 | 7.341 | 0.967× | 1.777× |
| weather | 6.017 | 4.985 | 2.699 | 1.207× | 2.230× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
