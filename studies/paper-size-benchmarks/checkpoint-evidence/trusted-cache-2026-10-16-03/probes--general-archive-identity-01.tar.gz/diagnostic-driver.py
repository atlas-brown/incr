from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
ROOT=Path('/users/jxia3/atlas/incr')
sys.path.insert(0,str(ROOT/'studies/paper-size-benchmarks/harness'))
sys.path.insert(0,str(ROOT/'studies/observe-performance-regression/harness'))
from common import WORK,atomic_json,remove_owned,supervise
from study import lock
from provenance import fingerprint,verify
with lock():
 result=ROOT/'studies/observe-performance-regression/results/general-archive-identity-01'
 result.mkdir(parents=True,exist_ok=False);shutil.copy2(__file__,result/'diagnostic-driver.py');fingerprint(ROOT,result,Path(__file__))
 owned=Path(tempfile.mkdtemp(prefix='archive-probe-',dir=WORK));rows=[]
 try:
  for mode,repo in [('original',ROOT.parent/'incr-main-qualification'),('observe',ROOT)]:
   fixture=owned/mode;fixture.mkdir();cache=owned/(mode+'-cache');cache.mkdir();profiles=result/(mode+'-profiles');profiles.mkdir()
   source=fixture/'input.txt';archive=owned/(mode+'.zip')
   env={k:os.environ[k] for k in ('HOME','USER','LOGNAME','PATH') if k in os.environ}
   env.update(LC_ALL='C',INCR_EFFECT_POLICY='final',INCR_ASSUME_DIRECTORY_ACCESS='true',INCR_PROFILE_DIR=str(profiles))
   command=[str(repo/'target/release/incr'),'--cache',str(cache),'--try',str(repo/'src/scripts/try.sh')]
   if mode=='observe':command+=['--observe',str(ROOT.parent/'observe/target/release/observe')]
   command+=['--','cat',str(source)]
   for phase in ('cold','unchanged','reextract-identical','reextract-changed'):
    content=b'old data\n' if phase!='reextract-changed' else b'new data\n'
    if phase!='unchanged':
     with zipfile.ZipFile(archive,'w') as output:
      info=zipfile.ZipInfo('input.txt',(2020,1,2,3,4,6));info.external_attr=0o100644<<16;output.writestr(info,content)
     subprocess.run(['unzip','-oq',str(archive),'-d',str(fixture)],check=True)
    metadata=source.stat();capture=owned/'capture'
    if capture.exists():remove_owned(capture)
    def snapshot():return {str(p.relative_to(cache)):{'mtime':p.stat().st_mtime_ns,'ctime':p.stat().st_ctime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in cache.rglob('*') if p.is_file() and p.name in ('data','data.incr')}
    before=snapshot();row=supervise(command,cwd=fixture,env=env,capture=capture,timeout=30,reserve=8*1024**3,budget=32*1024**3)
    after=snapshot();row.update(mode=mode,phase=phase,input={'mtime':metadata.st_mtime_ns,'ctime':metadata.st_ctime_ns,'inode':metadata.st_ino,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},metadata_unchanged=bool(before) and before==after,correct=row['returncode']==0 and row['stdout_sha256']==hashlib.sha256(content).hexdigest())
    rows.append(row);atomic_json(result/'measurements.json',rows);print(mode,phase,'correct',row['correct'],'cache-metadata-unchanged',row['metadata_unchanged'],flush=True)
    if mode=='observe' and (row['failure'] or not row['correct']):raise RuntimeError('Candidate correctness failure')
  atomic_json(result/'summary.json',{'scope':'Cache identity fault probe, not performance samples. Changed same-mtime archive data intentionally tests original baseline limitation.','candidate_correct':all(r['correct'] for r in rows if r['mode']=='observe'),'rows':len(rows)})
 finally:
  verify(ROOT,result,Path(__file__));remove_owned(owned)
