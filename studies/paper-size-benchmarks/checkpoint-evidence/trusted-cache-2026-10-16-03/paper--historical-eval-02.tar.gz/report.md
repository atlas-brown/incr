# Study historical-eval-02

Profile: paper.

285/828 invocations; 282 valid. Complete: False.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 17 | 2.809× | 1.558× | 18.142× |
| original | 14 | 1.032× | 0.864× | 4.473× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
