"""Small real-model diagnostic of the supplied full archive workflow."""
from pathlib import Path
import hashlib,json,os,shutil,sys,tempfile,zipfile
from types import SimpleNamespace
ROOT=Path('/users/jxia3/atlas/incr')
sys.path.insert(0,str(ROOT/'studies/paper-size-benchmarks/harness'))
sys.path.insert(0,str(ROOT/'studies/observe-performance-regression/harness'))
import study
from common import WORK,atomic_json,file_hash,remove_owned
from provenance import fingerprint,verify
with study.lock():
 run=ROOT/'studies/observe-performance-regression/results/general-dpt-archive-01';run.mkdir(parents=True,exist_ok=False)
 shutil.copy2(__file__,run/'diagnostic-driver.py');fingerprint(ROOT,run,Path(__file__))
 benchmark=dict(study.selected('dpt')[0],scripts=['dpt_2.sh','dpt_3a.sh'],timeout_scaled=300)
 manifest=dict(study.MANIFEST,benchmarks=[benchmark]);atomic_json(run/'manifest.json',manifest)
 args=SimpleNamespace(profile='scaled',only='dpt',repetitions=1,modes=('bash','original','observe'),annotations=False,reserve_gib=8,work_budget_gib=32,native_transform=True,assume_directory_access=True)
 atomic_json(run/'configuration.json',dict(vars(args),started=study.now(),manifest_sha256=file_hash(run/'manifest.json'),profiling=True,scope='One real JPEG, unchanged supplied versions 2 and 3a, full archive extraction workflow. Diagnostic only, not the full dataset.'))
 build=study.freeze(run);owned=Path(tempfile.mkdtemp(prefix='dpt-archive-',dir=WORK));data=owned/'data';(data/'inputs').mkdir(parents=True)
 prepared=json.loads((WORK/'data/min/dpt/prepared.json').read_text());photo=sorted((WORK/'data/min/dpt/inputs/dpt.ref').glob('*.jpg'))[0]
 with zipfile.ZipFile(data/'inputs/images.zip','w') as output:
  info=zipfile.ZipInfo(photo.name,(2020,1,2,3,4,6));info.external_attr=0o100644<<16;output.writestr(info,photo.read_bytes())
 provenance={'models':prepared['models'],'files':[{'path':'inputs/images.zip','bytes':(data/'inputs/images.zip').stat().st_size,'sha256':file_hash(data/'inputs/images.zip')}],'input_bytes':(data/'inputs/images.zip').stat().st_size,'recipes':[{'selection':'One unmodified real minimum JPEG in a fixed-timestamp archive; preserve full unzip semantics','photo_sha256':file_hash(photo)}]}
 atomic_json(data/'prepared.json',provenance);atomic_json(run/'inputs/dpt.json',provenance)
 profiles=run/'profiles';profiles.mkdir();base_environment=study.environment
 def instrument(*pos,**kw):return dict(base_environment(*pos,**kw),INCR_PROFILE_DIR=str(profiles))
 study.environment=instrument
 try:
  references={}
  with study.Mirror(data) as mirror:
   for mode in args.modes:
    record=study.execute_sequence(run,benchmark,mode,0,args,build,data,references,mirror)
    study.report(run)
    if not record['valid']:raise RuntimeError('Archive workflow validation failed: '+mode)
  result=study.report(run)
  if not result['complete']:raise RuntimeError('Incomplete archive workflow diagnostic')
  verify(ROOT,run,Path(__file__))
  atomic_json(run/'status.json',{'state':'complete','updated':study.now(),'valid_invocations':result['valid_invocations']})
 finally:
  study.environment=base_environment
  remove_owned(owned)
