# Study content-inputs-32-01

Suite: paper. Profile: scaled.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

84/84 invocations; 84 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 10 | 5.821× | 3.227× | 18.399× |
| original | 10 | 2.870× | 2.681× | 4.738× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| word-freq | 13.096 | 7.211 | 5.551 | 1.816× | 2.359× |
| poet | 25.844 | 12.480 | 7.907 | 2.071× | 3.268× |
| covid | 3.241 | 7.938 | 2.315 | 0.408× | 1.400× |
| weather | 1.408 | 3.234 | 0.859 | 0.435× | 1.639× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
