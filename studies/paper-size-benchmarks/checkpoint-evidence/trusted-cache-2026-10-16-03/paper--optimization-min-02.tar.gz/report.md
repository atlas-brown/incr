# Study optimization-min-02

Profile: min.

27/27 invocations; 27 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 7 | 1.706× | 1.393× | 5.224× |
| original | 7 | 5.743× | 3.780× | 14.967× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
