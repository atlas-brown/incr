# Study scaled-thirtytwo-spool64-01

Profile: scaled.

24/24 invocations; 24 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 6 | 1.293× | 1.236× | 1.633× |
| original | 6 | 0.850× | 0.850× | 0.908× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
