# Study general-unannotated-128-01

Suite: paper. Profile: scaled.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

84/84 invocations; 84 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 10 | 6.675× | 3.928× | 20.473× |
| original | 10 | 1.595× | 1.529× | 2.412× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| word-freq | 47.812 | 19.048 | 17.821 | 2.510× | 2.683× |
| poet | 104.951 | 35.226 | 30.329 | 2.979× | 3.460× |
| covid | 12.901 | 13.333 | 7.309 | 0.968× | 1.765× |
| weather | 6.134 | 5.640 | 2.719 | 1.088× | 2.256× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
