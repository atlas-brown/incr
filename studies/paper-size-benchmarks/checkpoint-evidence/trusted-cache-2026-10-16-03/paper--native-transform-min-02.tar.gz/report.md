# Study native-transform-min-02

Profile: min.
Native shell transformation: enabled, with Python fallback.

246/246 invocations; 246 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 69 | 0.540× | 0.266× | 14.439× |
| original | 69 | 3.974× | 2.776× | 17.118× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
