# Study scaled-128-native-bound64-01

Profile: scaled.
Native shell transformation: enabled, with Python fallback.

36/36 invocations; 36 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 9 | 4.970× | 3.284× | 14.290× |
| original | 9 | 0.860× | 0.838× | 1.225× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
