# Study content-inputs-min-01

Suite: paper. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

246/246 invocations; 246 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 69 | 0.520× | 0.254× | 13.489× |
| original | 69 | 9.574× | 6.911× | 30.180× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 1.885 | 15.486 | 2.005 | 0.122× | 0.940× |
| word-freq | 3.661 | 3.395 | 1.481 | 1.079× | 2.472× |
| nlp-ngrams | 0.065 | 11.390 | 0.640 | 0.006× | 0.101× |
| poet | 0.054 | 3.658 | 0.207 | 0.015× | 0.261× |
| nlp-uppercase | 0.034 | 3.471 | 0.330 | 0.010× | 0.102× |
| covid | 0.104 | 5.306 | 0.327 | 0.020× | 0.318× |
| nginx-analysis | 0.454 | 12.529 | 3.891 | 0.036× | 0.117× |
| spell | 0.177 | 5.280 | 0.667 | 0.034× | 0.265× |
| bio | 2.711 | 45.863 | 4.297 | 0.059× | 0.631× |
| weather | 0.032 | 2.098 | 0.146 | 0.015× | 0.218× |
| beginner | 0.156 | 7.409 | 0.578 | 0.021× | 0.270× |
| unixfun | 0.056 | 4.720 | 0.259 | 0.012× | 0.214× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
