# Study min-matrix-02

Profile: min.

87/87 invocations; 87 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 24 | 0.663× | 0.627× | 1.204× |
| original | 24 | 3.464× | 1.304× | 15.459× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
