// Diagnostic only: plain C-locale GNU-sort semantics on bounded inputs.
use std::io::{self, Read, Write};
fn main() -> io::Result<()> {
    let mut data = Vec::new();
    io::stdin().take(64 * 1024 * 1024 + 1).read_to_end(&mut data)?;
    if data.len() > 64 * 1024 * 1024 { return Err(io::Error::other("diagnostic input limit")); }
    let mut counts: std::collections::HashMap<&[u8],u32> = std::collections::HashMap::new();
    for record in data.split_inclusive(|&byte| byte == b'\n') {
        let line = record.strip_suffix(b"\n").unwrap_or(record);
        if !counts.contains_key(line) && counts.len() >= 512 * 1024 {
            return Err(io::Error::other("diagnostic unique-record limit"));
        }
        *counts.entry(line).or_default() += 1;
    }
    let mut records: Vec<_> = counts.into_iter().collect();
    records.sort_unstable_by(|a,b| a.0.cmp(b.0));
    let stdout=io::stdout();
    let mut output=io::BufWriter::with_capacity(65536,stdout.lock());
    for (line,count) in records {
        for _ in 0..count {
            output.write_all(line)?;
            output.write_all(b"\n")?;
        }
    }
    output.flush()
}
