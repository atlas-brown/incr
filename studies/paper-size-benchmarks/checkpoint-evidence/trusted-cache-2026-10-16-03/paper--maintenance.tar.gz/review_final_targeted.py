"""Audit the completed targeted cohort and qualification; preserve separate samples."""
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import subprocess

ROOT = Path('/users/jxia3/atlas/incr')
STUDY = ROOT / 'studies/paper-size-benchmarks'
RUN = STUDY / 'results/memory-queue-targeted-paper-01'
QUAL = STUDY / 'results/memory-queue-qualification-01'

def read(path):
    return json.loads(path.read_text())

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1024**2), b''):
            h.update(data)
    return h.hexdigest()

def require(value, message):
    if not value:
        raise RuntimeError(message)

def stats(values):
    return {'samples': values, 'median': statistics.median(values),
            'min': min(values), 'max': max(values),
            'stdev': statistics.stdev(values) if len(values) > 1 else None}

summary = read(RUN / 'summary.json')
require(summary['complete'] and summary['invocations'] == summary['valid_invocations'] == summary['expected_invocations'] == 216 and not summary['failed_sequences'], 'Targeted cohort incomplete')
monitor = read(RUN / 'monitor.json')
require(monitor['run_state'] == 'complete' and monitor['health'] == 'ok' and monitor['recorded'] == monitor['valid'] == 216 and not monitor['monitor_issues'] and not monitor['failed_samples'], 'Terminal monitor failed')
report = read(RUN / 'paired-report.json')
require(report['paired_repetitions'] == 3 and {x['label'] for x in report['families']} == {'beginner', 'dpt'}, 'Paired report scope changed')
config = read(RUN / 'configuration.json')
require(config['profile'] == 'paper' and config['repetitions'] == 3 and not config['annotations'] and config['native_transform'] and config['assume_directory_access'] and config['content_validated_inputs'], 'Runtime assumptions changed')
require(read(QUAL / 'summary.json')['complete'], 'Qualification incomplete')
commands = read(QUAL / 'commands.json')
require(len(commands) == 22 and len({x['stage'] for x in commands}) == 22 and all(x['returncode'] == 0 for x in commands), 'Qualification stage failed/missing')
sources = read(QUAL / 'source-fingerprints.json')
for path, expected in sources.items():
    require(sha(path) == expected, 'Qualified source changed: ' + path)
binaries = read(QUAL / 'binaries.json')
for name, expected in binaries.items():
    repo = ROOT if name == 'incr' else ROOT.parent / 'observe'
    require(sha(repo / 'target/release' / name) == expected, 'Qualified binary changed: ' + name)
build = read(RUN / 'frozen-build.json')
for path, expected in build['sha256'].items():
    require(sha(Path(build['directory']) / path) == expected, 'Frozen runtime changed: ' + path)
require(build['sha256']['candidate/target/release/incr'] == binaries['incr'] and build['sha256']['observe/target/release/observe'] == binaries['observe'], 'Measured binaries were not qualified')
baseline = ROOT.parent / 'incr-main-qualification'
require(sha(baseline / 'target/release/incr') == build['sha256']['original/target/release/incr'], 'Original baseline binary changed')
require(subprocess.check_output(['git', '-C', str(baseline), 'rev-parse', 'HEAD'], text=True).strip() == '4b8e5ddf8e275d947518c7cc0f5d2713fe992307', 'Original baseline head changed')
require(subprocess.check_output(['git', '-C', str(baseline), 'diff', 'HEAD', '--', 'src', 'Cargo.toml', 'Cargo.lock']) == (STUDY / 'reference/original-minimal-fixes.patch').read_bytes(), 'Original baseline patch changed')
for name, count in [('memory-queue-defaults-full-01',83), ('memory-queue-system-bash-full-01',82)]:
    s = read(ROOT / 'studies/bash-parity-audit-2026-10-08/results' / name / 'summary.json')
    require(s['complete'] and not s['failures'] and s['cold_matches'] == s['warm_matches'] == count and s['scratch_cleaned'] and all(x['returncode'] == 0 for x in s['regressions'].values()), 'Full Bash qualification failed: ' + name)
for name, count in [('memory-queue-min-all-01',276), ('memory-queue-supplemental-min-01',15)]:
    s = read(STUDY / 'results' / name / 'summary.json')
    require(s['complete'] and s['invocations'] == s['valid_invocations'] == s['expected_invocations'] == count and not s['failed_sequences'], 'Minimum qualification failed: ' + name)
    require(read(STUDY / 'results' / name / 'monitor.json')['health'] == 'ok', 'Minimum audit failed: ' + name)
rows = [read(p) for p in (RUN / 'sequences').glob('*/[0-9][0-9].*.json')]
require(len(rows) == 216, 'Unexpected targeted record count')
resources = []
for family, count in [('beginner',14), ('dpt',10)]:
    for mode in ('bash','original','observe'):
        for rep in range(3):
            seq = [x for x in rows if (x['benchmark'],x['mode'],x['repetition']) == (family,mode,rep)]
            marker = read(RUN / 'sequences' / f'{family}.{mode}.{rep}' / 'complete.json')
            require(len(seq) == count and marker['valid'], 'Incomplete sequence marker')
            resources.append({'benchmark':family,'mode':mode,'repetition':rep,
                'seconds':sum(x['elapsed_sec'] for x in seq),
                'edited_seconds':sum(x['elapsed_sec'] for x in seq if x['index'] > 0),
                'peak_cache_bytes':max(max(x['peak_cache_bytes'],x['cache_bytes']) for x in seq),
                'peak_work_bytes':max(x['peak_work_bytes'] for x in seq),
                'max_process_rss_kib':max(x['resources']['max_rss_kib'] for x in seq),
                'user_sec':sum(x['resources']['user_sec'] for x in seq),
                'system_sec':sum(x['resources']['system_sec'] for x in seq),
                'filesystem_output_blocks':sum(x['resources']['filesystem_outputs'] for x in seq)})
with (RUN / 'sequence-resources.csv').open('w') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(resources[0]));writer.writeheader();writer.writerows(resources)
resource_stats = []
for family in ('beginner','dpt'):
    for mode in ('bash','original','observe'):
        samples=[x for x in resources if x['benchmark']==family and x['mode']==mode]
        resource_stats.append({'benchmark':family,'mode':mode,'statistics':{k:stats([x[k] for x in samples]) for k in resources[0] if k not in ('benchmark','mode','repetition')}})
historical = {}
with (STUDY / 'reference/historical-timings.csv').open() as stream:
    for x in csv.DictReader(stream):
        if x['benchmark'] in ('beginner','dpt'):
            key=(x['benchmark'],x['mode'],int(x['repetition']))
            historical[key]=historical.get(key,0)+float(x['elapsed_sec'])
result = {'verified_at':datetime.now(timezone.utc).isoformat(),'scope':'Final unannotated three-pair full-size beginner/DPT cohort only. All 216 samples passed the terminal monitor and strict paired cohort reporter. Earlier revisions/cohorts are retained separately; the fresh full reproduction has not launched.',
    'qualification':{'stages':22,'qualified_sources':len(sources),'binaries':binaries,'frozen_files_verified':len(build['sha256']),'bash_default_cold_warm':83,'bash_benchmark_cold_warm':82,'historical_minimum_valid':276,'supplemental_minimum_valid':15},
    'families':report['families'],'edited_families':report['edited_families'],'sequence_resources':resource_stats,
    'resource_scope':'Cache/work peaks are sampled allocated bytes; GNU time RSS is the maximum single-process RSS, not aggregate concurrent RAM. Filesystem output counters are GNU time blocks. Raw per-invocation and per-sequence records remain available.',
    'interpretation':'Beginner material slowdown resolved; original and Observe are near parity, with substantial gain over Bash. DPT Observe has a small advantage over original and about4.5x total /6.3x edited speedup over Bash. Do not call marginal original/Observe differences large or statistically established with n=3; retain every per-version slowdown and full sample spread.',
    'historical_context_scope':'Published timings are context only: reconstructed historical recipes, annotations/configuration differences, workload repairs and new timing harness prevent treating them as matched paired samples. Individual multi-fold differences of a few seconds remain disclosed.',
    'historical_sequence_totals':[{'benchmark':k[0],'mode':k[1],'repetition':k[2],'seconds':v} for k,v in sorted(historical.items())],
    'historical_per_version_flags':[x for x in summary['historical_comparisons'] if x['review_large_difference']],
    'required_remaining':['Package detailed old/new evidence and review final code/study/controller','Commit and push both repositories; verify exact remote heads and clean worktrees','Prepare fresh owned state and launch/verify persistent serial full historical828 plus supplemental45 reproduction']}
(RUN / 'final-review.json').write_text(json.dumps(result,indent=2)+'\n')
for family in report['families']:
    print(family['label'],{m:round(s['median'],6) for m,s in family['seconds'].items()})
print('Verified',len(sources),'qualified source files;',len(build['sha256']),'frozen files; all qualification and targeted gates passed.')
