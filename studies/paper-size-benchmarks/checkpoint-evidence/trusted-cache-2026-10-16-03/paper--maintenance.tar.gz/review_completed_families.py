"""Summarize completed diagnostic families without pooling cohorts."""
import collections
import datetime
import json
from pathlib import Path
import sys

run = Path(sys.argv[1])
manifest_path = Path(sys.argv[2]) if len(sys.argv) > 2 else run / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
config = json.loads((run / 'configuration.json').read_text())
scripts = {b['name']: b['scripts'] for b in manifest['benchmarks']}
rows = collections.defaultdict(list)
for path in (run / 'sequences').glob('*/[0-9][0-9].*.json'):
    if '.interrupted.' in path.parent.name:
        continue
    row = json.loads(path.read_text())
    rows[row['benchmark']].append(row)
output = []
for family, samples in sorted(rows.items()):
    expected = {(s, m, r) for s in scripts[family] for m in config['modes']
                for r in range(config['repetitions'])}
    keys = {(s['script'], s['mode'], s['repetition']) for s in samples}
    if keys != expected or len(samples) != len(expected):
        continue
    if not all(s['valid'] and not s['failure'] for s in samples):
        raise ValueError('Invalid family: ' + family)
    pairs = []
    for repetition in range(config['repetitions']):
        times = {m: sum(s['elapsed_sec'] for s in samples
                        if s['mode'] == m and s['repetition'] == repetition)
                 for m in config['modes']}
        pairs.append(dict(repetition=repetition, seconds=times,
                          original_over_observe=times['original']/times['observe'],
                          bash_over_observe=times['bash']/times['observe']))
    output.append(dict(family=family, valid=len(samples), paired_samples=pairs))
report = dict(updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope=('Partial final cohort: completed families only; final complete-cohort audit pending; no diagnostic samples pooled' if config.get('profile') == 'paper' and config.get('repetitions', 0) >= 3 else 'Diagnostic only; incomplete families omitted; no pooling with final cohorts'),
              manifest_source=str(manifest_path),
              completed_families=output)
(run / 'live-family-review.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
