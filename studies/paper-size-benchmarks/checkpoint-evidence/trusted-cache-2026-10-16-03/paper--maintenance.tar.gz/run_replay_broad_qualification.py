"""Final-code broad diagnostics, serialized after the bio scaling queue."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
ROOT=Path.cwd();MAINT=ROOT/'studies/paper-size-benchmarks/results/maintenance'
STATE=MAINT/'replay-broad-qualification-status.json'
EXPECTED=json.loads((MAINT/'replay-reuse-push.json').read_text())['verified_remote_heads']
BINARIES=json.loads((ROOT/'studies/paper-size-benchmarks/REPLAY_REUSE_CHECKPOINT.json').read_text())['binaries']
def write(path,data):
    pending=path.with_suffix('.pending');pending.write_text(json.dumps(data,indent=2)+'\n');pending.replace(path)
def status(phase,**data):write(STATE,dict(phase=phase,updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),**data))
def stable():
    for name,repo in [('incr',ROOT),('observe',ROOT.parent/'observe')]:
        if subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()!=EXPECTED[name] or subprocess.check_output(['git','-C',str(repo),'status','--porcelain']):raise RuntimeError('Sources changed: '+name)
        if hashlib.sha256((repo/'target/release'/name).read_bytes()).hexdigest()!=BINARIES[name]:raise RuntimeError('Binary changed: '+name)
def launch(name,run,command,suite='paper'):
    stable();status('running',run=str(run.relative_to(ROOT)))
    monitor=Path.home()/'.config/systemd/user/incr-bench-monitor.service'
    monitor.write_text('\n'.join(f'ExecStart=/usr/bin/python3 {ROOT}/studies/paper-size-benchmarks/harness/monitor.py {run}' if l.startswith('ExecStart=') else l for l in monitor.read_text().splitlines())+'\n')
    subprocess.run(['systemctl','--user','daemon-reload'],check=True)
    subprocess.run(['systemctl','--user','start','incr-bench-monitor.timer'],check=True)
    active=MAINT/'active-evaluation.json';d=json.loads(active.read_text());d.update(phase='final-code-broad-qualification',service='incr-bench-study.service',run=str(run.relative_to(ROOT)),log=str((run.parent/(name+'.log')).relative_to(ROOT)),next='Finish full minimum correctness coverage plus repeated 128 MiB diagnostics. Agent review and final qualification commits/pushes precede the all-family full evaluation.');write(active,d)
    log=run.parent/(name+'.log')
    subprocess.run(['systemd-run','--user','--unit=incr-bench-study','--collect','--wait','--property=KillMode=control-group','--property=TimeoutStopSec=20','--property=Restart=no',f'--property=WorkingDirectory={ROOT}',f'--setenv=PATH={os.environ["PATH"]}',f'--setenv=INCR_BENCH_SUITE={suite}',f'--property=StandardOutput=append:{log}',f'--property=StandardError=append:{log}','--',*command],check=True)
    stable()
    subprocess.run(['/usr/bin/python3',str(ROOT/'studies/paper-size-benchmarks/harness/monitor.py'),str(run)],check=True)
    summary=json.loads((run/'summary.json').read_text());health=json.loads((run/'monitor.json').read_text())
    if not summary['complete'] or summary['failed_sequences'] or health['health']!='ok':raise RuntimeError('Qualification failed: '+name)
    status('stage-complete',run=str(run.relative_to(ROOT)),valid_invocations=summary['valid_invocations'])
try:
    status('waiting-for-bio-diagnostics')
    while True:
        p=subprocess.run(['systemctl','--user','show','incr-replay-diagnostics.service','-p','MainPID','--value'],capture_output=True,text=True)
        if not p.stdout.strip() or p.stdout.strip()=='0':break
        time.sleep(15)
    previous=json.loads((MAINT/'replay-diagnostic-queue-status.json').read_text())
    if previous['phase']!='complete-review-required':raise RuntimeError('Bio diagnostic queue did not pass: '+str(previous))
    flags=['--native-transform','--assume-directory-access','--content-validated-inputs']
    paper=ROOT/'studies/paper-size-benchmarks';performance=ROOT/'studies/observe-performance-regression'
    name='replay-reuse-min-all-01'
    launch(name,paper/'results'/name,['/usr/bin/python3','-u',str(paper/'harness/study.py'),'run','--profile','min','--only','file-mod,word-freq,nlp-ngrams,poet,nlp-uppercase,covid,nginx-analysis,spell,bio,weather,beginner,unixfun,dpt','--run-id',name,'--repetitions','1',*flags])
    name='replay-reuse-supplemental-min-01'
    launch(name,paper/'results'/name,['/usr/bin/python3','-u',str(paper/'harness/study.py'),'run','--profile','min','--only','web-search,weather-tufte','--run-id',name,'--repetitions','2',*flags],suite='supplemental')
    name='replay-reuse-larger-128-01'
    launch(name,performance/'results'/name,['/usr/bin/python3','-u',str(performance/'harness/scale.py'),'--id',name,'--only','word-freq,poet,covid,weather','--mib','128','--repetitions','2',*flags])
    status('complete-review-required',next='Review all regressions, source/provenance and full correctness; commit/push final qualification before full historical and separate full supplemental measurements.')
except BaseException as error:
    status('stopped-for-review',error=repr(error));raise
