import json,os,sys,time,subprocess,shutil
from pathlib import Path
root=Path('/users/jxia3/atlas/incr');sys.path.insert(0,str(root/'studies/paper-size-benchmarks/harness'))
from common import WORK,remove_owned,atomic_json
from study import lock
size=int(sys.argv[1]);tag=sys.argv[2]
result=root/'studies/observe-performance-regression/results'/tag;result.mkdir(parents=True,exist_ok=False)
owned=WORK/tag;owned.mkdir();fixture=owned/'fixture';fixture.mkdir();(fixture/'outputs').mkdir();(fixture/'tmp').mkdir()
with (WORK/'data/paper/beginner/inputs/logs/log0').open('rb') as src:
 data=src.read(size*1024**2);data=data[:data.rfind(b'\n')+1];(fixture/'input').write_bytes(data)
shutil.copytree(root/'evaluation/benchmarks/beginner/scripts',fixture/'scripts')
env={k:os.environ[k] for k in ('HOME','USER','LOGNAME') if k in os.environ};env.update(PATH=str(root/'qualification/.venv/bin')+':/usr/local/bin:/usr/bin:/bin',LC_ALL='C',LANG='C',IN=str(fixture/'input'),OUT=str(fixture/'outputs'),TMPDIR=str(fixture/'tmp'),INCR_EFFECT_POLICY='final',INCR_PYTHON=str(root/'qualification/.venv/bin/python'),PYTHONDONTWRITEBYTECODE='1',INCR_NATIVE_TRANSFORM='1',INCR_ASSUME_DIRECTORY_ACCESS='true')
profile_root=owned/'profiles';profile_root.mkdir();env['INCR_PROFILE_DIR']=str(profile_root)
rows=[];refs={}
with lock():
 for mode in ('bash','original','observe'):
  cache=owned/'cache';remove_owned(cache);cache.mkdir()
  top=root.parent/'incr-main-qualification' if mode=='original' else root
  env.update(INCR_TOP=str(top),INCR_SYS_PATH=str(top/'target/release/incr'),INCR_TRY_PATH=str(top/'src/scripts/try.sh'),INCR_OBSERVE='1' if mode=='observe' else '0',INCR_OBSERVE_PATH=str(root.parent/'observe/target/release/observe'),INCR_CACHE_DIR=str(cache))
  if mode=='observe':env['INCR_CONTENT_VALIDATED_INPUTS']='true'
  else:env.pop('INCR_CONTENT_VALIDATED_INPUTS',None)
  for script in sorted((fixture/'scripts').glob('beginner-*.sh')):
   profiles=result/f'{mode}-{script.stem}';profiles.mkdir();before=set(profile_root.iterdir())
   args=['bash',str(script)] if mode=='bash' else ['bash',str(top/('src/incr.sh' if mode=='original' else 'incr.sh')),str(script)]
   stdout=result/f'{mode}-{script.stem}.stdout';stderr=result/f'{mode}-{script.stem}.stderr'
   with stdout.open('wb') as out,stderr.open('wb') as err:
    start=time.monotonic();p=subprocess.run(args,cwd=fixture,env=env,stdout=out,stderr=err,timeout=180);elapsed=time.monotonic()-start
   import hashlib
   actual=[p.returncode,hashlib.sha256(stdout.read_bytes()).hexdigest(),hashlib.sha256(stderr.read_bytes()).hexdigest()]
   if mode=='bash':refs[script.name]=actual
   for profile in set(profile_root.iterdir())-before:shutil.copy2(profile,profiles/profile.name)
   row=dict(mode=mode,script=script.name,elapsed_sec=elapsed,valid=actual==refs[script.name]);rows.append(row);atomic_json(result/'measurements.json',rows);print(row,flush=True)
   if not row['valid']:raise RuntimeError('output mismatch')
 atomic_json(result/'summary.json',dict(valid=all(r['valid'] for r in rows),samples=len(rows),input_bytes=len(data),scope='Profiled diagnostic; not final measurements'))
 remove_owned(owned)
