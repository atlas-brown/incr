"""Launch only beginner/DPT after the serial qualification service proves its gates."""
import datetime,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/users/jxia3/atlas/incr');STUDY=ROOT/'studies/paper-size-benchmarks'
sys.path.insert(0,str(STUDY/'harness'))
from common import atomic_json,file_hash
from monitor import check
QUAL=STUDY/'results/trusted-cache-qualification-04'
STATE=STUDY/'results/maintenance/trusted-cache-targeted-launch.json'
SERVICE='incr-trusted-cache-qualification-04.service'
RUN='trusted-cache-targeted-paper-01'
def status(phase,**fields):atomic_json(STATE,dict(updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,qualification=str(QUAL),run=RUN,**fields))
def service(name):
 p=subprocess.run(['systemctl','--user','show',name,'-p','ActiveState','-p','MainPID','-p','Result'],capture_output=True,text=True,check=True,timeout=10)
 return dict(line.split('=',1) for line in p.stdout.splitlines() if '=' in line)
def require(condition,reason):
 if not condition:raise RuntimeError(reason)
try:
 status('waiting-for-qualification')
 deadline=time.monotonic()+6*3600
 while True:
  current=service(SERVICE)
  if current['ActiveState'] not in ('active','activating','deactivating'):break
  require(time.monotonic()<deadline,'Qualification wait deadline exceeded')
  time.sleep(15)
 require(current['ActiveState']=='inactive' and current.get('Result')=='success','Qualification service did not finish successfully')
 require(json.loads((QUAL/'summary.json').read_text())['complete'],'Qualification summary incomplete')
 require(json.loads((QUAL/'status.json').read_text())['phase']=='complete-review-required','Qualification stage incomplete')
 for path,digest in json.loads((QUAL/'source-fingerprints.json').read_text()).items():require(file_hash(path)==digest,'Implementation changed: '+path)
 for repo,digest in json.loads((QUAL/'binaries.json').read_text()).items():
  top=ROOT if repo=='incr' else ROOT.parent/'observe';require(file_hash(top/'target/release'/repo)==digest,'Binary changed: '+repo)
 commands=json.loads((QUAL/'commands.json').read_text())
 expected={'incr-format','incr-clippy','incr-units','incr-build','observe-format','observe-clippy','observe-units','observe-build','incr-foreign-owner','observe-integration','harness','incr-integration','regressions-final','regressions-live','chunk_tests','inherited_fd_tests','shell_ast_tests','native_transform_tests','trusted-cache-defaults-full-01','trusted-cache-system-bash-full-01','trusted-cache-min-all-01','trusted-cache-supplemental-min-01'}
 require({r['stage'] for r in commands}==expected and len(commands)==len(expected) and all(r['returncode']==0 for r in commands),'Missing or failed qualification command')
 for name,count in [('trusted-cache-defaults-full-01',83),('trusted-cache-system-bash-full-01',82)]:
  summary=json.loads((ROOT/'studies/bash-parity-audit-2026-10-08/results'/name/'summary.json').read_text())
  require(summary['complete'] and not summary['failures'] and summary['cold_matches']==count and summary['warm_matches']==count and summary['scratch_cleaned'],'Full Bash gate failed: '+name)
  require(all(v['returncode']==0 for v in summary['regressions'].values()),'Bash regression gate failed: '+name)
 for name,count in [('trusted-cache-min-all-01',276),('trusted-cache-supplemental-min-01',15)]:
  run=STUDY/'results'/name;summary=json.loads((run/'summary.json').read_text())
  require(summary['complete'] and summary['invocations']==count and summary['valid_invocations']==count and not summary['failed_sequences'],'Minimum gate failed: '+name)
  require(check(run)['health']=='ok','Minimum evidence audit failed: '+name)
 require(service('incr-bench-study.service')['ActiveState']!='active','Another benchmark service is active')
 status('gates-passed-launching',qualification_commands=len(commands))
 argv=[sys.executable,str(STUDY/'harness/launch.py'),'--profile','paper','--only','beginner,dpt','--run-id',RUN,'--repetitions','3','--native-transform','--assume-directory-access','--content-validated-inputs']
 subprocess.run(argv,cwd=ROOT,check=True,timeout=60)
 deadline=time.monotonic()+180
 while not (STUDY/'results'/RUN/'status.json').is_file():
  require(service('incr-bench-study.service')['ActiveState']=='active','Targeted run stopped before status creation')
  require(time.monotonic()<deadline,'Targeted status creation deadline exceeded');time.sleep(1)
 target=Path.home()/'.config/systemd/user/incr-bench-monitor.service.d/trusted-cache-target.conf';target.parent.mkdir(parents=True,exist_ok=True)
 target.write_text('[Service]\nExecStart=\nExecStart=/usr/bin/python3 '+str(STUDY/'harness/monitor.py')+' '+str(STUDY/'results'/RUN)+'\n')
 subprocess.run(['systemctl','--user','daemon-reload'],check=True,timeout=15)
 subprocess.run(['systemctl','--user','start','incr-bench-monitor.timer'],check=True,timeout=15)
 live=service('incr-bench-study.service');require(live['ActiveState']=='active' and int(live['MainPID'])>0,'Targeted benchmark service is not live')
 status('targeted-running',service=live,log=str(STUDY/'results/logs'/f'{RUN}.log'),expected_invocations=216,monitor_timer='incr-bench-monitor.timer')
 print('Targeted run launched with all gates verified.',flush=True)
except BaseException as error:
 status('failed',error=repr(error));raise
