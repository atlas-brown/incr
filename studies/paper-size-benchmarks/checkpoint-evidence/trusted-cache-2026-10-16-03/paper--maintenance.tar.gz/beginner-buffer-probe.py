"""Repeated real beginner script diagnostic; no final sequence-performance claim."""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path('/users/jxia3/atlas/incr')
sys.path.insert(0,str(ROOT/'studies/paper-size-benchmarks/harness'))
from common import WORK,atomic_json,file_hash,remove_owned
from study import lock,inventory
size,tag=int(sys.argv[1]),sys.argv[2]
result=ROOT/'studies/observe-performance-regression/results'/tag
fdguard=WORK/'builds/trusted-cache-targeted-paper-01/fdguard'
assert fdguard.is_file()
with lock():
 result.mkdir(parents=True,exist_ok=False)
 owned=WORK/tag;owned.mkdir();fixture=owned/'fixture';fixture.mkdir();(fixture/'outputs').mkdir();(fixture/'tmp').mkdir();profiles=owned/'profiles';profiles.mkdir()
 source=WORK/'data/paper/beginner/inputs/logs/log0'
 with source.open('rb') as src,(fixture/'input').open('wb') as out:
  remaining=size*1024**2
  while remaining:
   block=src.read(min(1024**2,remaining))
   if not block:break
   out.write(block);remaining-=len(block)
  # Full input or prefix is preserved exactly; all modes see identical bytes.
 script=fixture/'beginner.sh';shutil.copy2(ROOT/'evaluation/benchmarks/beginner/scripts/beginner-13.sh',script)
 original=ROOT.parent/'incr-main-qualification'
 binaries={str(p):file_hash(p) for p in [ROOT/'target/release/incr',original/'target/release/incr',ROOT.parent/'observe/target/release/observe']}
 sources={str(p):inventory(p/'src') for p in [ROOT,original,ROOT.parent/'observe']}
 atomic_json(result/'provenance.json',dict(binaries=binaries,sources=sources,input_bytes=(fixture/'input').stat().st_size,input_sha256=file_hash(fixture/'input'),script_sha256=file_hash(script),source=str(source),scope='Repeated unchanged supplied beginner-13, diagnostic only; not the 14-version study sequence'))
 env={k:os.environ[k] for k in ['HOME','USER','LOGNAME'] if k in os.environ}
 env.update(PATH=str(ROOT/'qualification/.venv/bin')+':/usr/local/bin:/usr/bin:/bin',LC_ALL='C',LANG='C',IN=str(fixture/'input'),OUT=str(fixture/'outputs'),TMPDIR=str(fixture/'tmp'),INCR_EFFECT_POLICY='final',INCR_PYTHON=str(ROOT/'qualification/.venv/bin/python'),PYTHONDONTWRITEBYTECODE='1',INCR_NATIVE_TRANSFORM='1',INCR_ASSUME_DIRECTORY_ACCESS='true',INCR_PROFILE_DIR=str(profiles))
 rows=[];reference=None
 for mode in ['bash','original','observe']:
  cache=owned/'cache';remove_owned(cache);cache.mkdir()
  top=original if mode=='original' else ROOT
  env.update(INCR_TOP=str(top),INCR_SYS_PATH=str(top/'target/release/incr'),INCR_TRY_PATH=str(top/'src/scripts/try.sh'),INCR_OBSERVE='1' if mode=='observe' else '0',INCR_OBSERVE_PATH=str(ROOT.parent/'observe/target/release/observe'),INCR_CACHE_DIR=str(cache))
  if mode=='observe':env['INCR_CONTENT_VALIDATED_INPUTS']='true'
  else:env.pop('INCR_CONTENT_VALIDATED_INPUTS',None)
  for repetition in range(3 if mode!='bash' else 1):
   stem=f'{mode}-{repetition}';before=set(profiles.iterdir());stdout=result/(stem+'.stdout');stderr=result/(stem+'.stderr');resource=result/(stem+'.resources.json')
   argv=['bash',str(script)] if mode=='bash' else ['bash',str(top/('src/incr.sh' if mode=='original' else 'incr.sh')),str(script)]
   with stdout.open('wb') as out,stderr.open('wb') as err:
    started=time.monotonic();proc=subprocess.run(['/usr/bin/time','-f','{"user_sec":%U,"system_sec":%S,"max_rss_kib":%M,"filesystem_inputs":%I,"filesystem_outputs":%O}','-o',str(resource),'--',str(fdguard),*argv],cwd=fixture,env=env,stdout=out,stderr=err,timeout=300);elapsed=time.monotonic()-started
   actual=[proc.returncode,file_hash(stdout),file_hash(stderr)]
   if mode=='bash':reference=actual
   destination=result/(stem+'-profiles');destination.mkdir()
   for path in set(profiles.iterdir())-before:shutil.copy2(path,destination/path.name)
   entries=[p for p in cache.glob('*/*') if p.name in ('data','data.incr')]
   if mode=='observe' and not list(destination.iterdir()):raise RuntimeError('Observe bypassed: no runtime profiles')
   row=dict(cache_entries=len(entries),mode=mode,repetition=repetition,elapsed_sec=elapsed,valid=actual==reference,resources=json.loads(resource.read_text()));rows.append(row);atomic_json(result/'measurements.json',rows);print(json.dumps(row),flush=True)
   if not row['valid']:raise RuntimeError('Native output mismatch')
 for path,digest in binaries.items():
  if file_hash(path)!=digest:raise RuntimeError('Binary changed')
 for path,entries in sources.items():
  if inventory(Path(path)/'src')!=entries:raise RuntimeError('Source changed')
 atomic_json(result/'summary.json',dict(complete=True,valid=all(r['valid'] for r in rows),samples=len(rows),scope='Repeated unchanged script diagnostic, not final benchmark samples'))
 remove_owned(owned)
