import sys,json,subprocess,time
from pathlib import Path
sys.path.insert(0,'studies/paper-size-benchmarks/harness')
import study
root=Path.cwd();out=root/'studies/paper-size-benchmarks/results/maintenance'/sys.argv[1];out.mkdir();profiles=out/'profiles';profiles.mkdir()
run=root/'studies/paper-size-benchmarks/results/replay-mtime-min-bio-01';setup=json.loads((run/'sequences/bio.observe.0/setup.json').read_text());env=setup['environment'];env['INCR_PROFILE_DIR']=str(profiles);env['INCR_SYS_PATH']=str(root/'target/release/incr');env['INCR_OBSERVE_PATH']=str(root.parent/'observe/target/release/observe')
with study.lock():
 study.remove_owned(study.SCRATCH/'cache')
 build=Path(setup['frozen_build']);active=study.fixture('bio',study.WORK/'data/min/bio',build,'min');rows=[]
 for script in ['bio-1.sh','bio-2.sh','bio-3.sh','bio-4-0.sh','bio-4.sh','bio-5.sh','bio-6.sh']:
  before=set(profiles.iterdir());start=time.monotonic();p=subprocess.run(['bash',str(build/'candidate/incr.sh'),str(active/'scripts'/script)],env=env,cwd=active,capture_output=True,timeout=30)
  assert p.returncode==0,(script,p.stderr)
  reports=[]
  for f in set(profiles.iterdir())-before:
   r=json.loads(f.read_text());r['command']=[bytes(x).decode(errors='replace') for x in r['arguments_bytes']];reports.append(r)
  rows.append({'script':script,'elapsed':time.monotonic()-start,'reports':reports})
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 for row in rows[-3:]:
  print(row['script'])
  for r in row['reports']:
   if any(p[0]=='capture_save' for p in r['phases_ns']):
    cmd=r['command'];idx=cmd.index('--observe');cmd=cmd[idx+2:]
    print(cmd[:3],r.get('events',[])[:2])
