from pathlib import Path
import datetime,json,subprocess,sys
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'studies/paper-size-benchmarks/harness'))
from study import lock
study=ROOT/'studies/bash-parity-audit-2026-10-08'
state=ROOT/'studies/paper-size-benchmarks/results/maintenance/replay-reuse-bash-status.json'
def status(**fields):
 fields['updated']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 state.write_text(json.dumps(fields,indent=2)+'\n')
base=['/usr/bin/python3','-B','-u',str(study/'harness/runner.py')]
cases=[('replay-reuse-system-bash-full-02',['--bash-build',str(ROOT/'qualification/.work/bash-5.1.16'),'--shell','/bin/bash','--corpus-provenance',str(study/'corpus-provenance-5.1.16.json'),'--native-transform','--assume-directory-access','--content-validated-inputs']),('replay-reuse-defaults-full-01',[])]
with lock():
 try:
  for name,flags in reversed(cases):
   output=study/'results'/name
   status(state='running',case=name,output=str(output))
   with (state.parent/(name+'.log')).open('xb') as log:
    subprocess.run(base+flags+['--output',str(output)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=3600)
   result=json.loads((output/'summary.json').read_text())
   assert result['complete'] and not result['failures'],result
  status(state='complete',cases=[name for name,_ in cases])
 except BaseException as error:
  status(state='error',error=repr(error))
  raise
