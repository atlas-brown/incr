"""Serial qualification of reviewed trusted-cache changes; stop on any failed gate."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/users/jxia3/atlas/incr');OBSERVE=ROOT.parent/'observe'
sys.path.insert(0,str(ROOT/'studies/paper-size-benchmarks/harness'))
from common import atomic_json,file_hash
from study import lock
OUT=ROOT/'studies/paper-size-benchmarks/results/memory-queue-qualification-01'
OUT.mkdir(parents=True,exist_ok=False)
PYTHON=ROOT/'qualification/.venv/bin/python'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sources():
 result={}
 for repo in (ROOT,OBSERVE):
  for p in sorted((repo/'src').rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:result[str(p)]=file_hash(p)
  for name in ('Cargo.toml','Cargo.lock','incr.sh'):
   p=repo/name
   if p.is_file():result[str(p)]=file_hash(p)
 return result
FROZEN=sources();atomic_json(OUT/'source-fingerprints.json',FROZEN)
for repo in (ROOT,OBSERVE):
 (OUT/f'{repo.name}.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=repo))
atomic_json(OUT/'provenance.json',{'started':now(),'heads':{repo.name:subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() for repo in (ROOT,OBSERVE)},'assumption':'Trusted private cache; no annotation performance shortcuts','controller_sha256':file_hash(Path(__file__))})
rows=[]
def status(phase,**extra):atomic_json(OUT/'status.json',dict(updated=now(),phase=phase,**extra))
def execute(name,argv,cwd=ROOT,timeout=3600,environment=None):
 if sources()!=FROZEN:raise RuntimeError('Implementation changed before '+name)
 status('running',stage=name)
 start=now()
 with (OUT/f'{name}.log').open('xb') as log:
  p=subprocess.run([str(x) for x in argv],cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 row=dict(stage=name,argv=[str(x) for x in argv],started=start,finished=now(),returncode=p.returncode);rows.append(row);atomic_json(OUT/'commands.json',rows)
 if p.returncode:raise RuntimeError(f'{name} failed: {p.returncode}')
 if sources()!=FROZEN:raise RuntimeError('Implementation changed during '+name)
 print(name,'PASS',flush=True)
def gate_run(run,expected):
 summary=json.loads((run/'summary.json').read_text())
 if not summary['complete'] or summary['valid_invocations']!=expected or summary['invocations']!=expected or summary['failed_sequences']:raise RuntimeError('Incomplete benchmark qualification: '+str(run))
try:
 status('waiting-for-beginner-proof',run='beginner-memory-confirm-paper-01')
 deadline=time.monotonic()+3600
 while True:
  service=dict(line.split('=',1) for line in subprocess.check_output(['systemctl','--user','show','incr-bench-study.service','-p','ActiveState','-p','MainPID','-p','Result'],text=True,timeout=10).splitlines() if '=' in line)
  if service['ActiveState'] not in ('active','activating','deactivating'):break
  if service['MainPID'] not in ('1751210','0'):raise RuntimeError('Unexpected benchmark process during proof wait')
  if time.monotonic()>deadline:raise RuntimeError('Beginner proof wait deadline exceeded')
  time.sleep(10)
 if service['ActiveState']!='inactive' or service['Result']!='success':raise RuntimeError('Beginner proof service failed')
 proof=ROOT/'studies/paper-size-benchmarks/results/beginner-memory-confirm-paper-01'
 gate_run(proof,42)
 from monitor import check
 if check(proof)['health']!='ok':raise RuntimeError('Beginner proof evidence audit failed')
 build=json.loads((proof/'frozen-build.json').read_text())
 if build['sha256']['candidate/target/release/incr']!=file_hash(ROOT/'target/release/incr'):raise RuntimeError('Beginner proof binary changed')
 totals={}
 for mode in ('bash','original','observe'):
  rows_for_mode=[json.loads(p.read_text()) for p in (proof/'sequences'/f'beginner.{mode}.0').glob('[0-9][0-9].*.json')]
  if len(rows_for_mode)!=14 or not all(r['valid'] and not r['failure'] for r in rows_for_mode):raise RuntimeError('Incomplete beginner proof')
  totals[mode]=sum(r['elapsed_sec'] for r in rows_for_mode)
 atomic_json(OUT/'beginner-proof.json',dict(run=str(proof),sequence_seconds=totals,scope='Single full-size sequence diagnostic; final three-pair rerun still required'))
 if not (totals['observe']<totals['original'] and totals['observe']<totals['bash']):raise RuntimeError('Beginner proof did not establish the intended speedup; investigate before qualification')
 print('Beginner full-size proof PASS',totals,flush=True)
 with lock():
  for repo in (ROOT,OBSERVE):
   for name,args in [('format',['cargo','fmt','--check']),('clippy',['cargo','clippy','--all-targets','--','-D','warnings']),('units',['cargo','test','--quiet']),('build',['cargo','build','--release','--quiet'])]:execute(repo.name+'-'+name,args,repo)
  atomic_json(OUT/'binaries.json',{repo.name:file_hash(repo/'target/release'/repo.name) for repo in (ROOT,OBSERVE)})
  execute('incr-foreign-owner',['cargo','test','--quiet','--','--ignored'])
  execute('observe-integration',['bash','tests/run_tests.sh'],OBSERVE,600)
 execute('harness',[PYTHON,'-m','unittest','discover','-s','studies/paper-size-benchmarks/harness','-p','test_*.py'],timeout=300)
 with lock():
  execute('incr-integration',['bash','agents/test_incr_observe.sh'],timeout=600)
  for policy in ('final','live'):execute('regressions-'+policy,[PYTHON,'qualification/regressions.py','--effect-policy',policy],timeout=300)
  for name in ('chunk_tests','inherited_fd_tests','shell_ast_tests','native_transform_tests'):
   env=dict(os.environ,INCR_QUALIFICATION_RESULTS=str(OUT/name));execute(name,[PYTHON,'qualification/'+name+'.py'],timeout=600,environment=env)
  audit=ROOT/'studies/bash-parity-audit-2026-10-08';base=[sys.executable,'-B','-u',audit/'harness/runner.py']
  for name,flags in [('memory-queue-defaults-full-01',[]),('memory-queue-system-bash-full-01',['--bash-build',ROOT/'qualification/.work/bash-5.1.16','--shell','/bin/bash','--corpus-provenance',audit/'corpus-provenance-5.1.16.json','--native-transform','--assume-directory-access','--content-validated-inputs'])]:
   result=audit/'results'/name;execute(name,base+flags+['--output',result],timeout=7200)
   summary=json.loads((result/'summary.json').read_text())
   if not summary['complete'] or summary['failures']:raise RuntimeError('Bash summary failed: '+name)
 # Each benchmark driver owns the same study lock. Never hold it across subprocess entry.
 base=[sys.executable,'-u',ROOT/'studies/paper-size-benchmarks/harness/study.py','run','--profile','min','--repetitions','1','--native-transform','--assume-directory-access','--content-validated-inputs']
 historical='memory-queue-min-all-01';execute(historical,base+['--only','file-mod,word-freq,nlp-ngrams,poet,nlp-uppercase,covid,nginx-analysis,spell,bio,weather,beginner,unixfun,dpt','--run-id',historical],timeout=14400)
 gate_run(OUT.parent/historical,276)
 supplemental='memory-queue-supplemental-min-01';execute(supplemental,base+['--only','web-search,weather-tufte','--run-id',supplemental],timeout=3600,environment=dict(os.environ,INCR_BENCH_SUITE='supplemental'))
 gate_run(OUT.parent/supplemental,15)
 status('complete-review-required',stages=len(rows));atomic_json(OUT/'summary.json',dict(complete=True,stages=len(rows),source_fingerprints_verified=True,finished=now()))
except BaseException as error:
 status('failed',error=repr(error));raise
