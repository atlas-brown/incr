"""Supervise serial diagnostics; the final all-family matrix follows agent review."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path.cwd()
MAINT=ROOT/'studies/paper-size-benchmarks/results/maintenance'
STATE=MAINT/'replay-diagnostic-queue-status.json'
EXPECTED=json.loads((MAINT/'replay-reuse-push.json').read_text())['verified_remote_heads']
BINARIES=json.loads((ROOT/'studies/paper-size-benchmarks/REPLAY_REUSE_CHECKPOINT.json').read_text())['binaries']

def write(path,data):
    pending=path.with_suffix(path.suffix+'.pending')
    pending.write_text(json.dumps(data,indent=2)+'\n');pending.replace(path)

def status(phase,**data):
    write(STATE,dict(phase=phase,updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),**data))

def stable():
    for name,repo in [('incr',ROOT),('observe',ROOT.parent/'observe')]:
        head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
        if head!=EXPECTED[name] or subprocess.check_output(['git','-C',str(repo),'status','--porcelain']):
            raise RuntimeError(f'Implementation changed before measurement: {name}')
        binary=repo/'target/release'/name
        if hashlib.sha256(binary.read_bytes()).hexdigest()!=BINARIES[name]:
            raise RuntimeError(f'Binary changed before measurement: {name}')

def qualify_bash():
    status('waiting-for-full-bash')
    while True:
        pid=subprocess.check_output(['systemctl','--user','show','incr-bash-qualification.service','-p','MainPID','--value'],text=True).strip()
        if pid=='0':break
        time.sleep(15)
    state=json.loads((MAINT/'replay-reuse-bash-status.json').read_text())
    if state['state']!='complete':raise RuntimeError(f'Bash qualification did not pass: {state}')
    checks=[]
    for name,count,files in [('replay-reuse-defaults-full-01',83,668),('replay-reuse-system-bash-full-02',82,625)]:
        directory=ROOT/'studies/bash-parity-audit-2026-10-08/results'/name
        summary=json.loads((directory/'summary.json').read_text())
        provenance=json.loads((directory/'provenance.json').read_text())
        rows=json.loads((directory/'case-results.json').read_text())
        if not(summary['complete'] and summary['groups']==count and summary['cold_matches']==count and summary['warm_matches']==count and not summary['failures'] and summary['scratch_cleaned'] and len(rows)==2*count and all(r['match'] for r in rows) and provenance['source_files_verified']==files and all(r['returncode']==0 for r in summary['regressions'].values())):
            raise RuntimeError(f'Incomplete full Bash evidence: {name}')
        checks.append(dict(run=name,groups=count,verified_corpus_files=files))
    write(MAINT/'replay-full-bash-gate.json',dict(passed=True,checks=checks))

def launch(name,command,run):
    stable();status('running-diagnostic',run=str(run.relative_to(ROOT)))
    active=MAINT/'active-evaluation.json';data=json.loads(active.read_text());data.update(phase='serial-replay-diagnostics',service='incr-bench-study.service',run=str(run.relative_to(ROOT)),log=str((run.parent/(name+'.log')).relative_to(ROOT)),next='Inspect .01 then paired .1 and full bio diagnostics. Final all-family evaluation still requires agent review and a clean pushed final checkpoint.');write(active,data)
    monitor=Path.home()/'.config/systemd/user/incr-bench-monitor.service'
    lines=monitor.read_text().splitlines()
    lines=[f'ExecStart=/usr/bin/python3 {ROOT}/studies/paper-size-benchmarks/harness/monitor.py {run}' if line.startswith('ExecStart=') else line for line in lines]
    monitor.write_text('\n'.join(lines)+'\n')
    subprocess.run(['systemctl','--user','daemon-reload'],check=True)
    subprocess.run(['systemctl','--user','start','incr-bench-monitor.timer'],check=True)
    log=run.parent/(name+'.log')
    subprocess.run(['systemd-run','--user','--unit=incr-bench-study','--collect','--wait','--property=KillMode=control-group','--property=TimeoutStopSec=20','--property=Restart=no',f'--property=WorkingDirectory={ROOT}',f'--setenv=PATH={os.environ["PATH"]}',f'--property=StandardOutput=append:{log}',f'--property=StandardError=append:{log}','--',*command],check=True)
    stable()
    subprocess.run(['/usr/bin/python3',str(ROOT/'studies/paper-size-benchmarks/harness/monitor.py'),str(run)],check=True)
    summary=json.loads((run/'summary.json').read_text());monitor=json.loads((run/'monitor.json').read_text())
    if not summary['complete'] or summary['failed_sequences'] or monitor['health']!='ok':
        raise RuntimeError(f'Diagnostic correctness/health failed: {name}')
    rows=[json.loads(p.read_text()) for p in (run/'sequences').glob('*/[0-9][0-9].*.json')]
    reps=sorted({r['repetition'] for r in rows});comparisons=[]
    for rep in reps:
        seconds={mode:sum(r['elapsed_sec'] for r in rows if r['mode']==mode and r['repetition']==rep) for mode in ['bash','original','observe']}
        comparisons.append(dict(repetition=rep,sequence_seconds=seconds,original_over_observe=seconds['original']/seconds['observe'],bash_over_observe=seconds['bash']/seconds['observe']))
    write(run/'diagnostic-gate.json',dict(scope='Diagnostic only; never pool with final historical evaluation',paired_samples=comparisons))
    if any(r['original_over_observe']<=1 for r in comparisons):raise RuntimeError(f'Observe failed original-speed gate: {name}')
    if '01pct' not in name and any(r['bash_over_observe']<=1 for r in comparisons):raise RuntimeError(f'Observe failed larger-input Bash-speed gate: {name}')
    status('diagnostic-complete',run=str(run.relative_to(ROOT)),paired_samples=comparisons)

try:
    qualify_bash();stable()
    for name,fraction,repetitions in [('bio-replay-real-01pct-03','.01',1),('bio-replay-real-10pct-01','.1',2)]:
        run=ROOT/'studies/observe-performance-regression/results'/name
        launch(name,['/usr/bin/python3','-u','studies/observe-performance-regression/harness/bio_scale.py','--id',name,'--fraction',fraction,'--repetitions',str(repetitions)],run)
    name='replay-reuse-bio-paper-01';run=ROOT/'studies/paper-size-benchmarks/results'/name
    launch(name,['/usr/bin/python3','-u','studies/paper-size-benchmarks/harness/study.py','run','--profile','paper','--only','bio','--run-id',name,'--repetitions','1','--native-transform','--assume-directory-access','--content-validated-inputs'],run)
    status('complete-review-required',next='Review full Bash and scaling evidence; commit/push final qualification before full historical/supplemental evaluation.')
except BaseException as error:
    status('stopped-for-review',error=repr(error))
    raise
