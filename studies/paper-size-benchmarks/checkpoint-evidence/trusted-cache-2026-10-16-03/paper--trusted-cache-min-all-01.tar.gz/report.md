# Study trusted-cache-min-all-01

Suite: paper. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

276/276 invocations; 276 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 78 | 0.905× | 0.348× | 15.283× |
| original | 78 | 8.891× | 5.708× | 40.293× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 2.083 | 15.660 | 1.898 | 0.133× | 1.097× |
| word-freq | 3.336 | 3.322 | 1.424 | 1.004× | 2.342× |
| nlp-ngrams | 0.065 | 11.215 | 0.565 | 0.006× | 0.116× |
| poet | 0.060 | 3.680 | 0.207 | 0.016× | 0.289× |
| nlp-uppercase | 0.030 | 3.585 | 0.301 | 0.008× | 0.101× |
| covid | 0.110 | 5.266 | 0.311 | 0.021× | 0.354× |
| nginx-analysis | 0.475 | 12.703 | 4.086 | 0.037× | 0.116× |
| spell | 0.170 | 5.197 | 0.626 | 0.033× | 0.271× |
| bio | 2.565 | 46.310 | 3.437 | 0.055× | 0.746× |
| weather | 0.031 | 2.209 | 0.146 | 0.014× | 0.216× |
| beginner | 0.159 | 7.018 | 0.597 | 0.023× | 0.267× |
| unixfun | 0.054 | 4.821 | 0.271 | 0.011× | 0.199× |
| dpt | 599.813 | 294.919 | 270.026 | 2.034× | 2.221× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
