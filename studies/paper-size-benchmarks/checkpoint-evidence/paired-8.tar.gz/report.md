# Study content-inputs-8-01

Suite: paper. Profile: scaled.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

84/84 invocations; 84 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 10 | 4.037× | 2.113× | 14.790× |
| original | 10 | 6.202× | 5.603× | 10.604× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| word-freq | 3.332 | 3.337 | 1.513 | 0.998× | 2.202× |
| poet | 5.576 | 6.330 | 2.299 | 0.881× | 2.426× |
| covid | 0.772 | 6.803 | 1.050 | 0.113× | 0.735× |
| weather | 0.375 | 2.937 | 0.308 | 0.128× | 1.220× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
