# Study final-cleanup-supplemental-min-01

Suite: supplemental. Profile: min.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

30/30 invocations; 30 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 2 | 0.410× | 0.308× | 0.681× |
| original | 2 | 2.374× | 2.231× | 3.187× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| web-search | 1.981 | 10.945 | 2.274 | 0.181× | 0.871× |
| weather-tufte | 6.827 | 18.491 | 10.304 | 0.369× | 0.663× |

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
