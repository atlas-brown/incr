# Study paper-file-mod

Suite: paper. Profile: paper.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

63/63 invocations; 63 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 6 | 0.716× | 0.706× | 0.908× |
| original | 6 | 1.777× | 1.105× | 6.301× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| file-mod | 40.661 | 110.531 | 54.469 | 0.368× | 0.746× |

Historical comparison: 0/14 matched version/mode timings differ by more than 2× and require review. Actual input sizes, annotation policy and environment must be reconciled before attributing differences.

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
