# Study paper-poet

Suite: paper. Profile: paper.
Native shell transformation: enabled, with Python fallback.

Directory stat/access assumption: enabled; directory content reads remain tracked.

Static performance annotations: disabled in both implementations.

36/36 invocations; 36 valid. Complete: True.

| Reference | Valid paired edits | Arithmetic mean | Geometric mean | Maximum |
|---|---:|---:|---:|---:|
| bash | 3 | 1.410× | 1.398× | 1.554× |
| original | 3 | 0.716× | 0.433× | 1.039× |

Complete-sequence means (seconds); speedup is Bash time divided by mode time.

| Family | Bash | Original Incr | Observe | Bash / original | Bash / Observe |
|---|---:|---:|---:|---:|---:|
| poet | 195.839 | 80.500 | 134.143 | 2.433× | 1.460× |

Historical comparison: 4/8 matched version/mode timings differ by more than 2× and require review. Actual input sizes, annotation policy and environment must be reconciled before attributing differences.

See timings.csv and invocation JSON for resources, hashes, output manifests, diagnostics, and cleanup evidence.
Identical successive source versions are retained as warm-repeat measurements and excluded from edit aggregates.
An incomplete study or failed sequence is never presented as a complete benchmark comparison.
