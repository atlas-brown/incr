use anyhow::Result;
use bincode::config::{Configuration, Fixint, Limit, LittleEndian};
use bincode::{Decode, Encode};
use serde::Serialize;
use serde::de::DeserializeOwned;
use std::fs::File;
use std::io::{BufReader, BufWriter, ErrorKind, Read, Write};
use std::path::Path;
use xxhash_rust::xxh3::Xxh3;

use crate::config::{BUFFER_SIZE, DEBUG};
use crate::ops;

const BINCODE_CONFIG: Configuration<LittleEndian, Fixint, Limit<67108864>> = bincode::config::standard()
    .with_little_endian()
    .with_fixed_int_encoding()
    .with_limit::<67108864>();

pub(crate) fn hash_bytes(bytes: &[u8]) -> u64 {
    let mut hasher = Xxh3::new();
    hasher.update(bytes);
    hasher.digest()
}

pub(crate) fn hash_stream<S>(stream: &mut S) -> Result<u64>
where
    S: Read,
{
    let mut hasher = Xxh3::new();
    let mut buffer = [0; BUFFER_SIZE];
    loop {
        match stream.read(&mut buffer) {
            Ok(0) => return Ok(hasher.digest()),
            Ok(length) => hasher.update(&buffer[..length]),
            Err(error) if error.kind() == ErrorKind::Interrupted => continue,
            Err(error) => return Err(error.into()),
        }
    }
}

pub(crate) fn encode_to_bytes<T>(value: &T) -> Result<Vec<u8>>
where
    T: Encode,
{
    Ok(bincode::encode_to_vec(value, BINCODE_CONFIG)?)
}

pub(crate) fn encode_to_file<T>(value: &T, directory: &Path, file_name: String) -> Result<()>
where
    T: Encode + Serialize,
{
    let file_name = ops::file::add_data_extension(file_name);
    let file = File::create(directory.join(file_name))?;
    let mut file_writer = BufWriter::with_capacity(BUFFER_SIZE, file);
    if !DEBUG {
        bincode::encode_into_std_write(value, &mut file_writer, BINCODE_CONFIG)?;
    } else {
        serde_json::to_writer_pretty(&mut file_writer, value)?;
    }
    file_writer.flush()?;
    Ok(())
}

pub(crate) fn decode_from_file<T>(directory: &Path, file_name: String) -> Result<Option<T>>
where
    T: Decode<()> + DeserializeOwned,
{
    let file_name = ops::file::add_data_extension(file_name);
    let file = match File::open(directory.join(file_name)) {
        Ok(file) => file,
        Err(error) if error.kind() == ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(error.into()),
    };
    let mut file_reader = BufReader::with_capacity(BUFFER_SIZE, file);

    let value = if !DEBUG {
        match bincode::decode_from_std_read(&mut file_reader, BINCODE_CONFIG) {
            Ok(value) => value,
            Err(_) => return Ok(None),
        }
    } else {
        match serde_json::from_reader(file_reader) {
            Ok(value) => value,
            Err(_) => return Ok(None),
        }
    };

    Ok(Some(value))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io;

    #[test]
    fn stream_hash_preserves_short_reads_interrupts_and_binary_bytes() -> Result<()> {
        struct Fragmented<'a> {
            bytes: &'a [u8],
            interrupt: bool,
        }
        impl Read for Fragmented<'_> {
            fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
                self.interrupt = !self.interrupt;
                if self.interrupt {
                    return Err(io::Error::from(ErrorKind::Interrupted));
                }
                let length = self.bytes.len().min(17).min(buffer.len());
                buffer[..length].copy_from_slice(&self.bytes[..length]);
                self.bytes = &self.bytes[length..];
                Ok(length)
            }
        }
        let bytes: Vec<_> = (0..BUFFER_SIZE * 3 + 137).map(|i| (i % 251) as u8).collect();
        assert_eq!(
            hash_stream(&mut Fragmented {
                bytes: &bytes,
                interrupt: false
            })?,
            hash_bytes(&bytes)
        );
        assert_eq!(hash_stream(&mut &[][..])?, hash_bytes(&[]));
        Ok(())
    }
}
