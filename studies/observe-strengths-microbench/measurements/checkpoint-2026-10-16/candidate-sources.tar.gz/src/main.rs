#![deny(rust_2018_idioms)]

mod annotation;
mod cache;
mod command;
mod config;
mod effect_gate;
mod execution;
mod ops;
mod scripts;
mod transform_fast;

use anyhow::{Result, anyhow};
use clap::Parser;
use std::collections::HashMap;
use std::env;
use std::io::IsTerminal;
use std::path::PathBuf;
use std::process;

use crate::command::Command;
use crate::config::Config;
use crate::config::{DEFAULT_CACHE_PATH, DEFAULT_TRY_PATH};
use crate::execution::{batch_executor, chunk_executor, skip_executor, stream_executor};
use crate::ops::{ExitCode, FAILURE_CODE, SUCCESS_CODE};

#[derive(Clone, Debug, Parser)]
struct Arguments {
    #[arg(short = 't', long = "try")]
    try_command: Option<String>,
    #[arg(short = 'c', long = "cache")]
    cache_directory: Option<String>,
    #[arg(long = "observe")]
    observe_command: Option<String>,

    #[arg(
        long = "effect-policy",
        env = "INCR_EFFECT_POLICY",
        value_enum,
        default_value = "final"
    )]
    effect_policy: crate::config::EffectPolicy,

    /// Assume stdin is NUL-free ASCII text for line-wise chunk optimizations.
    #[arg(long = "assume-text", env = "INCR_ASSUME_TEXT")]
    assume_text: bool,

    /// Include temporary scratch paths in Observe dependencies and replay effects.
    #[arg(long = "track-temporaries", env = "INCR_TRACK_TEMPORARIES")]
    track_temporaries: bool,

    /// Assume directory stat/access results are used for access checks, not timestamps.
    #[arg(long = "assume-directory-access", env = "INCR_ASSUME_DIRECTORY_ACCESS")]
    assume_directory_access: bool,

    /// Validate unchanged-mtime workspace data inputs by content after inode/ctime changes.
    /// Assumes those inputs do not expose inode identity or ctime as application data.
    #[arg(
        long = "content-validated-inputs",
        env = "INCR_CONTENT_VALIDATED_INPUTS",
        requires = "observe_command"
    )]
    content_validated_inputs: bool,

    #[arg(short = 'b', long = "batch_executor")]
    batch_executor: bool,
    #[arg(short = 's', long = "short_circuit")]
    short_circuit: bool,
    #[arg(short = 'z', long = "compress_output")]
    compress_output: bool,
    #[arg(short = 'f', long = "full_tracing")]
    full_tracing: bool,
    #[arg(short = 'a', long = "enable_annotations")]
    enable_annotations: bool,
    /// Compatibility flag: read-only witness bookkeeping has been removed.
    #[arg(short = 'o', long = "skip_introspection", hide = true)]
    skip_introspection: bool,

    #[arg(trailing_var_arg = true)]
    command: Vec<std::ffi::OsString>,
}

#[derive(Clone, Debug)]
struct Input {
    config: Config,
    command: Command,
    environment: HashMap<String, String>,
}

fn main() {
    if env::args_os().nth(1).as_deref() == Some(std::ffi::OsStr::new("--internal-transform-fast")) {
        process::exit(transform_fast::entry());
    }
    ops::profile::initialize();
    ops::initialize_log_file();
    // Adopt tracees if a cancelled tracer exits before reaping them.
    if unsafe { libc::prctl(libc::PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) } != 0 {
        eprintln!(
            "Error: cannot establish child ownership: {}",
            std::io::Error::last_os_error()
        );
        process::exit(FAILURE_CODE.0);
    }
    let result = run();
    command::reap_children();
    ops::profile::finish();
    match result {
        Ok(exit_code) => process::exit(exit_code.0),
        Err(error) => {
            eprintln!("Error: {error:#}");
            process::exit(FAILURE_CODE.0);
        }
    }
}

fn run() -> Result<ExitCode> {
    let (config, command, environment) = match ops::profile::measure("parse", parse_input)? {
        Some(input) => (input.config, input.command, input.environment),
        None => return Ok(SUCCESS_CODE),
    };
    // Pipes cannot preserve terminal reads, ioctl behavior or interactive output.
    if annotation::requires_fresh_execution(&command)
        || std::io::stdin().is_terminal()
        || std::io::stdout().is_terminal()
        || std::io::stderr().is_terminal()
        || command.unsupported_descriptors
        || (!command.guarded_descriptors.is_empty() && config.observe_command.is_none())
        || (!config.full_tracing && annotation::skip_command(&command, &environment))
    {
        return Err(skip_executor::execute(&command));
    }

    let chunk = !config.full_tracing
        && command.guarded_descriptors.is_empty()
        && config.enable_annotations
        && annotation::chunk_mode(&command, config.assume_text).is_some();
    let command_string = command.join_string()?;
    let result = if chunk {
        chunk_executor::execute(config, command)
    } else if !config.batch_executor {
        stream_executor::execute(&config, &command)
    } else {
        batch_executor::execute(&config, &command)
    };

    match result {
        Ok(code) => Ok(code),
        Err(error) => Err(error.context(format!("({command_string})"))),
    }
}

fn parse_input() -> Result<Option<Input>> {
    let arguments = Arguments::parse();
    if arguments.command.is_empty() {
        return Ok(None);
    }

    let home_directory = || env::home_dir().ok_or_else(|| anyhow!("Could not resolve home directory"));
    let try_command = match arguments.try_command {
        Some(command) => command,
        None => ops::file::path_to_string(&home_directory()?.join(DEFAULT_TRY_PATH))?.to_owned(),
    };
    let cache_directory = match arguments.cache_directory {
        Some(directory) => PathBuf::from(directory),
        None => home_directory()?.join(DEFAULT_CACHE_PATH),
    };

    // Cache keys currently use UTF-8 strings. Preserve arbitrary Unix bytes by
    // executing such invocations directly instead of rejecting or corrupting them.
    let utf8_arguments = arguments
        .command
        .iter()
        .map(|argument| argument.to_str().map(str::to_owned))
        .collect::<Option<Vec<_>>>();
    let environment = env::vars_os()
        .map(|(name, value)| Some((name.into_string().ok()?, value.into_string().ok()?)))
        .collect::<Option<HashMap<_, _>>>();
    let (Some(command_arguments), Some(environment)) = (utf8_arguments, environment) else {
        use std::os::unix::process::CommandExt;
        let error = std::process::Command::new(&arguments.command[0])
            .args(&arguments.command[1..])
            .exec();
        eprintln!("{}: {error}", arguments.command[0].to_string_lossy());
        process::exit(if error.kind() == std::io::ErrorKind::NotFound {
            127
        } else {
            126
        });
    };
    let command = command::create(command_arguments, &environment)?;
    let trace_type = if arguments.full_tracing {
        if arguments.observe_command.is_some() {
            crate::config::TraceType::Observe
        } else {
            crate::config::TraceType::Sandbox
        }
    } else {
        execution::get_trace_type(
            &command,
            arguments.observe_command.as_deref(),
            arguments.enable_annotations,
        )
    };
    let config = Config {
        try_command,
        cache_directory,
        trace_type,
        observe_command: arguments.observe_command,
        guarded_descriptors: command
            .guarded_descriptors
            .iter()
            .map(|descriptor| descriptor.fd)
            .collect(),

        effect_policy: arguments.effect_policy,
        assume_text: arguments.assume_text,
        track_temporaries: arguments.track_temporaries,
        assume_directory_access: arguments.assume_directory_access,
        content_validated_inputs: arguments.content_validated_inputs,
        batch_executor: arguments.batch_executor,
        short_circuit: arguments.short_circuit,
        compress_output: arguments.compress_output,
        full_tracing: arguments.full_tracing,
        enable_annotations: arguments.enable_annotations,
    };

    Ok(Some(Input {
        config,
        command,
        environment,
    }))
}
