pub(crate) mod batch_executor;
pub(crate) mod chunk_executor;
pub(crate) mod dependency;
pub(crate) mod run;
pub(crate) mod skip_executor;
pub(crate) mod stream_executor;

use anyhow::{Result, anyhow};
use std::collections::HashSet;
use std::fs;
use std::path::{Path, PathBuf};

use crate::annotation;
use crate::command::{Command, Runtime, RuntimeType};
use crate::config::{EXCLUDED_PATHS, TRACE_FILE, TraceType};
use crate::ops;
use crate::scripts;

/// Selects the trace type for a command based on annotations and introspection history.
/// Pure commands need no tracing; read-only/stateless or previously-introspected commands
/// use strace only; everything else gets a full sandbox.
pub(crate) fn get_trace_type(cache_directory: &Path, command: &Command, annotations: bool) -> TraceType {
    if annotations && annotation::check_pure(command) {
        return TraceType::Nothing;
    }
    if annotations && (annotation::check_stateless(command) || annotation::check_read_only(command)) {
        return TraceType::TraceFile;
    }
    if dependency::get_introspect_file(cache_directory, command.hash).exists() {
        return TraceType::TraceFile;
    }
    TraceType::Sandbox
}

/// Parses the strace output from a completed child into read and write path sets,
/// filtering out excluded paths (e.g. `/proc`, `pipe:`).
pub(crate) fn parse_trace(runtime: &Runtime) -> Result<(HashSet<PathBuf>, HashSet<PathBuf>)> {
    let trace_file = match &runtime.typ {
        RuntimeType::Sandbox(directory) => &directory.join("upperdir").join("tmp").join(TRACE_FILE),
        RuntimeType::TraceFile(file) => file,
        RuntimeType::Nothing => return Ok((HashSet::new(), HashSet::new())),
    };
    let (mut read_set, mut write_set) = scripts::parse_trace(trace_file).map_err(|e| anyhow!("{e}"))?;
    fs::remove_file(trace_file)?;

    read_set.retain(|p| {
        !EXCLUDED_PATHS.iter().any(|e| {
            ops::file::path_to_string(p)
                .map(|p| p.starts_with(e))
                .unwrap_or(true)
        })
    });
    write_set.retain(|p| {
        !EXCLUDED_PATHS.iter().any(|e| {
            ops::file::path_to_string(p)
                .map(|p| p.starts_with(e))
                .unwrap_or(true)
        })
    });

    Ok((read_set, write_set))
}
