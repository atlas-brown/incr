use nix::unistd::Pid;
use std::path::Path;

use crate::proc_helpers;
use crate::state::{PreWrite, TracerState};

mod mutation;
use mutation::{
    handle_create_node_exit, handle_link_exit, handle_rename_entry, handle_rename_exit,
    handle_unlink_entry, handle_unlink_exit,
};

mod metadata;
use metadata::{
    handle_extended_attributes, handle_metadata_write, handle_path_metadata, handle_transfer,
    handle_truncate,
};

mod open;
use open::{handle_open_entry, handle_open_exit};

/// Registers captured at syscall entry (PTRACE_EVENT_SECCOMP stop).
///
/// `number` is the syscall number (e.g. `libc::SYS_openat`). `arguments` contains the
/// six syscall arguments in the order defined by the x86_64 Linux ABI
/// (rdi, rsi, rdx, r10, r8, r9).
#[derive(Clone, Debug)]
pub struct SyscallEntry {
    pub number: i64,
    pub arguments: [u64; 6],
    open: Option<open::OpenArguments>,
}

impl SyscallEntry {
    /// Extract syscall number and arguments from x86_64 registers.
    #[cfg(target_arch = "x86_64")]
    pub fn from_registers(pid: Pid, registers: &libc::user_regs_struct) -> Self {
        let number = registers.orig_rax as i64;
        let arguments = [
            registers.rdi,
            registers.rsi,
            registers.rdx,
            registers.r10,
            registers.r8,
            registers.r9,
        ];
        let open = open::OpenArguments::decode(number, &arguments, |address| {
            proc_helpers::read_open_how_flags(pid, address)
        });
        Self {
            number,
            arguments,
            open,
        }
    }
}

/// High-level category for a traced syscall, used to dispatch entry/exit handling.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SyscallKind {
    Open,          // open, openat, openat2, creat
    PathMetadata,  // newfstatat, statx, access, faccessat, faccessat2, readlink, readlinkat
    Truncate,      // truncate(path)
    Rename,        // rename, renameat, renameat2
    Link,          // link, linkat, symlink, symlinkat
    Unlink,        // unlink, unlinkat, rmdir
    CreateNode,    // mkdir, mkdirat
    MetadataWrite, // chmod, fchmod, fchmodat, chown, fchown, lchown, fchownat, utimensat
    Transfer,      // sendfile, copy_file_range
    ExtendedAttributes,
    AsynchronousIo,
    Other,
}

/// Classify a syscall number into a `SyscallKind`.
pub fn classify(number: i64) -> SyscallKind {
    match number {
        libc::SYS_open | libc::SYS_openat | libc::SYS_openat2 | libc::SYS_creat => {
            SyscallKind::Open
        }

        libc::SYS_stat
        | libc::SYS_lstat
        | libc::SYS_newfstatat
        | libc::SYS_statx
        | libc::SYS_access
        | libc::SYS_faccessat
        | libc::SYS_faccessat2
        | libc::SYS_readlink
        | libc::SYS_readlinkat => SyscallKind::PathMetadata,

        libc::SYS_truncate => SyscallKind::Truncate,

        libc::SYS_rename | libc::SYS_renameat | libc::SYS_renameat2 => SyscallKind::Rename,

        libc::SYS_link | libc::SYS_linkat | libc::SYS_symlink | libc::SYS_symlinkat => {
            SyscallKind::Link
        }

        libc::SYS_unlink | libc::SYS_unlinkat | libc::SYS_rmdir => SyscallKind::Unlink,

        libc::SYS_mkdir | libc::SYS_mkdirat | libc::SYS_mknod | libc::SYS_mknodat => {
            SyscallKind::CreateNode
        }

        libc::SYS_chmod
        | libc::SYS_fchmod
        | libc::SYS_fchmodat
        | libc::SYS_fchmodat2
        | libc::SYS_chown
        | libc::SYS_fchown
        | libc::SYS_lchown
        | libc::SYS_fchownat
        | libc::SYS_utimensat
        | libc::SYS_utime
        | libc::SYS_utimes
        | libc::SYS_futimesat => SyscallKind::MetadataWrite,

        libc::SYS_sendfile | libc::SYS_copy_file_range => SyscallKind::Transfer,

        libc::SYS_getxattr
        | libc::SYS_lgetxattr
        | libc::SYS_fgetxattr
        | libc::SYS_listxattr
        | libc::SYS_llistxattr
        | libc::SYS_flistxattr
        | libc::SYS_setxattr
        | libc::SYS_lsetxattr
        | libc::SYS_fsetxattr
        | libc::SYS_removexattr
        | libc::SYS_lremovexattr
        | libc::SYS_fremovexattr => SyscallKind::ExtendedAttributes,
        libc::SYS_io_uring_setup
        | libc::SYS_io_uring_enter
        | libc::SYS_io_setup
        | libc::SYS_io_submit => SyscallKind::AsynchronousIo,
        _ => SyscallKind::Other,
    }
}

/// Conservative boundary for speculative cancellation. File opens with write
/// intent and FIFO opens must be arbitrated before the kernel sees the syscall.
pub fn has_live_effect(pid: Pid, entry: &SyscallEntry) -> bool {
    match classify(entry.number) {
        SyscallKind::Open => open::has_live_effect(pid, entry),
        SyscallKind::Truncate
        | SyscallKind::Rename
        | SyscallKind::Link
        | SyscallKind::Unlink
        | SyscallKind::CreateNode
        | SyscallKind::MetadataWrite
        | SyscallKind::Transfer
        | SyscallKind::ExtendedAttributes
        | SyscallKind::AsynchronousIo => true,
        _ => false,
    }
}

/// Handle a syscall at entry (PTRACE_EVENT_SECCOMP). Returns `true` if we
/// also need the syscall-exit stop to inspect the return value.
pub fn handle_entry(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) -> bool {
    if state.dependencies {
        // Creation success depends on the destination not already existing.
        let destination = match classify(entry.number) {
            SyscallKind::CreateNode
                if entry.number == libc::SYS_mkdir || entry.number == libc::SYS_mknod =>
            {
                Some((None, entry.arguments[0]))
            }
            SyscallKind::CreateNode => Some((Some(entry.arguments[0] as i32), entry.arguments[1])),
            SyscallKind::Link if entry.number == libc::SYS_symlink => {
                Some((None, entry.arguments[1]))
            }
            SyscallKind::Link if entry.number == libc::SYS_symlinkat => {
                Some((Some(entry.arguments[1] as i32), entry.arguments[2]))
            }
            _ => None,
        };
        if let Some((directory_descriptor, address)) = destination
            && let Ok(path) = proc_helpers::read_path(pid, address)
            && let Some(real_path) =
                proc_helpers::best_effort_resolve(pid, directory_descriptor, &path)
        {
            state.record_read(real_path);
        }
        // Final file bytes alone cannot reproduce inode-preserving moves,
        // external hard links, removal followed by recreation, or timestamps
        // and ownership. Keep executing these operations live until the
        // consumer supports their operation-level replay semantics.
        let barrier = match classify(entry.number) {
            SyscallKind::CreateNode
                if entry.number == libc::SYS_mknod || entry.number == libc::SYS_mknodat =>
            {
                Some("special file creation requires live execution")
            }
            SyscallKind::Rename => Some("rename preserves inode identity"),
            SyscallKind::Unlink => Some("unlink may replace an existing inode"),
            SyscallKind::MetadataWrite
                if entry.number != libc::SYS_chmod
                    && entry.number != libc::SYS_fchmod
                    && entry.number != libc::SYS_fchmodat
                    && entry.number != libc::SYS_fchmodat2 =>
            {
                Some("ownership or timestamp change")
            }
            SyscallKind::Link
                if entry.number == libc::SYS_link || entry.number == libc::SYS_linkat =>
            {
                Some("hard link may reference an external inode")
            }
            _ => None,
        };
        if let Some(reason) = barrier {
            state.replay_barriers.insert(reason.into());
        }
    }
    if matches!(
        classify(entry.number),
        SyscallKind::Rename | SyscallKind::Unlink | SyscallKind::Link
    ) {
        state.forbid_overwrite_reuse();
    }
    match classify(entry.number) {
        SyscallKind::PathMetadata => {
            handle_path_metadata(state, pid, entry);
            false
        }
        SyscallKind::Truncate => {
            handle_truncate(state, pid, entry);
            false
        }
        SyscallKind::Transfer => {
            handle_transfer(state, pid, entry);
            false
        }
        SyscallKind::MetadataWrite => {
            handle_metadata_write(state, pid, entry);
            false
        }
        // The following kinds need the exit stop (return value / fd matters).
        SyscallKind::Open => {
            // Pre-hash at entry if O_TRUNC, because the kernel will truncate
            // the file atomically with the open (before we see the exit stop).
            handle_open_entry(state, pid, entry);
            true
        }
        SyscallKind::Rename => {
            // Snapshot both old and new paths at entry, while both still exist.
            handle_rename_entry(state, pid, entry);
            true
        }
        SyscallKind::Link => true,
        SyscallKind::Unlink => {
            // Snapshot the target at entry, before the kernel removes it.
            handle_unlink_entry(state, pid, entry);
            true
        }
        SyscallKind::CreateNode => true,
        SyscallKind::ExtendedAttributes => {
            handle_extended_attributes(state, pid, entry);
            false
        }
        SyscallKind::AsynchronousIo => {
            state
                .replay_barriers
                .insert("asynchronous filesystem operations".into());
            false
        }
        SyscallKind::Other => false,
    }
}

/// Handle a syscall at exit. Called only for syscalls where `handle_entry`
/// returned `true`, so we can inspect the return value in `return_value`.
pub fn handle_exit(state: &mut TracerState, pid: Pid, entry: &SyscallEntry, return_value: i64) {
    match classify(entry.number) {
        SyscallKind::Open => handle_open_exit(state, pid, entry, return_value),
        SyscallKind::Rename => handle_rename_exit(state, pid, entry, return_value),
        SyscallKind::Link => handle_link_exit(state, pid, entry, return_value),
        SyscallKind::Unlink => handle_unlink_exit(state, pid, entry, return_value),
        SyscallKind::CreateNode => handle_create_node_exit(state, pid, entry, return_value),
        _ => {} // shouldn't happen but harmless
    }
}

/// Capture the first content hash, reusing it across hard-link aliases. The reader
/// is called only when hashing is enabled and neither the path nor inode is known.
fn capture_pre_hash(
    state: &mut TracerState,
    path: &Path,
    identify: impl FnOnce() -> Option<(u64, u64)>,
    read_hash: impl FnOnce() -> std::io::Result<u64>,
) {
    if !state.hash_writes || state.pre_hashes.contains_key(path) {
        return;
    }
    let identity = identify();
    let previous = identity.and_then(|identity| state.inode_hashes.get(&identity).copied());
    let pre_write = previous.unwrap_or_else(|| match read_hash() {
        Ok(hash) => PreWrite::Hash(hash),
        Err(_) => PreWrite::Unreadable,
    });
    if let Some(identity) = identity {
        state.inode_hashes.insert(identity, pre_write);
    }
    state.pre_hashes.insert(path.to_owned(), pre_write);
}

/// Record the dependency before hashing a descriptor whose contents may change.
fn maybe_prehash_fd(state: &mut TracerState, pid: Pid, descriptor: i32, path: &Path) {
    if state.dependencies {
        state.record_write_precondition(path.to_owned());
    }
    capture_pre_hash(
        state,
        path,
        || proc_helpers::file_id_from_fd(pid, descriptor),
        || proc_helpers::hash_fd(pid, descriptor),
    );
}

/// Record the dependency before a path operation such as truncate or open.
fn maybe_prehash_host_path(state: &mut TracerState, host_path: &Path, real_path: &Path) {
    if state.dependencies {
        // Our checksum is an implicit write precondition, not a content read
        // performed by the tracee. In particular it must not prevent O_TRUNC
        // from being recognized as an overwrite of an existing file.
        state.record_write_precondition(real_path.to_owned());
    }
    capture_pre_hash(
        state,
        real_path,
        || proc_helpers::file_id(host_path),
        || proc_helpers::hash_host_path(host_path),
    );
}
