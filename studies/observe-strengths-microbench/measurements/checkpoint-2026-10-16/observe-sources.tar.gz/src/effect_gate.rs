//! Optional Incr coordination: never start a live effect after replay is claimed.
//! v1 layout: native u32 version, then atomic u32 (0 running, 1 replay, 2 live, 3 awaiting attachment).
use anyhow::{Result, bail};
use std::fs::OpenOptions;
use std::os::fd::AsRawFd;
use std::path::Path;
use std::sync::atomic::{AtomicU32, Ordering};

const VERSION: u32 = 1;
const MAPPING_BYTES: usize = 8;
const RUNNING: u32 = 0;
const REPLAY: u32 = 1;
const LIVE: u32 = 2;
const ATTACHING: u32 = 3;

pub struct EffectGate(*mut libc::c_void);

impl EffectGate {
    pub fn open(path: &Path) -> Result<Self> {
        let file = OpenOptions::new().read(true).write(true).open(path)?;
        if file.metadata()?.len() != MAPPING_BYTES as u64 {
            bail!("invalid effect gate length");
        }
        let raw = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                MAPPING_BYTES,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED,
                file.as_raw_fd(),
                0,
            )
        };
        if raw == libc::MAP_FAILED {
            return Err(std::io::Error::last_os_error().into());
        }
        let gate = Self(raw);
        if unsafe { *raw.cast::<u32>() } != VERSION {
            bail!("unsupported effect gate version");
        }
        let state = unsafe { &*raw.cast::<AtomicU32>().add(1) };
        if state
            .compare_exchange(ATTACHING, RUNNING, Ordering::SeqCst, Ordering::SeqCst)
            .is_err()
        {
            bail!("effect gate already used or invalid");
        }
        Ok(gate)
    }

    pub fn has_live_effects(&self) -> bool {
        let state = unsafe { &*self.0.cast::<AtomicU32>().add(1) };
        state.load(Ordering::SeqCst) == LIVE
    }

    pub fn begin_effect(&self) -> bool {
        let state = unsafe { &*self.0.cast::<AtomicU32>().add(1) };
        match state.compare_exchange(RUNNING, LIVE, Ordering::SeqCst, Ordering::SeqCst) {
            Ok(_) | Err(LIVE) => true,
            // Incr won and is about to cancel us. The tracee is still stopped
            // at syscall entry, so cancellation cannot leave a partial write.
            Err(REPLAY) => loop {
                if crate::tracer::termination_requested() {
                    return false;
                }
                std::thread::park_timeout(std::time::Duration::from_millis(1));
            },
            Err(_) => std::process::exit(1),
        }
    }
}

impl Drop for EffectGate {
    fn drop(&mut self) {
        unsafe {
            libc::munmap(self.0, MAPPING_BYTES);
        }
    }
}
