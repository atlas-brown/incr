use nix::sys::ptrace;
use nix::sys::signal::{Signal, raise};
use nix::unistd::execvp;
use std::ffi::CString;

/// Run in the child process: set up ptrace, install seccomp filter, then exec.
/// This function never returns.
pub fn run_child(argv: &[CString], guarded_descriptors: &[i32]) -> ! {
    ptrace::traceme().expect("ptrace::traceme failed");

    crate::seccomp::install_filter(guarded_descriptors)
        .expect("seccomp filter installation failed");

    // Stop ourselves so parent can set ptrace options before we exec
    raise(Signal::SIGSTOP).expect("raise SIGSTOP failed");

    match execvp(&argv[0], argv) {
        Ok(_) => unreachable!(),
        Err(error) => {
            let command = argv[0].to_string_lossy();
            eprintln!("observe: {command}: {error}");
            // Follow bash conventions: 127 = command not found, 126 = permission denied
            let code = match error {
                nix::Error::ENOENT => 127,
                nix::Error::EACCES => 126,
                _ => 1,
            };
            std::process::exit(code);
        }
    }
}
