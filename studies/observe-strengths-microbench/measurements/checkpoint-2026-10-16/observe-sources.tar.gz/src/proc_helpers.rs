use anyhow::Result;
use nix::sys::ptrace;
use nix::unistd::Pid;
use std::ffi::OsString;
use std::fs;
use std::io::{self, Read};
use std::os::unix::ffi::{OsStrExt, OsStringExt};
use std::os::unix::fs::{MetadataExt, OpenOptionsExt};
use std::os::unix::io::AsRawFd;
use std::path::{Path, PathBuf};
use xxhash_rust::xxh3::Xxh3;

/// Resolve the current descriptor target; descriptor tables can be shared by threads.
pub fn resolve_fd(pid: Pid, descriptor: i32) -> Option<PathBuf> {
    let descriptor_path = format!("/proc/{pid}/fd/{descriptor}");
    let target = fs::read_link(&descriptor_path).ok()?;
    if target.as_os_str().as_bytes().ends_with(b" (deleted)") {
        // A literal filename may end in the kernel's deletion marker. Otherwise
        // the descriptor no longer names this directory entry and must not write it.
        let descriptor_metadata = fs::metadata(&descriptor_path).ok()?;
        let named_metadata = fs::metadata(&target).ok()?;
        if (descriptor_metadata.dev(), descriptor_metadata.ino())
            != (named_metadata.dev(), named_metadata.ino())
        {
            return None;
        }
    }
    Some(target)
}

/// Map a tracee-relative path to a host-accessible /proc/... path that can be
/// opened or stat'd from the tracer process.
///
/// - Absolute tracee paths  -> /proc/<pid>/root/<path>
/// - Relative with AT_FDCWD -> /proc/<pid>/cwd/<path>
/// - Relative with dirfd    -> /proc/<pid>/fd/<dirfd>/<path>
pub fn resolve_tracee_path(
    pid: Pid,
    directory_descriptor: Option<i32>,
    tracee_path: &Path,
) -> Option<PathBuf> {
    if tracee_path.as_os_str().is_empty() {
        return None;
    }

    if tracee_path.is_absolute() {
        let root = PathBuf::from(format!("/proc/{pid}/root"));
        return Some(join_tracee_root(&root, tracee_path));
    }
    Some(directory_anchor(pid, directory_descriptor)?.join(tracee_path))
}

/// Procfs anchor for paths relative to a tracee's current directory or descriptor.
fn directory_anchor(pid: Pid, directory_descriptor: Option<i32>) -> Option<PathBuf> {
    match directory_descriptor {
        None | Some(libc::AT_FDCWD) => Some(PathBuf::from(format!("/proc/{pid}/cwd"))),
        Some(descriptor) if descriptor >= 0 => {
            Some(PathBuf::from(format!("/proc/{pid}/fd/{descriptor}")))
        }
        _ => None,
    }
}

/// Resolve a host-openable /proc path to the real filesystem path by opening
/// the file and reading /proc/self/fd/<ourfd>.
pub fn resolve_to_real_path(host_proc_path: &Path) -> Option<PathBuf> {
    let file = fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_PATH)
        .open(host_proc_path)
        .ok()?;
    let link = format!("/proc/self/fd/{}", file.as_raw_fd());
    let target = fs::read_link(link).ok()?;
    Some(target)
}

/// Resolve a new file through its existing parent, preserving symlink semantics.
/// Returns None when the parent cannot be opened. The result matches the path
/// subsequently reported by resolve_fd after successful creation.
pub fn resolve_new_file_real_path(
    pid: Pid,
    directory_descriptor: Option<i32>,
    tracee_path: &Path,
) -> Option<PathBuf> {
    let path = Path::new(tracee_path);
    let filename = path.file_name()?;

    // Build the procfs path for the *parent* directory so we can open it and
    // get its kernel-canonical path (following all symlinks).
    let parent_host = match path.parent() {
        // Non-empty relative subdirectory component (e.g. "subdir/file" → parent "subdir")
        Some(parent) if !parent.as_os_str().is_empty() && parent != Path::new(".") => {
            resolve_tracee_path(pid, directory_descriptor, parent)?
        }
        // File is directly under dirfd / cwd (e.g. "file" or "./file").
        _ => directory_anchor(pid, directory_descriptor)?,
    };

    // Open the parent directory and read its canonical path from /proc/self/fd.
    let canonical_parent = resolve_to_real_path(&parent_host)?;
    Some(canonical_parent.join(filename))
}

/// Follow at most 40 symlinks to a missing creation target. Return None for
/// ordinary missing paths, existing files, inaccessible paths or symlink loops.
pub fn follow_dangling_symlink(path: &Path) -> Option<PathBuf> {
    const MAX_DEPTH: usize = 40;
    let mut current = PathBuf::from(path);
    let mut depth = 0usize;
    loop {
        match fs::symlink_metadata(&current) {
            Ok(metadata) if metadata.file_type().is_symlink() => {
                depth += 1;
                if depth > MAX_DEPTH {
                    return None;
                }
                let target = fs::read_link(&current).ok()?;
                if target.is_absolute() {
                    current = target;
                } else {
                    let parent = current.parent()?.to_path_buf();
                    current = normalize_path(&parent.join(&target));
                }
            }
            Ok(_) => return None, // exists as a non-symlink; not a dangling chain
            Err(error) if error.kind() == io::ErrorKind::NotFound => {
                return (depth > 0).then_some(current);
            }
            Err(_) => return None,
        }
    }
}

/// Best-effort path resolution that does NOT open the leaf path.
/// Works even for already-unlinked files.
pub fn best_effort_resolve(
    pid: Pid,
    directory_descriptor: Option<i32>,
    tracee_path: &Path,
) -> Option<PathBuf> {
    if tracee_path.as_os_str().is_empty() {
        return None;
    }

    let path = Path::new(tracee_path);

    if path.is_absolute() {
        if let Ok(root) = fs::read_link(format!("/proc/{}/root", pid)) {
            let joined = join_tracee_root(&root, path);
            return Some(normalize_path(&joined));
        }
        return Some(normalize_path(Path::new(tracee_path)));
    }

    let base = fs::read_link(directory_anchor(pid, directory_descriptor)?).ok()?;

    let joined = Path::new(&base).join(tracee_path);
    Some(normalize_path(&joined))
}

/// Remove the root component before joining; repeated leading slashes must not
/// turn the tracee path into an absolute host path. Preserve symlink/.. traversal.
fn join_tracee_root(root: &Path, absolute_path: &Path) -> PathBuf {
    root.join(
        absolute_path
            .strip_prefix("/")
            .expect("absolute tracee path"),
    )
}

/// Keep parent components: link/.. must be resolved by the filesystem, not lexically.
fn normalize_path(path: &Path) -> PathBuf {
    path.components()
        .filter(|component| *component != std::path::Component::CurDir)
        .collect()
}

/// Read a NUL-terminated C string from the tracee's memory at `address`.
/// Fast path: process_vm_readv. Fallback: ptrace::read word-by-word.
pub fn read_path(pid: Pid, address: u64) -> Result<PathBuf> {
    const MAX_PATH_LEN: usize = 4096;

    // Fast path with process_vm_readv
    let mut buffer = [0u8; 4096];
    let local = libc::iovec {
        iov_base: buffer.as_mut_ptr() as _,
        iov_len: buffer.len(),
    };
    let remote = libc::iovec {
        iov_base: address as _,
        iov_len: buffer.len(),
    };
    let bytes_read = unsafe { libc::process_vm_readv(pid.as_raw() as _, &local, 1, &remote, 1, 0) };
    if bytes_read > 0 {
        let read_len = bytes_read as usize;
        if let Some(nul_pos) = buffer[..read_len].iter().position(|&byte| byte == 0) {
            return Ok(PathBuf::from(OsString::from_vec(
                buffer[..nul_pos].to_vec(),
            )));
        }
        // Short read with no NUL found — fall through to ptrace word-by-word.
    }

    // Fallback: ptrace::read word-by-word
    let mut out = Vec::new();
    let mut cursor = address as usize;
    loop {
        let word = ptrace::read(pid, cursor as ptrace::AddressType)?;
        for byte in word.to_ne_bytes() {
            if byte == 0 {
                return Ok(PathBuf::from(OsString::from_vec(out)));
            }
            out.push(byte);
            anyhow::ensure!(out.len() < MAX_PATH_LEN, "tracee pathname exceeds PATH_MAX");
        }
        cursor += std::mem::size_of::<libc::c_long>();
    }
}

/// Is the host-openable proc path a regular file?
pub fn is_regular_file(host_proc_path: &Path) -> bool {
    fs::metadata(host_proc_path)
        .map(|metadata| metadata.is_file())
        .unwrap_or(false)
}

/// Is the host-openable proc path a regular file or directory?
/// (For read tracking -- reads can target either.)
pub fn is_readable_node(host_proc_path: &Path) -> bool {
    fs::metadata(host_proc_path)
        .map(|metadata| metadata.is_file() || metadata.is_dir())
        .unwrap_or(false)
}

/// File identity by (st_dev, st_ino) for dedup.
pub fn file_id(host_path: &Path) -> Option<(u64, u64)> {
    fs::metadata(host_path)
        .ok()
        .map(|metadata| (metadata.dev(), metadata.ino()))
}

/// File identity from a tracee's fd via /proc/<pid>/fd/<fd>.
pub fn file_id_from_fd(pid: Pid, descriptor: i32) -> Option<(u64, u64)> {
    let proc_path = format!("/proc/{}/fd/{}", pid, descriptor);
    fs::metadata(&proc_path)
        .ok()
        .map(|metadata| (metadata.dev(), metadata.ino()))
}

/// Hash a file via /proc/<pid>/fd/<fd>. The tracee must be stopped.
pub fn hash_fd(pid: Pid, descriptor: i32) -> io::Result<u64> {
    let proc_path = format!("/proc/{}/fd/{}", pid, descriptor);
    let file = fs::File::open(proc_path)?;
    xxh3_stream(file)
}

/// Hash a file via a host-accessible proc path.
pub fn hash_host_path(host_path: &Path) -> io::Result<u64> {
    let file = fs::File::open(host_path)?;
    xxh3_stream(file)
}

/// Stream `reader` through the xxh3 hasher and return the 64-bit digest.
fn xxh3_stream<R: Read>(mut reader: R) -> io::Result<u64> {
    let mut hasher = Xxh3::new();
    io::copy(&mut reader, &mut hasher)?;
    Ok(hasher.digest())
}

/// Read the flags field from an openat2 `struct open_how` in tracee memory.
/// Layout: struct open_how { u64 flags; u64 mode; u64 resolve; }
pub fn read_open_how_flags(pid: Pid, address: u64) -> Option<u64> {
    if address == 0 {
        return None;
    }
    ptrace::read(pid, address as ptrace::AddressType)
        .ok()
        .map(|word| word as u64)
}

#[cfg(test)]
mod tests {
    use super::join_tracee_root;
    use std::path::Path;

    #[test]
    fn tracee_root_preserves_kernel_path_resolution() {
        for path in ["/file", "//file", "///file"] {
            assert_eq!(
                join_tracee_root(Path::new("/jail"), Path::new(path)),
                Path::new("/jail/file")
            );
        }
        assert_eq!(
            join_tracee_root(Path::new("/jail"), Path::new("//link/../file")),
            Path::new("/jail/link/../file")
        );
        assert_eq!(
            join_tracee_root(Path::new("/jail"), Path::new("/")),
            Path::new("/jail")
        );
    }
}
