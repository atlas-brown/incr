//! Lossless JSON reports and human-readable trace summaries.
use anyhow::Result;
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};

use crate::unix_path::Borrowed as ReportPath;
use crate::{snapshot, tracer};

#[derive(serde::Serialize)]
struct JsonReport<'report> {
    dependency_version: u32,
    guarded_descriptors: &'report [i32],
    directory_access_only: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    content_opens: Option<Vec<ReportPath<'report>>>,
    overwrites: Vec<ReportPath<'report>>,
    replay_barriers: Vec<&'report str>,
    dependencies: Vec<JsonDependency<'report>>,
    reads: Vec<ReportPath<'report>>,
    writes: Vec<JsonWrite<'report>>,
}

#[derive(serde::Serialize)]
#[serde(untagged)]
enum JsonWrite<'report> {
    Path(ReportPath<'report>),
    Hashed {
        path: ReportPath<'report>,
        pre_hash: Option<String>,
    },
}

#[derive(serde::Serialize)]
struct JsonDependency<'report> {
    path: ReportPath<'report>,
    #[serde(flatten)]
    state: &'report crate::dependency::Dependency,
}

/// Emit to the requested JSON file, or to stderr in the selected display format.
pub(crate) fn write(
    result: &tracer::TraceResult,
    destination: Option<&Path>,
    json: bool,
) -> Result<()> {
    if let Some(path) = destination {
        write_report_to_file(result, path)
    } else {
        print_report(result, json);
        Ok(())
    }
}

/// Filter out transient/noisy paths that change every run.
pub(crate) fn filter_paths(mut result: tracer::TraceResult) -> tracer::TraceResult {
    result
        .content_opens
        .retain(|path| !snapshot::is_noisy_path(path));
    result
        .read_paths
        .retain(|path| !snapshot::is_noisy_path(path));
    result
        .write_paths
        .retain(|path| !snapshot::is_noisy_path(path));
    result
        .overwrites
        .retain(|path| !snapshot::is_noisy_path(path));
    result
        .pre_hashes
        .retain(|path, _| !snapshot::is_noisy_path(path));
    result
        .pre_reads
        .retain(|path, _| !snapshot::is_noisy_path(path));
    result
}

fn build_json_report(result: &tracer::TraceResult) -> JsonReport<'_> {
    use crate::state::PreWrite;
    let mut reads: Vec<_> = result.read_paths.iter().map(PathBuf::as_path).collect();
    reads.sort_unstable();
    let mut paths: Vec<_> = result.write_paths.iter().map(PathBuf::as_path).collect();
    paths.sort_unstable();
    let has_hashes = !result.pre_hashes.is_empty();
    let writes = paths
        .into_iter()
        .map(|path| {
            if !has_hashes {
                return JsonWrite::Path(ReportPath(path));
            }
            let pre_hash = result.pre_hashes.get(path).map(|state| match state {
                PreWrite::Hash(hash) => format!("{hash:016x}"),
                PreWrite::Nonexistent => "nonexistent".to_owned(),
                PreWrite::Unreadable => "unreadable".to_owned(),
            });
            JsonWrite::Hashed {
                path: ReportPath(path),
                pre_hash,
            }
        })
        .collect();
    let mut replay_barriers: Vec<_> = result.replay_barriers.iter().map(String::as_str).collect();
    replay_barriers.sort_unstable();
    JsonReport {
        guarded_descriptors: &result.guarded_descriptors,
        dependency_version: if !result.guarded_descriptors.is_empty() {
            12
        } else if result.record_content_opens {
            11
        } else if result.directory_access_only {
            10
        } else {
            9
        },
        directory_access_only: result.directory_access_only,
        content_opens: result.record_content_opens.then(|| {
            let mut paths: Vec<_> = result.content_opens.iter().map(PathBuf::as_path).collect();
            paths.sort_unstable();
            paths.into_iter().map(ReportPath).collect()
        }),
        overwrites: {
            let mut paths: Vec<_> = result.overwrites.iter().map(PathBuf::as_path).collect();
            paths.sort_unstable();
            paths.into_iter().map(ReportPath).collect()
        },
        reads: reads.into_iter().map(ReportPath).collect(),
        writes,
        replay_barriers,
        dependencies: {
            let mut entries: Vec<_> = result.pre_reads.iter().collect();
            entries.sort_unstable_by_key(|(path, _)| *path);
            entries
                .into_iter()
                .map(|(path, state)| JsonDependency {
                    path: ReportPath(path),
                    state,
                })
                .collect()
        },
    }
}

/// Serialize the trace result as a pretty-printed JSON report and write it to
/// `path`, as requested by `--output`.
fn write_report_to_file(result: &tracer::TraceResult, path: &std::path::Path) -> Result<()> {
    let report = build_json_report(result);
    let mut file = BufWriter::with_capacity(65536, File::create(path)?);
    serde_json::to_writer_pretty(&mut file, &report)?;
    file.flush()?;
    Ok(())
}

/// Print the trace result to stderr. When `json` is true the output is
/// machine-readable JSON; otherwise a human-readable summary is printed.
fn print_report(result: &tracer::TraceResult, json: bool) {
    use crate::state::PreWrite;

    if json {
        let report = build_json_report(result);
        eprintln!(
            "{}",
            serde_json::to_string_pretty(&report).expect("JSON serialization")
        );
        return;
    }

    let mut reads: Vec<&Path> = result.read_paths.iter().map(PathBuf::as_path).collect();
    let mut writes: Vec<&Path> = result.write_paths.iter().map(PathBuf::as_path).collect();
    reads.sort();
    writes.sort();
    let has_hashes = !result.pre_hashes.is_empty();

    eprintln!("--- observe: file access report ---");
    eprintln!("Reads:");
    for path in &reads {
        eprintln!("  {}", path.display());
    }
    eprintln!("Writes:");
    for path in &writes {
        if has_hashes {
            let annotation = match result.pre_hashes.get(*path) {
                Some(PreWrite::Hash(hash)) => format!(" (pre-hash: {hash:016x})"),
                Some(PreWrite::Nonexistent) => " (new file)".to_string(),
                Some(PreWrite::Unreadable) => " (unreadable)".to_string(),
                None => String::new(),
            };
            eprintln!("  {}{}", path.display(), annotation);
        } else {
            eprintln!("  {}", path.display());
        }
    }
}
