//! Capture open preconditions before truncation, then classify the returned descriptor.
use nix::unistd::Pid;

use super::{SyscallEntry, capture_pre_hash, maybe_prehash_host_path};
use crate::state::{PreWrite, TracerState};
use crate::{proc_helpers, snapshot};

/// Open arguments captured at entry, including the pointed-to openat2 flags.
/// Keeping these with the entry prevents later tracee memory from changing how
/// the gate, snapshot and exit handlers interpret the same syscall.
#[derive(Clone, Copy, Debug)]
pub(super) struct OpenArguments {
    directory_descriptor: Option<i32>,
    path_address: u64,
    flags: u64,
}

impl OpenArguments {
    pub(super) fn decode(
        number: i64,
        arguments: &[u64; 6],
        read_flags: impl FnOnce(u64) -> Option<u64>,
    ) -> Option<Self> {
        let (directory_descriptor, path_address, flags) = match number {
            libc::SYS_open => (None, arguments[0], arguments[1]),
            libc::SYS_creat => (
                None,
                arguments[0],
                (libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC) as u64,
            ),
            libc::SYS_openat => (Some(arguments[0] as i32), arguments[1], arguments[2]),
            libc::SYS_openat2 => (
                Some(arguments[0] as i32),
                arguments[1],
                read_flags(arguments[2])?,
            ),
            _ => return None,
        };
        Some(Self {
            directory_descriptor,
            path_address,
            flags,
        })
    }
}

pub(super) fn has_live_effect(pid: Pid, entry: &SyscallEntry) -> bool {
    let Some(arguments) = entry.open else {
        return true;
    };
    if arguments.flags & libc::O_PATH as u64 != 0 {
        return false;
    }
    if flags_imply_write(arguments.flags) {
        return true;
    }
    let path = proc_helpers::read_path(pid, arguments.path_address).unwrap_or_default();
    proc_helpers::resolve_tracee_path(pid, arguments.directory_descriptor, &path)
        .and_then(|path| std::fs::metadata(path).ok())
        .is_some_and(|metadata| !metadata.is_file() && !metadata.is_dir())
}

/// Return `true` if any of the open flags (`O_WRONLY`, `O_RDWR`, `O_TRUNC`,
/// or `O_CREAT`) indicate that the opened file will be modified.
fn flags_imply_write(flags: u64) -> bool {
    flags & libc::O_PATH as u64 == 0
        && flags & (libc::O_WRONLY | libc::O_RDWR | libc::O_TRUNC | libc::O_CREAT) as u64 != 0
}

/// At open entry: handle pre-write hashing and snapshotting for O_TRUNC (before
/// the kernel truncates) and O_CREAT on files that don't exist yet.
pub(super) fn handle_open_entry(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    let Some(arguments) = entry.open else {
        state.record_unsupported_effect("unreadable open flags");
        return;
    };
    let directory_descriptor = arguments.directory_descriptor;
    let truncates = arguments.flags & libc::O_TRUNC as u64 != 0;
    let creates = arguments.flags & libc::O_CREAT as u64 != 0;

    let tracee_path = proc_helpers::read_path(pid, arguments.path_address).unwrap_or_default();
    if state.dependencies {
        if let Some(real_path) =
            proc_helpers::best_effort_resolve(pid, directory_descriptor, &tracee_path)
        {
            // Writes depend on pre-existing contents/metadata too: partial
            // writes retain the suffix, O_EXCL can fail, and truncation must
            // preserve an existing file's permissions and hard-link identity.
            if flags_imply_write(arguments.flags) {
                state.record_write_precondition(real_path);
            } else {
                state.record_read(real_path);
            }
        }
        if let Some(host) =
            proc_helpers::resolve_tracee_path(pid, directory_descriptor, &tracee_path)
            && proc_helpers::is_readable_node(&host)
            && let Some(real_path) = proc_helpers::resolve_to_real_path(&host)
        {
            if flags_imply_write(arguments.flags) {
                state.record_write_precondition(real_path);
            } else {
                state.record_read(real_path);
            }
        }
    }
    // O_PATH ignores access, creation and truncation flags.
    if arguments.flags & libc::O_PATH as u64 != 0 || (!truncates && !creates) {
        return;
    }
    if let Some(host_path) =
        proc_helpers::resolve_tracee_path(pid, directory_descriptor, &tracee_path)
    {
        if proc_helpers::is_regular_file(&host_path) {
            if truncates {
                // O_TRUNC will zero the file -- hash/snapshot it now before the kernel does.
                if let Some(real_path) = proc_helpers::resolve_to_real_path(&host_path) {
                    if state.hash_writes {
                        maybe_prehash_host_path(state, &host_path, &real_path);
                    }
                    snapshot::maybe_snapshot_host_path(&mut state.snapshot, &host_path, &real_path);
                }
            }
            // If O_CREAT without O_TRUNC on an existing file, the open
            // won't modify content. handle_open_exit will hash/snapshot at exit
            // if needed (e.g. O_WRONLY, before any write() happens).
        } else if creates {
            // Use the same canonical key as the descriptor returned at exit.
            let real_path =
                proc_helpers::resolve_new_file_real_path(pid, directory_descriptor, &tracee_path)
                    .or_else(|| {
                        proc_helpers::best_effort_resolve(pid, directory_descriptor, &tracee_path)
                    });
            if let Some(real_path) = real_path {
                // Creation follows dangling links; the link itself must survive revert.
                let real_path =
                    proc_helpers::follow_dangling_symlink(&real_path).unwrap_or(real_path);
                if !matches!(std::fs::symlink_metadata(&real_path),
                    Err(error) if error.kind() == std::io::ErrorKind::NotFound)
                {
                    return;
                }
                if state.hash_writes && !state.pre_hashes.contains_key(&real_path) {
                    state
                        .pre_hashes
                        .insert(real_path.clone(), PreWrite::Nonexistent);
                }
                snapshot::snapshot_nonexistent(&mut state.snapshot, &real_path);
            }
        }
    }
}

/// open/openat/openat2/creat exit: on success, classify as read or write.
pub(super) fn handle_open_exit(
    state: &mut TracerState,
    pid: Pid,
    entry: &SyscallEntry,
    return_value: i64,
) {
    if return_value < 0 {
        return; // failed
    }
    let descriptor = return_value as i32;
    let Some(arguments) = entry.open else {
        return;
    };

    let path = match proc_helpers::resolve_fd(pid, descriptor) {
        Some(path) => path,
        None => return,
    };

    let proc_fd = std::path::PathBuf::from(format!("/proc/{pid}/fd/{descriptor}"));
    if !proc_helpers::is_readable_node(&proc_fd) {
        if state.dependencies {
            state.record_read(path);
        }
        return;
    }

    let flags = arguments.flags;
    if flags & libc::O_TRUNC as u64 != 0
        && flags & (libc::O_EXCL | libc::O_APPEND | libc::O_PATH) as u64 == 0
    {
        state.record_overwrite(&path);
    } else if state.dependencies && flags_imply_write(flags) {
        // A partial write or append can retain/consume the original bytes.
        state.record_read(path.clone());
    }

    if flags_imply_write(flags) {
        if proc_helpers::is_regular_file(&proc_fd) {
            // Entry handling already captured files changed by O_TRUNC/O_CREAT.
            capture_pre_hash(
                state,
                &path,
                || proc_helpers::file_id_from_fd(pid, descriptor),
                || proc_helpers::hash_fd(pid, descriptor),
            );
            // Snapshot at exit for O_WRONLY/O_RDWR on existing files
            // (O_TRUNC and O_CREAT-new were already handled at entry).
            snapshot::maybe_snapshot_fd(&mut state.snapshot, pid, descriptor, &path);

            // O_RDWR and append depend on the original contents.
            if (flags & libc::O_ACCMODE as u64) == libc::O_RDWR as u64
                || (state.dependencies && (flags & libc::O_APPEND as u64) != 0)
            {
                state.record_read(path.clone());
            }

            state.write_paths.insert(path);
        }
    } else {
        // Successful readable opens are distinct from stat/access-only probes.
        // O_PATH provides metadata access without opening content for reading.
        if state.record_content_opens
            && flags & libc::O_PATH as u64 == 0
            && proc_helpers::is_regular_file(&proc_fd)
        {
            state.content_opens.insert(path.clone());
        }
        state.record_read(path);
    }
}
