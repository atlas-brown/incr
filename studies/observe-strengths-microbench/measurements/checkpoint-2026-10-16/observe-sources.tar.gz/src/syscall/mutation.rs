//! Snapshot and track changes to directory entries and renamed trees.
use nix::unistd::Pid;
use std::path::Path;

use super::{SyscallEntry, maybe_prehash_host_path};
use crate::state::TracerState;
use crate::{proc_helpers, snapshot};

/// Snapshot both old and new paths of a rename before the rename executes.
/// The old path still exists; the new path may or may not exist.
pub(super) fn handle_rename_entry(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    if !state.snapshot.is_enabled() && !state.dependencies {
        return;
    }
    let number = entry.number;
    let (source_directory, source_address, destination_directory, destination_address) =
        if number == libc::SYS_rename {
            (None, entry.arguments[0], None, entry.arguments[1])
        } else {
            (
                Some(entry.arguments[0] as i32),
                entry.arguments[1],
                Some(entry.arguments[2] as i32),
                entry.arguments[3],
            )
        };

    let old_path = proc_helpers::read_path(pid, source_address).unwrap_or_default();
    let new_path = proc_helpers::read_path(pid, destination_address).unwrap_or_default();
    let source = proc_helpers::best_effort_resolve(pid, source_directory, &old_path);
    let destination = proc_helpers::best_effort_resolve(pid, destination_directory, &new_path);
    let exchange = entry.number == libc::SYS_renameat2
        && entry.arguments[4] & libc::RENAME_EXCHANGE as u64 != 0;
    if let (Some(source), Some(destination)) = (source, destination) {
        if state.dependencies {
            record_rename_tree(state, &source, RenameAccess::Input);
            record_rename_tree(state, &destination, RenameAccess::Input);
            record_rename_destinations(state, &source, &destination);
            if exchange {
                record_rename_destinations(state, &destination, &source);
            }
            if let Some(host_path) =
                proc_helpers::resolve_tracee_path(pid, source_directory, &old_path)
                && proc_helpers::is_regular_file(&host_path)
            {
                maybe_prehash_host_path(state, &host_path, &source);
            }
        }
        snapshot::snapshot_rename_tree(&mut state.snapshot, &source, &destination);
        if exchange {
            snapshot::snapshot_rename_tree(&mut state.snapshot, &destination, &source);
        }
    }
}

/// Snapshot the target of an unlink/unlinkat/rmdir before the kernel removes it.
pub(super) fn handle_unlink_entry(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    if !state.snapshot.is_enabled() && !state.dependencies {
        return;
    }
    let number = entry.number;
    let (directory_descriptor, path_address) =
        if number == libc::SYS_unlink || number == libc::SYS_rmdir {
            (None, entry.arguments[0])
        } else {
            (Some(entry.arguments[0] as i32), entry.arguments[1])
        };

    let path = proc_helpers::read_path(pid, path_address).unwrap_or_default();

    let is_dir_removal = number == libc::SYS_rmdir
        || (number == libc::SYS_unlinkat && (entry.arguments[2] as i32 & libc::AT_REMOVEDIR) != 0);

    if is_dir_removal {
        if let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path)
        {
            if state.dependencies {
                state.record_read(real_path.clone());
            }
            if std::fs::symlink_metadata(&real_path).is_ok_and(|metadata| metadata.is_dir()) {
                snapshot::snapshot_existing_dir(&mut state.snapshot, &real_path);
            }
        }
        return;
    }

    // unlink / unlinkat (without AT_REMOVEDIR): could be a regular file or a symlink.
    // Use best_effort_resolve to get the path of the file itself (not following symlinks).
    if let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path) {
        if state.dependencies {
            state.record_read(real_path.clone());
        }
        // Check if it is a symlink (lstat does not follow).
        if std::fs::symlink_metadata(&real_path)
            .map(|metadata| metadata.file_type().is_symlink())
            .unwrap_or(false)
        {
            if let Ok(target) = std::fs::read_link(&real_path) {
                snapshot::snapshot_existing_symlink(&mut state.snapshot, &real_path, &target);
            }
        } else if let Some(host_path) =
            proc_helpers::resolve_tracee_path(pid, directory_descriptor, &path)
            && proc_helpers::is_regular_file(&host_path)
        {
            snapshot::maybe_snapshot_host_path(&mut state.snapshot, &host_path, &real_path);
        }
    }
}

/// Record both affected trees after a successful rename.
pub(super) fn handle_rename_exit(
    state: &mut TracerState,
    pid: Pid,
    entry: &SyscallEntry,
    return_value: i64,
) {
    if return_value < 0 {
        return;
    }
    let number = entry.number;

    let (source_directory, source_address, destination_directory, destination_address) =
        if number == libc::SYS_rename {
            (None, entry.arguments[0], None, entry.arguments[1])
        } else {
            // renameat/renameat2: (olddirfd, oldpath, newdirfd, newpath, ...)
            (
                Some(entry.arguments[0] as i32),
                entry.arguments[1],
                Some(entry.arguments[2] as i32),
                entry.arguments[3],
            )
        };

    let old_path = proc_helpers::read_path(pid, source_address).unwrap_or_default();
    if let Some(real_path) = proc_helpers::best_effort_resolve(pid, source_directory, &old_path) {
        if state.dependencies {
            record_rename_tree(state, &real_path, RenameAccess::Output);
        }
        state.record_read(real_path);
    }

    let new_path = proc_helpers::read_path(pid, destination_address).unwrap_or_default();
    if let Some(real_path) =
        proc_helpers::best_effort_resolve(pid, destination_directory, &new_path)
    {
        if state.dependencies {
            record_rename_tree(state, &real_path, RenameAccess::Output);
        } else {
            state.write_paths.insert(real_path);
        }
    }
}

/// link/linkat/symlink/symlinkat exit: on success, mark new path as write.
pub(super) fn handle_link_exit(
    state: &mut TracerState,
    pid: Pid,
    entry: &SyscallEntry,
    return_value: i64,
) {
    if return_value < 0 {
        return;
    }
    let number = entry.number;

    let (directory_descriptor, path_address) =
        if number == libc::SYS_link || number == libc::SYS_symlink {
            (None, entry.arguments[1]) // Both legacy calls have destination in arguments[1].
        } else if number == libc::SYS_linkat {
            (Some(entry.arguments[2] as i32), entry.arguments[3]) // linkat(olddirfd, old, newdirfd, new, flags)
        } else {
            // symlinkat(target, newdirfd, linkpath)
            (Some(entry.arguments[1] as i32), entry.arguments[2])
        };

    let path = proc_helpers::read_path(pid, path_address).unwrap_or_default();
    if let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path) {
        // The new link/symlink was just created -- record as nonexistent
        // so revert can remove it.
        snapshot::snapshot_nonexistent(&mut state.snapshot, &real_path);
        state.write_paths.insert(real_path);
    }
}

/// unlink/unlinkat/rmdir exit: on success, mark path as write.
pub(super) fn handle_unlink_exit(
    state: &mut TracerState,
    pid: Pid,
    entry: &SyscallEntry,
    return_value: i64,
) {
    if return_value < 0 {
        return;
    }
    let number = entry.number;

    let (directory_descriptor, path_address) =
        if number == libc::SYS_unlink || number == libc::SYS_rmdir {
            (None, entry.arguments[0])
        } else {
            // unlinkat(dirfd, path, flags)
            (Some(entry.arguments[0] as i32), entry.arguments[1])
        };

    let path = proc_helpers::read_path(pid, path_address).unwrap_or_default();
    if let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path) {
        state.write_paths.insert(real_path);
    }
}

/// mkdir/mkdirat exit: on success, mark path as write.
pub(super) fn handle_create_node_exit(
    state: &mut TracerState,
    pid: Pid,
    entry: &SyscallEntry,
    return_value: i64,
) {
    if return_value < 0 {
        return;
    }
    let number = entry.number;

    let (directory_descriptor, path_address) =
        if number == libc::SYS_mkdir || number == libc::SYS_mknod {
            (None, entry.arguments[0])
        } else {
            // mkdirat(dirfd, path, mode)
            (Some(entry.arguments[0] as i32), entry.arguments[1])
        };

    let path = proc_helpers::read_path(pid, path_address).unwrap_or_default();
    if let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path) {
        // Directory was just created -- record as nonexistent so revert can remove it.
        snapshot::snapshot_nonexistent(&mut state.snapshot, &real_path);
        state.write_paths.insert(real_path);
    }
}

enum RenameAccess {
    Input,
    Output,
}

fn record_rename_tree(state: &mut TracerState, root: &Path, access: RenameAccess) {
    let mut pending = vec![std::path::PathBuf::from(root)];
    while let Some(path) = pending.pop() {
        let name = path.clone();
        if matches!(access, RenameAccess::Output) {
            state.write_paths.insert(name);
        } else {
            state.record_read(name);
        }
        if !std::fs::symlink_metadata(&path).is_ok_and(|metadata| metadata.is_dir()) {
            continue;
        }
        match std::fs::read_dir(path) {
            Ok(entries) => {
                for entry in entries {
                    match entry {
                        Ok(entry) => pending.push(entry.path()),
                        Err(_) => {
                            state
                                .replay_barriers
                                .insert("unreadable renamed directory".into());
                        }
                    }
                }
            }
            Err(_) => {
                state
                    .replay_barriers
                    .insert("unreadable renamed directory".into());
            }
        }
    }
}

fn record_rename_destinations(state: &mut TracerState, source: &Path, destination: &Path) {
    let source = std::path::Path::new(source);
    let destination = std::path::Path::new(destination);
    let paths: Vec<_> = state
        .read_paths
        .iter()
        .filter_map(|path| std::path::Path::new(path).strip_prefix(source).ok())
        .filter(|relative| !relative.as_os_str().is_empty())
        .map(|relative| destination.join(relative))
        .collect();
    for path in paths {
        state.record_read(path);
    }
}
