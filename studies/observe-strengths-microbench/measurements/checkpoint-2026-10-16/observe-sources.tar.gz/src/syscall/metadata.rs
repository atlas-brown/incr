//! Track metadata dependencies, metadata changes and descriptor transfers.
use nix::unistd::Pid;

use super::{SyscallEntry, maybe_prehash_fd, maybe_prehash_host_path};
use crate::state::TracerState;
use crate::{proc_helpers, snapshot};

/// Path-based metadata reads: newfstatat, statx, access, faccessat, faccessat2,
/// readlink, readlinkat
pub(super) fn handle_path_metadata(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    let number = entry.number;

    let is_readlink = number == libc::SYS_readlink || number == libc::SYS_readlinkat;

    let (directory_descriptor, path_address) = if number == libc::SYS_access
        || number == libc::SYS_readlink
        || number == libc::SYS_stat
        || number == libc::SYS_lstat
    {
        (None, entry.arguments[0])
    } else {
        // newfstatat(dirfd, path, ...), statx(dirfd, path, ...),
        // faccessat(dirfd, path, ...), faccessat2(dirfd, path, ...),
        // readlinkat(dirfd, path, ...)
        (Some(entry.arguments[0] as i32), entry.arguments[1])
    };

    let path = proc_helpers::read_path(pid, path_address).unwrap_or_default();

    if is_readlink {
        // readlink reads the symlink itself — don't follow it.
        if let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path)
            && (state.dependencies || std::fs::symlink_metadata(&real_path).is_ok())
        {
            state.record_read(real_path);
        }
        return;
    }

    if state.dependencies
        && let Some(real_path) = proc_helpers::best_effort_resolve(pid, directory_descriptor, &path)
    {
        // Track the directory entry as well as its resolved target: lstat
        // and changing a symlink must invalidate cached results.
        state.record_metadata_read(real_path);
    }
    if let Some(host_path) = proc_helpers::resolve_tracee_path(pid, directory_descriptor, &path) {
        // Special nodes represent live communication rather than reusable content.
        if proc_helpers::is_readable_node(&host_path) {
            if let Some(real_path) = proc_helpers::resolve_to_real_path(&host_path) {
                state.record_metadata_read(real_path);
            }
        } else if state.dependencies
            && let Some(real_path) =
                proc_helpers::best_effort_resolve(pid, directory_descriptor, &path)
        {
            // A failed existence check is a dependency too; non-regular nodes
            // carry live communication semantics and must not be memoized away.
            state.record_metadata_read(real_path);
        }
    }
}

/// truncate(path, length) -- write to a path
pub(super) fn handle_truncate(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    let path = proc_helpers::read_path(pid, entry.arguments[0]).unwrap_or_default();
    if state.dependencies
        && let Some(real_path) = proc_helpers::best_effort_resolve(pid, None, &path)
    {
        state.record_read(real_path);
    }
    if let Some(host_path) = proc_helpers::resolve_tracee_path(pid, None, &path)
        && proc_helpers::is_regular_file(&host_path)
        && let Some(real_path) = proc_helpers::resolve_to_real_path(&host_path)
    {
        maybe_prehash_host_path(state, &host_path, &real_path);
        snapshot::maybe_snapshot_host_path(&mut state.snapshot, &host_path, &real_path);
        state.write_paths.insert(real_path);
    }
}

/// Cross-fd: sendfile(destination_descriptor, source_descriptor, ...) and copy_file_range(source_descriptor, ..., destination_descriptor, ...)
pub(super) fn handle_transfer(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    let (source_descriptor, destination_descriptor) = if entry.number == libc::SYS_sendfile {
        (entry.arguments[1] as i32, entry.arguments[0] as i32) // sendfile(out, in, ...)
    } else {
        (entry.arguments[0] as i32, entry.arguments[2] as i32) // copy_file_range(in, ..., out, ...)
    };

    if let Some(path) = proc_helpers::resolve_fd(pid, source_descriptor) {
        let proc_fd = std::path::PathBuf::from(format!("/proc/{pid}/fd/{source_descriptor}"));
        if proc_helpers::is_readable_node(&proc_fd) {
            state.record_read(path);
        }
    }

    if let Some(path) = proc_helpers::resolve_fd(pid, destination_descriptor) {
        let proc_fd = std::path::PathBuf::from(format!("/proc/{pid}/fd/{destination_descriptor}"));
        if proc_helpers::is_regular_file(&proc_fd) {
            maybe_prehash_fd(state, pid, destination_descriptor, &path);
            snapshot::maybe_snapshot_fd(&mut state.snapshot, pid, destination_descriptor, &path);
            state.write_paths.insert(path);
        }
    }
}

pub(super) fn handle_extended_attributes(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    let descriptor_based = matches!(
        entry.number,
        libc::SYS_fgetxattr | libc::SYS_flistxattr | libc::SYS_fsetxattr | libc::SYS_fremovexattr
    );
    let writes = matches!(
        entry.number,
        libc::SYS_setxattr
            | libc::SYS_lsetxattr
            | libc::SYS_fsetxattr
            | libc::SYS_removexattr
            | libc::SYS_lremovexattr
            | libc::SYS_fremovexattr
    );
    let path = if descriptor_based {
        proc_helpers::resolve_fd(pid, entry.arguments[0] as i32)
    } else {
        proc_helpers::read_path(pid, entry.arguments[0])
            .ok()
            .and_then(|path| proc_helpers::best_effort_resolve(pid, None, &path))
    };
    if let Some(path) = path
        && (state.dependencies || proc_helpers::is_readable_node(&path))
    {
        state.record_read(path.clone());
        if matches!(
            entry.number,
            libc::SYS_getxattr | libc::SYS_listxattr | libc::SYS_setxattr | libc::SYS_removexattr
        ) && let Some(target) = proc_helpers::resolve_to_real_path(&path)
        {
            state.record_read(target);
        }
        if writes {
            state.write_paths.insert(path);
        }
    }
    if writes {
        // Attribute reads validate ctime; replay cannot install attribute changes yet.
        state
            .replay_barriers
            .insert("extended file attributes".into());
    }
}

pub(super) fn handle_metadata_write(state: &mut TracerState, pid: Pid, entry: &SyscallEntry) {
    let number = entry.number;
    let descriptor_only = number == libc::SYS_fchmod
        || number == libc::SYS_fchown
        || (number == libc::SYS_utimensat && entry.arguments[1] == 0);
    let path = if descriptor_only {
        proc_helpers::resolve_fd(pid, entry.arguments[0] as i32)
    } else {
        let plain_path = matches!(
            number,
            libc::SYS_chmod
                | libc::SYS_chown
                | libc::SYS_lchown
                | libc::SYS_utime
                | libc::SYS_utimes
        );
        let (directory, address) = if plain_path {
            (None, entry.arguments[0])
        } else {
            (Some(entry.arguments[0] as i32), entry.arguments[1])
        };
        let name = proc_helpers::read_path(pid, address).unwrap_or_default();
        let flags = match number {
            libc::SYS_fchownat => entry.arguments[4] as i32,
            libc::SYS_utimensat | libc::SYS_fchmodat2 => entry.arguments[3] as i32,
            _ => 0,
        };
        if name.is_empty() && flags & libc::AT_EMPTY_PATH != 0 {
            proc_helpers::resolve_fd(pid, entry.arguments[0] as i32)
        } else {
            let named_path = proc_helpers::best_effort_resolve(pid, directory, &name);
            if state.dependencies
                && let Some(path) = &named_path
            {
                state.record_read(path.clone());
            }
            if number == libc::SYS_lchown || flags & libc::AT_SYMLINK_NOFOLLOW != 0 {
                named_path
            } else {
                proc_helpers::resolve_tracee_path(pid, directory, &name)
                    .and_then(|path| proc_helpers::resolve_to_real_path(&path))
            }
        }
    };
    if let Some(path) = path
        && std::fs::symlink_metadata(&path).is_ok()
    {
        if state.dependencies {
            state.record_read(path.clone());
        }
        snapshot::maybe_snapshot_metadata(&mut state.snapshot, &path);
        state.write_paths.insert(path);
    }
}
