//! Pre-write capture and restoration of a command's filesystem changes.
use anyhow::Result;
use nix::unistd::Pid;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::fs;
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

mod restore;

pub use restore::revert;

use crate::proc_helpers;

/// Owns snapshot selection, deduplication and capture failures for one trace.
/// Payloads remain on disk until the caller restores or removes the snapshot.
#[derive(Default)]
pub struct Snapshot {
    directory: Option<PathBuf>,
    exclusions: HashSet<PathBuf>,
    filter_noisy: bool,
    entries: Vec<SnapshotEntry>,
    inode_entries: HashMap<(u64, u64), usize>,
    captured_paths: HashSet<PathBuf>,
    captured_metadata: HashSet<PathBuf>,
    failures: Vec<String>,
    aliases: HashMap<PathBuf, PathBuf>,
}

impl Snapshot {
    pub fn new(directory: Option<PathBuf>, filter_noisy: bool) -> Self {
        Self {
            directory,
            filter_noisy,
            ..Self::default()
        }
    }

    pub fn is_enabled(&self) -> bool {
        self.directory.is_some()
    }

    /// Exclude exact outputs that the caller will restore from another source.
    pub fn exclude(&mut self, paths: HashSet<PathBuf>) {
        self.exclusions = paths;
    }

    /// Prevent a partial snapshot from being reported as successfully restored.
    pub fn invalidate(&mut self, reason: &str) {
        if self.is_enabled() && !self.failures.iter().any(|failure| failure == reason) {
            self.failures.push(reason.to_owned());
        }
    }

    /// Resolve parent links at capture time, leaving the final entry unfollowed.
    /// Restoration must not depend on parent links the command may later replace.
    fn entry_path(&mut self, path: &Path) -> Option<PathBuf> {
        if !self.is_enabled() || excluded(self, path) {
            return None;
        }
        match entry_location(path) {
            Ok(resolved) if !excluded(self, &resolved) => {
                if path != resolved {
                    self.aliases.insert(path.to_owned(), resolved.clone());
                }
                Some(resolved)
            }
            Ok(_) => None,
            Err(error) => {
                self.invalidate(&format!("cannot resolve snapshot parent {path:?}: {error}"));
                None
            }
        }
    }

    /// Publish the manifest after tracing has stopped, including capture failures.
    pub fn write_manifest(&self) -> Result<()> {
        if let Some(directory) = &self.directory {
            let aliases = self
                .aliases
                .iter()
                .filter(|(_, target)| {
                    self.captured_paths.contains(*target)
                        || self.captured_metadata.contains(*target)
                })
                .map(|(path, target)| SnapshotAlias {
                    path: path.clone(),
                    target: target.clone(),
                })
                .collect();
            write_manifest(directory, &self.entries, &self.failures, aliases)?;
        }
        Ok(())
    }
}

/// What was captured in the snapshot for a given path.
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "lowercase")]
pub enum SnapshotKind {
    /// Existing regular file; content stored at the given relative path inside
    /// `<snapshot-dir>/files/`.
    File { snapshot: String },
    /// Path did not exist before the write (created by the command).
    /// Revert: delete the file/dir/link.
    Nonexistent,
    /// Directory that existed and was removed by the command.
    /// Metadata is captured separately and restored after the contents.
    Directory,
    /// Symlink that was deleted; stores the link target.
    /// Revert: recreate the symlink.
    Symlink {
        #[serde(with = "crate::unix_path")]
        target: PathBuf,
    },
    /// Metadata-only change (chmod/chown/utimensat). No content copy.
    /// Revert: restore mode, uid, gid, and mtime.
    Metadata {
        mode: u32,
        uid: u32,
        gid: u32,
        mtime_sec: i64,
        mtime_nsec: i64,
    },
    /// Could not capture the entry; revert reports failure.
    Unreadable,
}

/// One entry in the snapshot manifest.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SnapshotEntry {
    /// The real filesystem path that was (or would be) modified.
    #[serde(with = "crate::unix_path")]
    pub path: PathBuf,
    #[serde(flatten)]
    pub kind: SnapshotKind,
}

/// Returns true for transient/noisy paths that should not be snapshotted:
/// /tmp, /proc, /dev, and pseudo-file prefixes like pipe:, socket:, anon_inode:.
pub fn is_noisy_path(path: &Path) -> bool {
    !path.is_absolute()
        || ["/tmp", "/proc", "/dev"]
            .iter()
            .any(|root| path.starts_with(root))
}

/// Resolve the nearest existing parent for entries in a not-yet-created tree.
/// Keep unresolved suffixes intact: lexical removal of `..` changes link semantics.
fn entry_location(path: &Path) -> std::io::Result<PathBuf> {
    let Some(parent) = path.parent() else {
        return fs::canonicalize(path);
    };
    for ancestor in parent.ancestors() {
        match fs::canonicalize(ancestor) {
            Ok(resolved) => return Ok(resolved.join(path.strip_prefix(ancestor).unwrap())),
            Err(error)
                if matches!(
                    error.kind(),
                    std::io::ErrorKind::NotFound | std::io::ErrorKind::NotADirectory
                ) =>
            {
                continue;
            }
            Err(error) => return Err(error),
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::NotFound,
        "snapshot parent is unavailable",
    ))
}

fn excluded(capture: &Snapshot, path: &Path) -> bool {
    capture.exclusions.contains(path) || (capture.filter_noisy && is_noisy_path(path))
}

/// Copy a file via `/proc/<pid>/fd/<fd>` into the snapshot directory before
/// the first write. No-op if snapshotting is disabled, path already recorded,
/// path is noisy (filtered), or the inode was already snapshotted (hard-link dedup).
pub fn maybe_snapshot_fd(capture: &mut Snapshot, pid: Pid, descriptor: i32, path: &Path) {
    let Some(resolved_path) = capture.entry_path(path) else {
        return;
    };
    let path = resolved_path.as_path();
    let snapshot_dir = match &capture.directory {
        Some(directory) => directory.clone(),
        None => return,
    };
    if excluded(capture, path) {
        return;
    }
    if capture.captured_paths.contains(path) {
        return;
    }

    maybe_snapshot_metadata(capture, path);
    let proc_fd = PathBuf::from(format!("/proc/{pid}/fd/{descriptor}"));
    let file_id = proc_helpers::file_id_from_fd(pid, descriptor);
    do_snapshot_file(capture, &snapshot_dir, path, &proc_fd, file_id);
}

/// Copy a file via a host-accessible proc path (e.g. `/proc/<pid>/root/...`)
/// before the first write. Used for path-based syscalls (truncate, open w/ O_TRUNC).
pub fn maybe_snapshot_host_path(capture: &mut Snapshot, host_proc_path: &Path, real_path: &Path) {
    let Some(resolved_path) = capture.entry_path(real_path) else {
        return;
    };
    let real_path = resolved_path.as_path();
    let snapshot_dir = match &capture.directory {
        Some(directory) => directory.clone(),
        None => return,
    };
    if excluded(capture, real_path) {
        return;
    }
    if capture.captured_paths.contains(real_path) {
        return;
    }

    maybe_snapshot_metadata(capture, real_path);
    let file_id = proc_helpers::file_id(host_proc_path);
    do_snapshot_file(capture, &snapshot_dir, real_path, host_proc_path, file_id);
}

/// Store the first contents of a path, sharing payloads for hard links.
fn do_snapshot_file(
    capture: &mut Snapshot,
    snapshot_dir: &std::path::Path,
    real_path: &Path,
    source_path: &Path,
    file_id: Option<(u64, u64)>,
) {
    let existing = file_id.and_then(|identity| capture.inode_entries.get(&identity).copied());
    let kind = if let Some(index) = existing {
        capture.entries[index].kind.clone()
    } else {
        // Index-based names avoid NAME_MAX failures on long or escaped source paths.
        let snapshot = format!("files/{}", capture.entries.len());
        let kind = match copy_file(source_path, &snapshot_dir.join(&snapshot)) {
            Ok(()) => SnapshotKind::File { snapshot },
            Err(error) => {
                capture.invalidate(&format!("cannot snapshot {real_path:?}: {error:#}"));
                SnapshotKind::Unreadable
            }
        };
        if let Some(identity) = file_id {
            capture
                .inode_entries
                .insert(identity, capture.entries.len());
        }
        kind
    };
    record_snapshot(capture, real_path, kind);
}

fn record_snapshot(capture: &mut Snapshot, path: &Path, kind: SnapshotKind) {
    if capture.directory.is_some()
        && !excluded(capture, path)
        && capture.captured_paths.insert(path.to_owned())
    {
        capture.entries.push(SnapshotEntry {
            path: path.to_owned(),
            kind,
        });
    }
}

/// Record a path as nonexistent (it will be created by the command).
/// Revert: delete the created file/dir/link.
pub fn snapshot_nonexistent(capture: &mut Snapshot, path: &Path) {
    let Some(resolved_path) = capture.entry_path(path) else {
        return;
    };
    let path = resolved_path.as_path();
    if !capture.captured_paths.contains(path) && !excluded(capture, path) {
        capture.captured_metadata.insert(path.to_owned());
    }
    record_snapshot(capture, path, SnapshotKind::Nonexistent);
}

pub fn snapshot_existing_dir(capture: &mut Snapshot, path: &Path) {
    let Some(resolved_path) = capture.entry_path(path) else {
        return;
    };
    let path = resolved_path.as_path();
    maybe_snapshot_metadata(capture, path);
    record_snapshot(capture, path, SnapshotKind::Directory);
}

pub fn snapshot_existing_symlink(capture: &mut Snapshot, path: &Path, target: &Path) {
    let Some(resolved_path) = capture.entry_path(path) else {
        return;
    };
    let path = resolved_path.as_path();
    maybe_snapshot_metadata(capture, path);
    record_snapshot(
        capture,
        path,
        SnapshotKind::Symlink {
            target: target.to_owned(),
        },
    );
}

/// Capture a rename tree and the entries it can replace, without following links.
pub fn snapshot_rename_tree(capture: &mut Snapshot, source: &Path, destination: &Path) {
    if capture.directory.is_none() {
        return;
    }
    let mut pending = vec![(
        std::path::PathBuf::from(source),
        std::path::PathBuf::from(destination),
    )];
    while let Some((source, destination)) = pending.pop() {
        snapshot_path(capture, &source);
        snapshot_path(capture, &destination);
        if !fs::symlink_metadata(&source).is_ok_and(|metadata| metadata.is_dir()) {
            continue;
        }
        let entries = match fs::read_dir(&source) {
            Ok(entries) => entries,
            Err(error) => {
                capture.invalidate(&format!(
                    "cannot read renamed directory {source:?}: {error}"
                ));
                continue;
            }
        };
        for entry in entries {
            match entry {
                Ok(entry) => pending.push((entry.path(), destination.join(entry.file_name()))),
                Err(error) => capture.invalidate(&format!(
                    "cannot read renamed directory {source:?}: {error}"
                )),
            }
        }
    }
}

fn snapshot_path(capture: &mut Snapshot, path: &Path) {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.is_symlink() => match fs::read_link(path) {
            Ok(target) => snapshot_existing_symlink(capture, path, &target),
            Err(_) => record_snapshot(capture, path, SnapshotKind::Unreadable),
        },
        Ok(metadata) if metadata.is_dir() => snapshot_existing_dir(capture, path),
        Ok(metadata) if metadata.is_file() => maybe_snapshot_host_path(capture, path, path),
        Ok(_) => record_snapshot(capture, path, SnapshotKind::Unreadable),
        Err(error)
            if matches!(
                error.kind(),
                std::io::ErrorKind::NotFound | std::io::ErrorKind::NotADirectory
            ) =>
        {
            snapshot_nonexistent(capture, path)
        }
        Err(_) => record_snapshot(capture, path, SnapshotKind::Unreadable),
    }
}

/// Capture current metadata for a path before a chmod/chown/utimensat.
/// Revert: restore mode, uid, gid, and mtime.
pub fn maybe_snapshot_metadata(capture: &mut Snapshot, real_path: &Path) {
    let Some(resolved_path) = capture.entry_path(real_path) else {
        return;
    };
    let real_path = resolved_path.as_path();
    if capture.directory.is_none() {
        return;
    }
    if excluded(capture, real_path) {
        return;
    }
    // Use a separate dedup set so that a metadata-only snapshot doesn't block
    // a later content snapshot on the same path (e.g., chmod then write).
    if capture.captured_metadata.contains(real_path) {
        return;
    }
    let metadata = match std::fs::symlink_metadata(real_path) {
        Ok(metadata) => metadata,
        Err(_) => return,
    };
    capture.captured_metadata.insert(real_path.to_owned());
    capture.entries.push(SnapshotEntry {
        path: real_path.to_owned(),
        kind: SnapshotKind::Metadata {
            mode: metadata.mode(),
            uid: metadata.uid(),
            gid: metadata.gid(),
            mtime_sec: metadata.mtime(),
            mtime_nsec: metadata.mtime_nsec(),
        },
    });
}

fn copy_file(source: &Path, destination: &Path) -> Result<()> {
    if let Some(parent) = destination.parent() {
        fs::create_dir_all(parent)?;
    }
    loop {
        match fs::copy(source, destination) {
            Ok(_) => return Ok(()),
            // SIGTERM deliberately interrupts waitpid, but can also interrupt
            // a pre-syscall snapshot copy. The tracee is still stopped: retry
            // from the same source before cancellation kills and reaps it.
            Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(error) => return Err(error.into()),
        }
    }
}

/// Logical names whose resolved entries are covered by this snapshot.
#[derive(Serialize, Deserialize)]
struct SnapshotAlias {
    #[serde(with = "crate::unix_path")]
    path: PathBuf,
    #[serde(with = "crate::unix_path")]
    target: PathBuf,
}

#[derive(Serialize, Deserialize)]
struct Manifest<Entries> {
    entries: Entries,
    #[serde(default)]
    aliases: Vec<SnapshotAlias>,
    #[serde(default)]
    failures: Vec<String>,
}

/// Write the snapshot manifest to `<snapshot_dir>/manifest.json` atomically.
fn write_manifest(
    snapshot_dir: &Path,
    entries: &[SnapshotEntry],
    failures: &[String],
    aliases: Vec<SnapshotAlias>,
) -> Result<()> {
    fs::create_dir_all(snapshot_dir)?;
    let tmp_path = snapshot_dir.join("manifest.json.tmp");
    let final_path = snapshot_dir.join("manifest.json");

    let manifest = Manifest {
        entries,
        aliases,
        failures: failures.to_vec(),
    };
    let json = serde_json::to_string_pretty(&manifest)?;

    fs::write(&tmp_path, json)?;
    fs::rename(&tmp_path, &final_path)?;
    Ok(())
}
