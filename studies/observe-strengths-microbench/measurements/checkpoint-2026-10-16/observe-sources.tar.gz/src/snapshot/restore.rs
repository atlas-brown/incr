//! Restore a completed snapshot after all tracees have stopped.
use anyhow::Result;
use std::fs;
use std::os::unix::ffi::OsStrExt;
use std::path::{Component, Path};

use super::Manifest;
use super::{SnapshotEntry, SnapshotKind};
use crate::permissions::{TemporaryPermissions, remove_tree};

/// Apply the snapshot manifest to revert all changes made by the observed command.
/// Remove created entries deepest-first, restore parent directories, then contents
/// and metadata. This also handles a rename exchanging files with directories.
pub fn revert(snapshot_dir: &Path) -> Result<()> {
    let manifest_path = snapshot_dir.join("manifest.json");
    let data = fs::read_to_string(&manifest_path)?;
    let manifest: Manifest<Vec<SnapshotEntry>> = serde_json::from_str(&data)?;
    anyhow::ensure!(
        manifest.failures.is_empty(),
        "incomplete snapshot: {:?}",
        manifest.failures
    );
    validate_entries(snapshot_dir, &manifest.entries)?;

    apply_entries(snapshot_dir, &manifest.entries)
}

fn apply_entries(snapshot_dir: &Path, entries: &[SnapshotEntry]) -> Result<()> {
    let managed_paths: std::collections::HashSet<_> =
        entries.iter().map(|entry| entry.path.as_path()).collect();
    let mut entries: Vec<_> = entries.iter().collect();
    entries.sort_by_key(|entry| {
        let depth = Path::new(&entry.path).components().count() as isize;
        match entry.kind {
            SnapshotKind::Nonexistent => (0, -depth),
            SnapshotKind::Directory => (1, depth),
            SnapshotKind::File { .. } | SnapshotKind::Symlink { .. } => (2, depth),
            SnapshotKind::Metadata { .. } => (3, -depth),
            SnapshotKind::Unreadable => (4, depth),
        }
    });
    let mut failures = 0;
    for entry in entries {
        if let Err(error) = TemporaryPermissions::with_parents(&entry.path, &managed_paths, || {
            revert_entry(snapshot_dir, entry)
        }) {
            eprintln!("observe revert: {}: {error}", entry.path.display());
            failures += 1;
        }
    }
    anyhow::ensure!(
        failures == 0,
        "could not restore {failures} snapshot entries"
    );
    Ok(())
}

/// Reject incomplete or malformed snapshots before applying deletions or writes.
/// Snapshot contents must remain private until restoration finishes.
fn validate_entries(snapshot_directory: &Path, entries: &[SnapshotEntry]) -> Result<()> {
    let mut contents = std::collections::HashSet::new();
    let mut metadata = std::collections::HashSet::new();
    for entry in entries {
        anyhow::ensure!(
            Path::new(&entry.path).is_absolute() && !entry.path.as_os_str().as_bytes().contains(&0),
            "invalid snapshot target: {:?}",
            entry.path.display()
        );
        let seen = if matches!(entry.kind, SnapshotKind::Metadata { .. }) {
            &mut metadata
        } else {
            &mut contents
        };
        anyhow::ensure!(
            seen.insert(&entry.path),
            "duplicate snapshot entry: {}",
            entry.path.display()
        );
        match &entry.kind {
            SnapshotKind::File { snapshot } => {
                let components: Vec<_> = Path::new(snapshot).components().collect();
                anyhow::ensure!(
                    matches!(components.as_slice(), [Component::Normal(directory), Component::Normal(_)] if *directory == "files"),
                    "invalid snapshot payload: {snapshot}"
                );
                anyhow::ensure!(
                    fs::symlink_metadata(snapshot_directory.join("files"))?.is_dir(),
                    "snapshot payload directory is not a directory"
                );
                let payload = snapshot_directory.join(snapshot);
                anyhow::ensure!(
                    fs::symlink_metadata(&payload)?.is_file(),
                    "snapshot payload is not a regular file: {snapshot}"
                );
                fs::File::open(payload)?;
            }
            SnapshotKind::Symlink { target } => {
                anyhow::ensure!(
                    !target.as_os_str().as_bytes().contains(&0),
                    "snapshot link target contains a null byte"
                );
            }
            SnapshotKind::Metadata { mtime_nsec, .. } => {
                anyhow::ensure!(
                    (0..1_000_000_000).contains(mtime_nsec),
                    "invalid snapshot modification time"
                );
            }
            SnapshotKind::Unreadable => {
                anyhow::bail!(
                    "entry was unreadable at snapshot time: {}",
                    entry.path.display()
                )
            }
            SnapshotKind::Nonexistent | SnapshotKind::Directory => (),
        }
    }
    Ok(())
}

/// Revert a single manifest entry, restoring the filesystem to its pre-command
/// state for the given path. Returns an error if the revert cannot be completed.
fn revert_entry(snapshot_dir: &Path, entry: &SnapshotEntry) -> Result<()> {
    match &entry.kind {
        SnapshotKind::File { snapshot } => {
            let source = snapshot_dir.join(snapshot);
            let destination = entry.path.as_path();
            if let Some(parent) = destination.parent() {
                fs::create_dir_all(parent)?;
            }
            if destination.is_dir() && !destination.is_symlink() {
                remove_tree(destination)?;
            } else if destination.is_symlink() {
                fs::remove_file(destination)?;
            }
            TemporaryPermissions::with_file(destination, || {
                let mut source = fs::File::open(source)?;
                let mut destination = fs::File::create(destination)?;
                std::io::copy(&mut source, &mut destination)?;
                Ok(())
            })?;
        }
        SnapshotKind::Nonexistent => {
            let path = entry.path.as_path();
            match fs::symlink_metadata(path) {
                Ok(metadata) if metadata.is_dir() => fs::remove_dir(path)?,
                Ok(_) => fs::remove_file(path)?,
                Err(error)
                    if matches!(
                        error.kind(),
                        std::io::ErrorKind::NotFound | std::io::ErrorKind::NotADirectory
                    ) => {}
                Err(error) => return Err(error.into()),
            }
        }
        SnapshotKind::Directory => {
            if fs::symlink_metadata(&entry.path).is_ok_and(|metadata| !metadata.is_dir()) {
                fs::remove_file(&entry.path)?;
            }
            fs::create_dir_all(&entry.path)?;
        }
        SnapshotKind::Symlink { target } => {
            // The command deleted a symlink; recreate it.
            let path = entry.path.as_path();
            if path.is_dir() && !path.is_symlink() {
                remove_tree(path)?;
            } else if path.exists() || path.is_symlink() {
                fs::remove_file(path)?;
            }
            if let Some(parent) = path.parent() {
                fs::create_dir_all(parent)?;
            }
            std::os::unix::fs::symlink(target, path)?;
        }
        SnapshotKind::Metadata {
            mode,
            uid,
            gid,
            mtime_sec,
            mtime_nsec,
        } => {
            restore_metadata(&entry.path, *mode, *uid, *gid, *mtime_sec, *mtime_nsec)?;
        }
        SnapshotKind::Unreadable => anyhow::bail!("entry was unreadable at snapshot time"),
    }
    Ok(())
}

/// Restore ownership, permissions, and mtime for `path` to the values captured
/// in the snapshot. Uses `lchown` and `AT_SYMLINK_NOFOLLOW` so that symlinks
/// themselves (not their targets) are updated.
fn restore_metadata(
    path: &Path,
    mode: u32,
    uid: u32,
    gid: u32,
    mtime_sec: i64,
    mtime_nsec: i64,
) -> Result<()> {
    use std::ffi::CString;
    use std::os::unix::fs::MetadataExt;

    let metadata = fs::symlink_metadata(path)?;
    let c_path = CString::new(path.as_os_str().as_bytes())?;
    unsafe {
        // Restore ownership (lchown -- don't follow symlinks).
        if (metadata.uid() != uid || metadata.gid() != gid)
            && libc::lchown(c_path.as_ptr(), uid, gid) != 0
        {
            return Err(std::io::Error::last_os_error().into());
        }

        // Restore permissions (skip for symlinks; chmod on symlinks is a no-op on Linux).
        let metadata = std::fs::symlink_metadata(path)?;
        if !metadata.file_type().is_symlink()
            && metadata.mode() & 0o7777 != mode & 0o7777
            && libc::chmod(c_path.as_ptr(), mode as libc::mode_t) != 0
        {
            return Err(std::io::Error::last_os_error().into());
        }

        if metadata.mtime() == mtime_sec && metadata.mtime_nsec() == mtime_nsec {
            return Ok(());
        }
        // Restore mtime via utimensat with AT_SYMLINK_NOFOLLOW.
        let times = [
            libc::timespec {
                tv_sec: 0,
                tv_nsec: libc::UTIME_OMIT,
            },
            libc::timespec {
                tv_sec: mtime_sec,
                tv_nsec: mtime_nsec,
            },
        ];
        if libc::utimensat(
            libc::AT_FDCWD,
            c_path.as_ptr(),
            times.as_ptr(),
            libc::AT_SYMLINK_NOFOLLOW,
        ) != 0
        {
            return Err(std::io::Error::last_os_error().into());
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};

    static NEXT_DIRECTORY: AtomicU64 = AtomicU64::new(0);

    struct TestDirectory(PathBuf);

    impl TestDirectory {
        fn create() -> Result<Self> {
            let path = std::env::temp_dir().join(format!(
                "observe-restore-{}-{}",
                std::process::id(),
                NEXT_DIRECTORY.fetch_add(1, Ordering::Relaxed)
            ));
            fs::create_dir(&path)?;
            Ok(Self(path))
        }
    }

    impl Drop for TestDirectory {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    #[test]
    fn missing_payload_does_not_delete_other_entries() -> Result<()> {
        let directory = TestDirectory::create()?;
        let created = directory.0.join("created");
        fs::write(&created, b"preserve on failure")?;
        let entries = vec![
            SnapshotEntry {
                path: created.clone(),
                kind: SnapshotKind::Nonexistent,
            },
            SnapshotEntry {
                path: directory.0.join("original"),
                kind: SnapshotKind::File {
                    snapshot: "files/missing".to_owned(),
                },
            },
        ];
        super::super::write_manifest(&directory.0, &entries, &[], Vec::new())?;
        assert!(revert(&directory.0).is_err());
        assert_eq!(fs::read(created)?, b"preserve on failure");
        Ok(())
    }

    #[test]
    fn incomplete_capture_is_rejected_before_deletion() -> Result<()> {
        let directory = TestDirectory::create()?;
        let output = directory.0.join("output");
        fs::write(&output, b"preserved")?;
        let entries = vec![SnapshotEntry {
            path: output.clone(),
            kind: SnapshotKind::Nonexistent,
        }];
        super::super::write_manifest(
            &directory.0,
            &entries,
            &["unsupported effect".to_owned()],
            Vec::new(),
        )?;
        assert!(revert(&directory.0).is_err());
        assert_eq!(fs::read(output)?, b"preserved");
        Ok(())
    }

    #[test]
    fn payload_cannot_escape_snapshot_directory() -> Result<()> {
        let directory = TestDirectory::create()?;
        let output = directory.0.join("output");
        fs::write(&output, b"unchanged")?;
        fs::write(directory.0.join("outside"), b"wrong payload")?;
        fs::create_dir(directory.0.join("files"))?;
        let entries = vec![SnapshotEntry {
            path: output.clone(),
            kind: SnapshotKind::File {
                snapshot: "files/../outside".to_owned(),
            },
        }];
        super::super::write_manifest(&directory.0, &entries, &[], Vec::new())?;
        assert!(revert(&directory.0).is_err());
        assert_eq!(fs::read(output)?, b"unchanged");
        Ok(())
    }
}
