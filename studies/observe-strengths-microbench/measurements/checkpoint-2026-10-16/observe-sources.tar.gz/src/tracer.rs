use anyhow::{Context, Result};
use nix::libc;
use nix::sys::ptrace;
use nix::sys::signal::Signal;
use nix::sys::wait::{WaitPidFlag, WaitStatus, waitpid};
use nix::unistd::Pid;
use std::collections::{HashMap, HashSet};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};

use crate::snapshot::Snapshot;
use crate::state::{PreWrite, TracerState};
mod events;

/// Set to `true` by the SIGTERM handler; checked after each `waitpid` returns
/// `EINTR` so the tracer can flush snapshot state before exiting.
static SIGTERM_RECEIVED: AtomicBool = AtomicBool::new(false);

pub(crate) fn termination_requested() -> bool {
    SIGTERM_RECEIVED.load(Ordering::Relaxed)
}

/// Signal-safe SIGTERM handler. Only sets the atomic flag; all real work
/// happens in the `waitpid` loop after it detects the flag.
unsafe extern "C" fn handle_sigterm(_: libc::c_int) {
    SIGTERM_RECEIVED.store(true, Ordering::Relaxed);
}

/// Result of tracing a command.
pub struct TraceResult {
    pub guarded_descriptors: Vec<i32>,
    pub directory_access_only: bool,
    pub record_content_opens: bool,
    pub content_opens: HashSet<PathBuf>,
    pub read_paths: HashSet<PathBuf>,
    pub write_paths: HashSet<PathBuf>,
    /// Pre-write hashes for files in write_paths (populated when --hash is set).
    pub pre_hashes: HashMap<PathBuf, PreWrite>,
    /// Snapshot entries (populated when --snapshot-dir is set).
    pub snapshot: Snapshot,
    pub exit_code: i32,
    pub replay_barriers: HashSet<String>,
    pub pre_reads: HashMap<PathBuf, crate::dependency::Dependency>,
    pub overwrites: HashSet<PathBuf>,
}

/// Dependency-report options shared by the CLI and tracer.
pub struct DependencyOptions {
    pub guarded_descriptors: Vec<i32>,
    pub enabled: bool,
    pub directory_access_only: bool,
    pub record_content_opens: bool,
}

/// Main tracer: wait for the initial child, set ptrace options, then run the
/// event loop until all traced processes have exited.
pub fn run_tracer(
    initial_pid: Pid,
    hash_writes: bool,
    snapshot_dir: Option<PathBuf>,
    filter_noisy: bool,
    effect_gate: Option<&crate::effect_gate::EffectGate>,
    snapshot_exclusions: HashSet<PathBuf>,
    dependency_options: DependencyOptions,
) -> Result<TraceResult> {
    let DependencyOptions {
        guarded_descriptors,
        enabled: dependencies,
        directory_access_only,
        record_content_opens,
    } = dependency_options;
    let mut state = TracerState::new(initial_pid, hash_writes, snapshot_dir, filter_noisy);
    state.dependencies = dependencies;
    state.guarded_descriptors = guarded_descriptors.clone();
    state.directory_access_only = directory_access_only;
    state.record_content_opens = record_content_opens;
    state.snapshot.exclude(snapshot_exclusions);

    // Install a SIGTERM handler so the tracer can write the snapshot manifest
    // before exiting when killed. SIGKILL cannot be caught; SIGTERM can.
    // The handler only sets a flag; the waitpid loop checks it on EINTR.
    unsafe {
        let mut action: libc::sigaction = std::mem::zeroed();
        action.sa_sigaction = handle_sigterm as *const () as libc::sighandler_t;
        action.sa_flags = 0; // no SA_RESTART: we want waitpid to return EINTR
        if libc::sigaction(libc::SIGTERM, &action, std::ptr::null_mut()) == -1 {
            return Err(std::io::Error::last_os_error()).context("install termination handler");
        }
    }

    // Wait for the child's initial SIGSTOP (from raise(SIGSTOP) after traceme)
    wait_initial_stop(initial_pid)?;

    let options = ptrace::Options::PTRACE_O_TRACESYSGOOD
        | ptrace::Options::PTRACE_O_TRACEEXEC
        | ptrace::Options::PTRACE_O_TRACEFORK
        | ptrace::Options::PTRACE_O_TRACEVFORK
        | ptrace::Options::PTRACE_O_TRACECLONE
        | ptrace::Options::PTRACE_O_TRACESECCOMP
        | ptrace::Options::PTRACE_O_EXITKILL;

    ptrace::setoptions(initial_pid, options).context("setoptions on initial_pid")?;
    // Resume child -- it will exec and start generating seccomp stops
    ptrace::cont(initial_pid, None).context("initial cont")?;

    let mut exit_code: i32 = 0;

    loop {
        if SIGTERM_RECEIVED.load(Ordering::Relaxed) {
            // Kill and reap tracees before returning the partial manifest. Merely
            // leaving the loop relies on EXITKILL and strands zombie descendants.
            for pid in &state.live {
                let _ = nix::sys::signal::kill(*pid, Signal::SIGKILL);
            }
        }
        // __WALL: get events from all traced threads (cloned or forked).
        // SIGTERM interrupts waitpid; the next iteration kills and reaps tracees.
        let status = match waitpid(None, Some(WaitPidFlag::__WALL)) {
            Ok(status) => status,
            Err(nix::errno::Errno::EINTR) => {
                continue;
            }
            Err(nix::errno::Errno::ECHILD) if termination_requested() => break,
            Err(error) => return Err(error).context("waitpid"),
        };

        // A queued stop can outlive a tracee killed above. Do not inspect its
        // registers or descriptors after cancellation: that would manufacture
        // unreadable observations/snapshots from a deliberately dead process.
        // Mutating syscalls were snapshotted before resumption; an open's exit
        // stop cannot precede another write while the tracee remains stopped.
        if termination_requested() {
            let stopped = match status {
                WaitStatus::PtraceEvent(pid, _, event) => {
                    if matches!(
                        event,
                        libc::PTRACE_EVENT_FORK
                            | libc::PTRACE_EVENT_VFORK
                            | libc::PTRACE_EVENT_CLONE
                    ) && let Ok(child) = ptrace::getevent(pid)
                    {
                        let child = Pid::from_raw(child as i32);
                        state.live.insert(child);
                        let _ = nix::sys::signal::kill(child, Signal::SIGKILL);
                    }
                    Some(pid)
                }
                WaitStatus::PtraceSyscall(pid) | WaitStatus::Stopped(pid, _) => Some(pid),
                _ => None,
            };
            if let Some(pid) = stopped {
                state.live.insert(pid);
                let _ = nix::sys::signal::kill(pid, Signal::SIGKILL);
                let _ = ptrace::cont(pid, None);
                continue;
            }
        }

        match status {
            WaitStatus::PtraceEvent(pid, _, event) => {
                events::ptrace_event(&mut state, pid, event, options, effect_gate);
            }
            WaitStatus::PtraceSyscall(pid) => events::syscall_exit(&mut state, pid),
            WaitStatus::Stopped(pid, signal) => {
                events::signal_stop(&mut state, pid, signal, options)
            }

            WaitStatus::Exited(pid, code) => {
                if pid == initial_pid {
                    exit_code = code;
                }
                state.remove_pid(pid);
                if state.live.is_empty() && !termination_requested() {
                    break;
                }
            }
            WaitStatus::Signaled(pid, sig, _) => {
                if pid == initial_pid {
                    // Killed by signal -- encode as 128 + signal number
                    exit_code = 128 + sig as i32;
                }
                state.remove_pid(pid);
                if state.live.is_empty() && !termination_requested() {
                    break;
                }
            }

            _ => {}
        }
    }

    Ok(TraceResult {
        guarded_descriptors,
        directory_access_only,
        record_content_opens,
        content_opens: std::mem::take(&mut state.content_opens),
        read_paths: std::mem::take(&mut state.read_paths),
        write_paths: std::mem::take(&mut state.write_paths),
        pre_hashes: std::mem::take(&mut state.pre_hashes),
        snapshot: std::mem::take(&mut state.snapshot),
        exit_code,
        pre_reads: std::mem::take(&mut state.pre_reads),
        overwrites: std::mem::take(&mut state.overwrites),
        replay_barriers: std::mem::take(&mut state.replay_barriers),
    })
}

/// Wait for the initial ptrace stop from the child.
fn wait_initial_stop(pid: Pid) -> Result<()> {
    loop {
        if termination_requested() {
            let _ = nix::sys::signal::kill(pid, Signal::SIGKILL);
        }
        let status = match waitpid(pid, Some(WaitPidFlag::__WALL)) {
            Ok(status) => status,
            Err(nix::errno::Errno::EINTR) => continue,
            Err(error) => return Err(error.into()),
        };
        match status {
            WaitStatus::Stopped(_, _)
            | WaitStatus::PtraceEvent(_, _, _)
            | WaitStatus::PtraceSyscall(_) => return Ok(()),
            WaitStatus::Exited(_, code) => {
                anyhow::bail!("child exited with code {} before initial stop", code);
            }
            WaitStatus::Signaled(_, sig, _) => {
                anyhow::bail!("child killed by {} before initial stop", sig);
            }
            _ => continue,
        }
    }
}
