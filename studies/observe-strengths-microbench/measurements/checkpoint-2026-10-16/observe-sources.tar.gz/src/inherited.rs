//! Conservative observation of inherited descriptors outside the stdin key.
use crate::syscall::SyscallEntry;

pub(crate) fn parse(value: &str) -> anyhow::Result<Vec<i32>> {
    let mut descriptors = value
        .split(',')
        .map(str::parse::<i32>)
        .collect::<Result<Vec<_>, _>>()?;
    descriptors.sort_unstable();
    descriptors.dedup();
    anyhow::ensure!(
        !descriptors.is_empty() && descriptors.len() <= 16,
        "guard 1..16 descriptors"
    );
    for &fd in &descriptors {
        let flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
        let descriptor_flags = unsafe { libc::fcntl(fd, libc::F_GETFD) };
        anyhow::ensure!(
            fd > 2
                && flags >= 0
                && descriptor_flags >= 0
                && descriptor_flags & libc::FD_CLOEXEC == 0
                && flags & libc::O_ACCMODE == libc::O_RDONLY
                && flags & libc::O_PATH == 0
                && std::fs::metadata(format!("/proc/self/fd/{fd}"))?.is_file(),
            "guarded descriptor must be an inherited read-only regular file: {fd}"
        );
    }
    Ok(descriptors)
}

// Descriptor arguments are checked in seccomp, so ordinary stdin/stdout and
// newly opened files retain the normal no-stop data path. Duplication is itself
// a barrier: we never need to follow an inherited descriptor into an alias.
pub(crate) const FD_ARGUMENTS: &[(i64, &[usize])] = &[
    (libc::SYS_read, &[0]),
    (libc::SYS_write, &[0]),
    (libc::SYS_readv, &[0]),
    (libc::SYS_writev, &[0]),
    (libc::SYS_pread64, &[0]),
    (libc::SYS_pwrite64, &[0]),
    (libc::SYS_preadv, &[0]),
    (libc::SYS_pwritev, &[0]),
    (libc::SYS_preadv2, &[0]),
    (libc::SYS_pwritev2, &[0]),
    (libc::SYS_lseek, &[0]),
    (libc::SYS_fstat, &[0]),
    (libc::SYS_fstatfs, &[0]),
    (libc::SYS_fchdir, &[0]),
    (libc::SYS_ftruncate, &[0]),
    (libc::SYS_fchmod, &[0]),
    (libc::SYS_fchown, &[0]),
    (libc::SYS_fsync, &[0]),
    (libc::SYS_fdatasync, &[0]),
    (libc::SYS_syncfs, &[0]),
    (libc::SYS_sync_file_range, &[0]),
    (libc::SYS_fgetxattr, &[0]),
    (libc::SYS_flistxattr, &[0]),
    (libc::SYS_fsetxattr, &[0]),
    (libc::SYS_fremovexattr, &[0]),
    (libc::SYS_fcntl, &[0]),
    (libc::SYS_ioctl, &[0]),
    (libc::SYS_flock, &[0]),
    (libc::SYS_dup, &[0]),
    (libc::SYS_dup2, &[0, 1]),
    (libc::SYS_dup3, &[0, 1]),
    (libc::SYS_getdents, &[0]),
    (libc::SYS_getdents64, &[0]),
    (libc::SYS_fadvise64, &[0]),
    (libc::SYS_readahead, &[0]),
    (libc::SYS_fallocate, &[0]),
    (libc::SYS_sendfile, &[0, 1]),
    (libc::SYS_copy_file_range, &[0, 2]),
    (libc::SYS_splice, &[0, 2]),
    (libc::SYS_tee, &[0, 1]),
    (libc::SYS_vmsplice, &[0]),
    (libc::SYS_mmap, &[4]),
    (libc::SYS_sendto, &[0]),
    (libc::SYS_recvfrom, &[0]),
    (libc::SYS_sendmsg, &[0]),
    (libc::SYS_recvmsg, &[0]),
    (libc::SYS_sendmmsg, &[0]),
    (libc::SYS_recvmmsg, &[0]),
    (libc::SYS_shutdown, &[0]),
    (libc::SYS_getsockopt, &[0]),
    (libc::SYS_setsockopt, &[0]),
    (libc::SYS_getsockname, &[0]),
    (libc::SYS_getpeername, &[0]),
    (libc::SYS_accept, &[0]),
    (libc::SYS_accept4, &[0]),
    (libc::SYS_connect, &[0]),
    (libc::SYS_bind, &[0]),
    (libc::SYS_listen, &[0]),
    (libc::SYS_pidfd_getfd, &[0, 1]),
    (libc::SYS_execveat, &[0]),
    (libc::SYS_quotactl_fd, &[0]),
    // AT_EMPTY_PATH can operate directly on regular descriptors, too.
    (libc::SYS_openat, &[0]),
    (libc::SYS_openat2, &[0]),
    (libc::SYS_newfstatat, &[0]),
    (libc::SYS_statx, &[0]),
    (libc::SYS_faccessat, &[0]),
    (libc::SYS_faccessat2, &[0]),
    (libc::SYS_readlinkat, &[0]),
    (libc::SYS_renameat, &[0, 2]),
    (libc::SYS_renameat2, &[0, 2]),
    (libc::SYS_linkat, &[0, 2]),
    (libc::SYS_unlinkat, &[0]),
    (libc::SYS_mkdirat, &[0]),
    (libc::SYS_mknodat, &[0]),
    (libc::SYS_symlinkat, &[1]),
    (libc::SYS_fchmodat, &[0]),
    (libc::SYS_fchmodat2, &[0]),
    (libc::SYS_fchownat, &[0]),
    (libc::SYS_utimensat, &[0]),
    (libc::SYS_futimesat, &[0]),
    (libc::SYS_name_to_handle_at, &[0]),
    (libc::SYS_open_by_handle_at, &[0]),
];

// These interfaces hide descriptor sets behind pointers or registered state.
// Keep them live rather than trying to infer their descriptor usage.
pub(crate) const INDIRECT: &[i64] = &[
    libc::SYS_poll,
    libc::SYS_ppoll,
    libc::SYS_select,
    libc::SYS_pselect6,
    libc::SYS_epoll_ctl,
    libc::SYS_epoll_wait,
    libc::SYS_epoll_pwait,
    libc::SYS_epoll_pwait2,
];

pub(crate) fn touches(entry: &SyscallEntry, descriptors: &[i32]) -> bool {
    !descriptors.is_empty()
        && (INDIRECT.contains(&entry.number)
            || FD_ARGUMENTS.iter().any(|(number, arguments)| {
                *number == entry.number
                    && arguments
                        .iter()
                        .any(|arg| descriptors.contains(&(entry.arguments[*arg] as i32)))
            }))
}
