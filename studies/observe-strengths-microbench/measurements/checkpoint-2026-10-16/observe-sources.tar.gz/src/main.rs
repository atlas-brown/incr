#![deny(rust_2018_idioms)]

mod child;
mod dependency;
mod effect_gate;
mod inherited;
mod permissions;
mod proc_helpers;
mod report;
mod seccomp;
mod snapshot;
mod state;
mod syscall;
mod tracer;
mod unix_path;

use anyhow::{Context, Result};
use std::ffi::{CString, OsString};
use std::os::unix::ffi::OsStrExt;
use std::path::PathBuf;

fn main() -> Result<()> {
    let arguments: Vec<OsString> = std::env::args_os().collect();

    if arguments.get(1).and_then(|argument| argument.to_str()) == Some("revert") {
        let directory = arguments
            .get(2)
            .ok_or_else(|| anyhow::anyhow!("Usage: observe revert <snapshot-dir>"))?;
        snapshot::revert(std::path::Path::new(directory))?;
        return Ok(());
    }

    // Usage: observe [flags] -- <command> [arguments...]
    //        observe [flags] <command> [arguments...]   (no -- separator)
    let separator = arguments.iter().position(|argument| argument == "--");
    let (flags, command_arguments) = match separator {
        Some(position) => (&arguments[1..position], &arguments[position + 1..]),
        None => (&arguments[1..1], &arguments[1..]),
    };

    if command_arguments.is_empty() {
        eprintln!(
            "Usage: observe [--json] [--no-filter] [--hash] [--dependencies] [--directory-access-only] [--content-opens] [--guard-fds <list>] [--effect-gate <file>] [--output <file>] [--snapshot-dir <dir>] -- <command> [arguments...]"
        );
        eprintln!("       observe revert <snapshot-dir>");
        std::process::exit(1);
    }

    let mut index = 0;
    while index < flags.len() {
        match flags[index].to_str().context("option is not UTF-8")? {
            "--json"
            | "--dependencies"
            | "--no-filter"
            | "--hash"
            | "--directory-access-only"
            | "--content-opens" => (),
            "--output" | "--snapshot-dir" | "--snapshot-exclude" | "--effect-gate"
            | "--guard-fds" => {
                index += 1;
                if index == flags.len() || flags[index].as_bytes().starts_with(b"--") {
                    anyhow::bail!("missing value for {}", flags[index - 1].to_string_lossy());
                }
            }
            unknown => anyhow::bail!("unknown Observe option: {unknown}"),
        }
        index += 1;
    }

    let json_output = flags.iter().any(|flag| flag == "--json");
    let dependencies = flags.iter().any(|flag| flag == "--dependencies");
    let directory_access_only = flags.iter().any(|flag| flag == "--directory-access-only");
    let record_content_opens = flags.iter().any(|flag| flag == "--content-opens");
    anyhow::ensure!(
        !record_content_opens || dependencies,
        "--content-opens requires --dependencies"
    );
    let guarded_descriptors = parse_flag_value(flags, "--guard-fds")
        .map(|value| inherited::parse(&value.to_string_lossy()))
        .transpose()?
        .unwrap_or_default();
    anyhow::ensure!(
        guarded_descriptors.is_empty() || dependencies,
        "--guard-fds requires --dependencies"
    );
    let no_filter = flags.iter().any(|flag| flag == "--no-filter");
    let hash_writes = flags.iter().any(|flag| flag == "--hash");

    let output_path = parse_flag_value(flags, "--output");
    let snapshot_dir = parse_flag_value(flags, "--snapshot-dir");
    let snapshot_exclusions = parse_flag_value(flags, "--snapshot-exclude")
        .map(|path| -> Result<std::collections::HashSet<PathBuf>> {
            let paths: Vec<unix_path::Owned> = serde_json::from_slice(&std::fs::read(path)?)?;
            Ok(paths.into_iter().map(|path| path.0).collect())
        })
        .transpose()?
        .unwrap_or_default();

    let effect_gate = parse_flag_value(flags, "--effect-gate")
        .map(|path| effect_gate::EffectGate::open(&path))
        .transpose()?;

    let command: Vec<CString> = command_arguments
        .iter()
        .map(|argument| CString::new(argument.as_bytes()).context("argument contains null byte"))
        .collect::<Result<Vec<_>>>()?;

    match unsafe { nix::unistd::fork().context("fork failed")? } {
        nix::unistd::ForkResult::Child => {
            child::run_child(&command, &guarded_descriptors);
        }
        nix::unistd::ForkResult::Parent { child } => {
            let result = tracer::run_tracer(
                child,
                hash_writes,
                snapshot_dir.clone(),
                !no_filter,
                effect_gate.as_ref(),
                snapshot_exclusions,
                tracer::DependencyOptions {
                    enabled: dependencies,
                    directory_access_only,
                    record_content_opens,
                    guarded_descriptors,
                },
            )?;

            let result = if no_filter {
                result
            } else {
                report::filter_paths(result)
            };

            // Snapshot filtering happens before capture, not during reporting.
            result.snapshot.write_manifest()?;

            report::write(&result, output_path.as_deref(), json_output)?;

            std::process::exit(result.exit_code);
        }
    }
}

/// Find the first occurrence of `--<flag_name> <value>` in `flags` and return
/// the value as a `PathBuf`. Returns `None` if the flag is not present.
fn parse_flag_value(flags: &[OsString], flag_name: &str) -> Option<PathBuf> {
    flags
        .windows(2)
        .find(|pair| pair[0] == flag_name)
        .map(|pair| PathBuf::from(&pair[1]))
}
