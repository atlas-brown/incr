//! Lossless JSON paths: UTF-8 strings normally, or an explicit byte object.
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use std::ffi::OsString;
use std::os::unix::ffi::{OsStrExt, OsStringExt};
use std::path::{Path, PathBuf};

#[derive(Serialize)]
struct Bytes<'path> {
    bytes: &'path [u8],
}

/// Owned counterpart used when decoding a list of paths.
#[derive(Deserialize)]
pub struct Owned(#[serde(with = "crate::unix_path")] pub PathBuf);

/// Borrow a path for report serialization without allocating a second path.
pub struct Borrowed<'path>(pub &'path Path);

impl Serialize for Borrowed<'_> {
    fn serialize<Output: Serializer>(
        &self,
        serializer: Output,
    ) -> Result<Output::Ok, Output::Error> {
        serialize(self.0, serializer)
    }
}

/// Preserve ordinary JSON strings while keeping arbitrary Unix bytes distinct.
pub fn serialize<Output: Serializer>(
    path: &Path,
    serializer: Output,
) -> Result<Output::Ok, Output::Error> {
    match path.to_str() {
        Some(text) => serializer.serialize_str(text),
        None => Bytes {
            bytes: path.as_os_str().as_bytes(),
        }
        .serialize(serializer),
    }
}

pub fn deserialize<'input, Input: Deserializer<'input>>(
    deserializer: Input,
) -> Result<PathBuf, Input::Error> {
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum Representation {
        Text(String),
        Bytes { bytes: Vec<u8> },
    }
    let path = match Representation::deserialize(deserializer)? {
        Representation::Text(text) => PathBuf::from(text),
        Representation::Bytes { bytes } => PathBuf::from(OsString::from_vec(bytes)),
    };
    if path.as_os_str().as_bytes().contains(&0) {
        return Err(serde::de::Error::custom("path contains a null byte"));
    }
    Ok(path)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Serialize, Deserialize)]
    struct Entry {
        #[serde(with = "super")]
        path: PathBuf,
    }

    #[test]
    fn byte_paths_do_not_collide_with_unicode_or_escape_sequences() {
        for bytes in [
            b"/file-\xff".as_slice(),
            "/file-�".as_bytes(),
            b"/file-\\xff",
            b"/line\nbreak",
        ] {
            let path = PathBuf::from(OsString::from_vec(bytes.to_vec()));
            let encoded = serde_json::to_vec(&Entry { path: path.clone() }).unwrap();
            let decoded: Entry = serde_json::from_slice(&encoded).unwrap();
            assert_eq!(decoded.path, path);
        }
    }

    #[test]
    fn null_bytes_are_rejected() {
        assert!(serde_json::from_str::<Entry>(r#"{"path":{"bytes":[47,0]}}"#).is_err());
    }
}
