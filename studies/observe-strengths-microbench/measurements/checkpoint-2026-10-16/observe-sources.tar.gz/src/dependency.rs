//! Filesystem state at the first dependency access, not after command execution.
use serde::Serialize;
use std::fs;
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

#[derive(Clone, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Dependency {
    Absent,
    /// A path component is a regular file, so lookup fails with ENOTDIR.
    NotDirectory,
    ParentDirectory {
        mode: u32,
        uid: u32,
        gid: u32,
        access: u8,
    },
    File {
        device: u64,
        inode: u64,
        modified: u128,
        changed_sec: i64,
        changed_nsec: i64,
        size: u64,
        mode: u32,
    },
    Directory {
        modified: u128,
        changed_sec: i64,
        changed_nsec: i64,
        mode: u32,
    },
    Symlink {
        #[serde(with = "crate::unix_path")]
        target: PathBuf,
        modified: u128,
        changed_sec: i64,
        changed_nsec: i64,
        mode: u32,
    },
    Uncacheable,
}

impl Dependency {
    /// Parent traversal depends on permissions, not directory entry timestamps.
    pub fn capture_parent(path: &Path) -> Self {
        if let Ok(metadata) = fs::symlink_metadata(path)
            && metadata.is_dir()
        {
            return match crate::permissions::effective_access(path) {
                Ok(access) => Self::ParentDirectory {
                    mode: metadata.mode(),
                    uid: metadata.uid(),
                    gid: metadata.gid(),
                    access,
                },
                Err(_) => Self::Uncacheable,
            };
        }
        Self::capture(path)
    }

    pub fn capture(path: &Path) -> Self {
        let metadata = match fs::symlink_metadata(path) {
            Ok(metadata) => metadata,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Self::Absent,
            Err(error) if error.kind() == std::io::ErrorKind::NotADirectory => {
                return Self::NotDirectory;
            }
            Err(_) => return Self::Uncacheable,
        };
        let Some(modified) = metadata
            .modified()
            .ok()
            .and_then(|modified_time| modified_time.duration_since(UNIX_EPOCH).ok())
            .map(|duration| duration.as_nanos())
        else {
            return Self::Uncacheable;
        };
        if metadata.file_type().is_symlink() {
            return match fs::read_link(path) {
                Ok(target) => Self::Symlink {
                    target,
                    modified,
                    changed_sec: metadata.ctime(),
                    changed_nsec: metadata.ctime_nsec(),
                    mode: metadata.mode(),
                },
                Err(_) => Self::Uncacheable,
            };
        }
        if metadata.is_file() {
            Self::File {
                device: metadata.dev(),
                inode: metadata.ino(),
                modified,
                changed_sec: metadata.ctime(),
                changed_nsec: metadata.ctime_nsec(),
                size: metadata.len(),
                mode: metadata.mode(),
            }
        } else if metadata.is_dir() {
            Self::Directory {
                modified,
                changed_sec: metadata.ctime(),
                changed_nsec: metadata.ctime_nsec(),
                mode: metadata.mode(),
            }
        } else {
            Self::Uncacheable
        }
    }
}
