//! State transitions for ptrace stops. The parent owns waiting and termination.
use nix::libc;
use nix::sys::ptrace;
use nix::sys::signal::{Signal, kill};
use nix::unistd::Pid;

use crate::effect_gate::EffectGate;
use crate::state::TracerState;
use crate::syscall::{SyscallEntry, handle_entry, handle_exit, has_live_effect};

pub(super) fn ptrace_event(
    state: &mut TracerState,
    pid: Pid,
    event: i32,
    options: ptrace::Options,
    gate: Option<&EffectGate>,
) {
    match event {
        libc::PTRACE_EVENT_FORK | libc::PTRACE_EVENT_VFORK | libc::PTRACE_EVENT_CLONE => {
            if let Ok(child) = ptrace::getevent(pid) {
                let child = Pid::from_raw(child as i32);
                state.live.insert(child);
                let _ = ptrace::setoptions(child, options);
                let _ = ptrace::cont(child, None);
            }
            let _ = ptrace::cont(pid, None);
        }
        libc::PTRACE_EVENT_EXEC => exec(state, pid),
        libc::PTRACE_EVENT_SECCOMP => syscall_entry(state, pid, gate),
        _ => {
            let _ = ptrace::cont(pid, None);
        }
    }
}

fn exec(state: &mut TracerState, pid: Pid) {
    // A non-leader exec adopts the leader PID; its old TID has no exit event.
    if let Ok(previous) = ptrace::getevent(pid) {
        let previous = Pid::from_raw(previous as i32);
        if previous != pid {
            state.remove_pid(previous);
        }
    }
    state.live.insert(pid);
    state.awaiting_exit.remove(&pid);
    state.last_enter.remove(&pid);
    if let Ok(path) = std::fs::read_link(format!("/proc/{pid}/exe")) {
        state.record_read(path);
    }
    let _ = ptrace::cont(pid, None);
}

/// Classify effects while the tracee is stopped, before permitting the syscall.
fn syscall_entry(state: &mut TracerState, pid: Pid, gate: Option<&EffectGate>) {
    let Ok(registers) = ptrace::getregs(pid) else {
        state.record_unsupported_effect("unreadable syscall entry");
        if authorize_effect(state, gate) {
            let _ = ptrace::cont(pid, None);
        }
        return;
    };
    let entry = SyscallEntry::from_registers(pid, &registers);
    let foreign_abi = ptrace::getevent(pid) != Ok(0);
    let inherited_access = crate::inherited::touches(&entry, &state.guarded_descriptors);
    if gate.is_some_and(|gate| !gate.has_live_effects())
        && (foreign_abi || inherited_access || has_live_effect(pid, &entry))
        && !authorize_effect(state, gate)
    {
        return;
    }
    if inherited_access {
        state.record_unsupported_effect("inherited descriptor access requires live execution");
    }
    if foreign_abi {
        state.record_unsupported_effect("unsupported syscall ABI");
        let _ = ptrace::cont(pid, None);
        return;
    }
    if handle_entry(state, pid, &entry) {
        state.last_enter.insert(pid, entry);
        state.awaiting_exit.insert(pid);
        let _ = ptrace::syscall(pid, None);
    } else {
        let _ = ptrace::cont(pid, None);
    }
}

fn authorize_effect(state: &TracerState, gate: Option<&EffectGate>) -> bool {
    if let Some(gate) = gate
        && !gate.has_live_effects()
        && !gate.begin_effect()
    {
        for child in &state.live {
            let _ = kill(*child, Signal::SIGKILL);
        }
        return false;
    }
    true
}

pub(super) fn syscall_exit(state: &mut TracerState, pid: Pid) {
    if state.awaiting_exit.remove(&pid) {
        match (ptrace::getregs(pid), state.last_enter.remove(&pid)) {
            (Ok(registers), Some(entry)) => handle_exit(state, pid, &entry, registers.rax as i64),
            _ => state.record_unsupported_effect("unreadable syscall exit"),
        }
    }
    let _ = ptrace::cont(pid, None);
}

/// Preserve requested syscall-exit stops when forwarding an intervening signal.
pub(super) fn signal_stop(
    state: &mut TracerState,
    pid: Pid,
    signal: Signal,
    options: ptrace::Options,
) {
    let delivered = if signal == Signal::SIGSTOP {
        // A new child's stop can arrive before its parent's fork event.
        if state.live.insert(pid) {
            let _ = ptrace::setoptions(pid, options);
        }
        None
    } else {
        Some(signal)
    };
    if state.awaiting_exit.contains(&pid) {
        let _ = ptrace::syscall(pid, delivered);
    } else {
        let _ = ptrace::cont(pid, delivered);
    }
}
