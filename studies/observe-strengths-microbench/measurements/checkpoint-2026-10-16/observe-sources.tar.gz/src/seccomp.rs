use anyhow::{Result, bail};

/// Install a seccomp-BPF filter that causes PTRACE_EVENT_SECCOMP stops for
/// file-related syscalls only. All other syscalls are allowed to proceed
/// without any ptrace stop.
///
/// Must be called after ptrace::traceme() and before exec.
pub fn install_filter(guarded_descriptors: &[i32]) -> Result<()> {
    // PR_SET_NO_NEW_PRIVS is required before installing a seccomp filter
    // without CAP_SYS_ADMIN.
    let status = unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) };
    if status != 0 {
        bail!(
            "prctl(PR_SET_NO_NEW_PRIVS) failed: {}",
            std::io::Error::last_os_error()
        );
    }

    let filter = build_filter(guarded_descriptors);
    let program = libc::sock_fprog {
        len: filter.len() as u16,
        filter: filter.as_ptr() as *mut libc::sock_filter,
    };

    let status = unsafe {
        libc::syscall(
            libc::SYS_seccomp,
            SECCOMP_SET_MODE_FILTER,
            0u64, // flags
            &program as *const libc::sock_fprog,
        )
    };
    if status != 0 {
        bail!(
            "seccomp(SET_MODE_FILTER) failed: {}",
            std::io::Error::last_os_error()
        );
    }

    Ok(())
}

// seccomp constants not always in libc crate
const SECCOMP_SET_MODE_FILTER: u64 = 1;
const SECCOMP_RET_TRACE: u32 = 0x7ff0_0000;
const SECCOMP_RET_ALLOW: u32 = 0x7fff_0000;

// BPF instruction helpers
const BPF_LD: u16 = 0x00;
const BPF_W: u16 = 0x00;
const BPF_ABS: u16 = 0x20;
const BPF_JMP: u16 = 0x05;
const BPF_JEQ: u16 = 0x10;
const BPF_K: u16 = 0x00;
const BPF_RET: u16 = 0x06;

/// Construct a BPF statement instruction (no jump offsets).
fn statement(code: u16, value: u32) -> libc::sock_filter {
    libc::sock_filter {
        code,
        jt: 0,
        jf: 0,
        k: value,
    }
}

/// Construct a conditional jump with offsets for matching and other values.
fn jump(code: u16, value: u32, on_match: u8, on_mismatch: u8) -> libc::sock_filter {
    libc::sock_filter {
        code,
        jt: on_match,
        jf: on_mismatch,
        k: value,
    }
}

// Reads, writes and mappings use descriptors already tracked at open. Keeping
// high-volume pipe I/O out of ptrace is essential to pipeline performance.
const TRACED_SYSCALLS: &[u32] = &[
    // File open/create — entry needed (O_TRUNC pre-snapshot, O_CREAT Nonexistent),
    // exit needed for read/write classification.
    libc::SYS_open as u32,
    libc::SYS_openat as u32,
    libc::SYS_openat2 as u32,
    libc::SYS_creat as u32,
    // Path-based truncation — must snapshot BEFORE the kernel zeroes the file.
    libc::SYS_truncate as u32,
    // Path-based metadata reads — stat/access/readlink without an open().
    libc::SYS_stat as u32,
    libc::SYS_lstat as u32,
    libc::SYS_mknod as u32,
    libc::SYS_mknodat as u32,
    libc::SYS_newfstatat as u32,
    libc::SYS_statx as u32,
    libc::SYS_access as u32,
    libc::SYS_faccessat as u32,
    libc::SYS_faccessat2 as u32,
    libc::SYS_readlink as u32,
    libc::SYS_readlinkat as u32,
    // Directory / link / unlink — must snapshot targets before rename/unlink.
    libc::SYS_rename as u32,
    libc::SYS_renameat as u32,
    libc::SYS_renameat2 as u32,
    libc::SYS_link as u32,
    libc::SYS_linkat as u32,
    libc::SYS_symlink as u32,
    libc::SYS_symlinkat as u32,
    libc::SYS_unlink as u32,
    libc::SYS_unlinkat as u32,
    libc::SYS_rmdir as u32,
    libc::SYS_mkdir as u32,
    libc::SYS_mkdirat as u32,
    // Permissions / ownership / timestamps
    libc::SYS_chmod as u32,
    libc::SYS_fchmod as u32,
    libc::SYS_fchmodat as u32,
    libc::SYS_chown as u32,
    libc::SYS_fchown as u32,
    libc::SYS_lchown as u32,
    libc::SYS_fchownat as u32,
    libc::SYS_utimensat as u32,
    libc::SYS_fchmodat2 as u32,
    libc::SYS_utime as u32,
    libc::SYS_utimes as u32,
    libc::SYS_futimesat as u32,
    libc::SYS_getxattr as u32,
    libc::SYS_lgetxattr as u32,
    libc::SYS_fgetxattr as u32,
    libc::SYS_listxattr as u32,
    libc::SYS_llistxattr as u32,
    libc::SYS_flistxattr as u32,
    libc::SYS_setxattr as u32,
    libc::SYS_lsetxattr as u32,
    libc::SYS_fsetxattr as u32,
    libc::SYS_removexattr as u32,
    libc::SYS_lremovexattr as u32,
    libc::SYS_fremovexattr as u32,
    libc::SYS_io_uring_setup as u32,
    libc::SYS_io_uring_enter as u32,
    libc::SYS_io_setup as u32,
    libc::SYS_io_submit as u32,
    // Cross-fd content transfer — snapshot source/dest at entry.
    libc::SYS_sendfile as u32,
    libc::SYS_copy_file_range as u32,
];

const _: () = assert!(TRACED_SYSCALLS.len() <= u8::MAX as usize);

fn build_filter(guarded_descriptors: &[i32]) -> Vec<libc::sock_filter> {
    const AUDIT_ARCH_X86_64: u32 = 0xc000003e;
    const X32_SYSCALL_BIT: u32 = 0x40000000;
    const BPF_JSET: u16 = 0x40;
    let mut program = vec![
        statement(BPF_LD | BPF_W | BPF_ABS, 4), // seccomp_data.arch
        jump(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_X86_64, 1, 0),
        statement(BPF_RET | BPF_K, SECCOMP_RET_TRACE | 1),
        statement(BPF_LD | BPF_W | BPF_ABS, 0), // seccomp_data.nr
        jump(BPF_JMP | BPF_JSET | BPF_K, X32_SYSCALL_BIT, 0, 1),
        statement(BPF_RET | BPF_K, SECCOMP_RET_TRACE | 1),
    ];
    if !guarded_descriptors.is_empty() {
        for &number in crate::inherited::INDIRECT {
            program.push(jump(BPF_JMP | BPF_JEQ | BPF_K, number as u32, 0, 1));
            program.push(statement(BPF_RET | BPF_K, SECCOMP_RET_TRACE));
        }
        for &(number, arguments) in crate::inherited::FD_ARGUMENTS {
            let length = arguments.len() * (1 + 2 * guarded_descriptors.len()) + 1;
            assert!(length <= u8::MAX as usize);
            program.push(jump(
                BPF_JMP | BPF_JEQ | BPF_K,
                number as u32,
                0,
                length as u8,
            ));
            for &argument in arguments {
                program.push(statement(
                    BPF_LD | BPF_W | BPF_ABS,
                    16 + 8 * argument as u32,
                ));
                for &fd in guarded_descriptors {
                    program.push(jump(BPF_JMP | BPF_JEQ | BPF_K, fd as u32, 0, 1));
                    program.push(statement(BPF_RET | BPF_K, SECCOMP_RET_TRACE));
                }
            }
            program.push(if TRACED_SYSCALLS.contains(&(number as u32)) {
                statement(BPF_LD | BPF_W | BPF_ABS, 0)
            } else {
                // Ordinary read/write on unguarded descriptors needs no
                // further filesystem dispatch or ptrace stop.
                statement(BPF_RET | BPF_K, SECCOMP_RET_ALLOW)
            });
        }
    }
    for (index, &number) in TRACED_SYSCALLS.iter().enumerate() {
        let jump_to_trace = (TRACED_SYSCALLS.len() - index) as u8;
        program.push(jump(BPF_JMP | BPF_JEQ | BPF_K, number, jump_to_trace, 0));
    }
    program.push(statement(BPF_RET | BPF_K, SECCOMP_RET_ALLOW));
    program.push(statement(BPF_RET | BPF_K, SECCOMP_RET_TRACE));
    program
}

#[cfg(test)]
mod tests {
    use super::*;

    fn evaluate(program: &[libc::sock_filter], number: i64, arguments: [u64; 6]) -> u32 {
        let mut data = [0u8; 64];
        data[..4].copy_from_slice(&(number as u32).to_ne_bytes());
        data[4..8].copy_from_slice(&0xc000003eu32.to_ne_bytes());
        for (index, argument) in arguments.iter().enumerate() {
            data[16 + index * 8..24 + index * 8].copy_from_slice(&argument.to_ne_bytes());
        }
        let (mut pc, mut accumulator) = (0usize, 0u32);
        loop {
            let instruction = &program[pc];
            match instruction.code {
                code if code == BPF_LD | BPF_W | BPF_ABS => {
                    accumulator = u32::from_ne_bytes(
                        data[instruction.k as usize..instruction.k as usize + 4]
                            .try_into()
                            .unwrap(),
                    );
                }
                code if code == BPF_JMP | BPF_JEQ | BPF_K => {
                    pc += if accumulator == instruction.k {
                        instruction.jt
                    } else {
                        instruction.jf
                    } as usize;
                }
                code if code == BPF_JMP | 0x40 | BPF_K => {
                    pc += if accumulator & instruction.k != 0 {
                        instruction.jt
                    } else {
                        instruction.jf
                    } as usize;
                }
                code if code == BPF_RET | BPF_K => return instruction.k,
                _ => panic!("unexpected BPF opcode"),
            }
            pc += 1;
        }
    }

    #[test]
    fn descriptor_guards_preserve_the_bulk_io_fast_path() {
        let program = build_filter(&[3, 9]);
        for &(number, positions) in crate::inherited::FD_ARGUMENTS {
            for &position in positions {
                let mut arguments = [5; 6];
                arguments[position] = 3;
                assert_eq!(evaluate(&program, number, arguments), SECCOMP_RET_TRACE);
                arguments[position] = 9;
                assert_eq!(evaluate(&program, number, arguments), SECCOMP_RET_TRACE);
            }
            if !TRACED_SYSCALLS.contains(&(number as u32)) {
                assert_eq!(evaluate(&program, number, [5; 6]), SECCOMP_RET_ALLOW);
            }
        }
        for fd in [0, 1, 2, 4] {
            assert_eq!(
                evaluate(&program, libc::SYS_read, [fd, 0, 0, 0, 0, 0]),
                SECCOMP_RET_ALLOW
            );
        }
        for &number in crate::inherited::INDIRECT {
            assert_eq!(evaluate(&program, number, [0; 6]), SECCOMP_RET_TRACE);
        }
        assert!(build_filter(&(3..19).collect::<Vec<_>>()).len() < 4096);
    }
}
