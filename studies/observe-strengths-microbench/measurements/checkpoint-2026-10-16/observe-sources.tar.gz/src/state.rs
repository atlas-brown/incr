use crate::snapshot::Snapshot;
use nix::unistd::Pid;
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

use crate::syscall::SyscallEntry;

/// Pre-write state of a file, captured before the first modifying syscall.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum PreWrite {
    /// File did not exist before the write (e.g. O_CREAT on a new file).
    Nonexistent,
    /// File existed but could not be read/hashed from the tracer.
    Unreadable,
    /// xxh3 hash of the file's content before the first write.
    Hash(u64),
}

/// All mutable state for the tracer event loop.
pub struct TracerState {
    /// Currently live (traced) pids.
    pub live: HashSet<Pid>,
    /// Pids where we called ptrace::syscall() after a seccomp stop and are
    /// waiting for the syscall-exit stop.
    pub awaiting_exit: HashSet<Pid>,
    /// Last syscall-entry info per pid (needed at exit to know which syscall).
    pub last_enter: HashMap<Pid, SyscallEntry>,
    /// Set of file paths read by the tracee.
    pub read_paths: HashSet<PathBuf>,
    /// Set of file paths written by the tracee.
    pub write_paths: HashSet<PathBuf>,
    /// Whether to compute pre-write hashes (--hash flag).
    pub hash_writes: bool,
    /// Pre-write hashes for files that were written.
    /// Only populated when hash_writes is true.
    pub pre_hashes: HashMap<PathBuf, PreWrite>,
    /// (dev, ino) -> PreWrite for already-hashed inodes. Avoids re-hashing
    /// the same physical file and propagates the value to additional paths
    /// (hard links) that alias the same inode.
    pub inode_hashes: HashMap<(u64, u64), PreWrite>,

    pub snapshot: Snapshot,
    /// Include negative lookups, FIFO interactions and append preconditions for caching.
    pub dependencies: bool,
    pub directory_access_only: bool,
    pub record_content_opens: bool,
    pub content_opens: HashSet<PathBuf>,
    pub guarded_descriptors: Vec<i32>,
    pub replay_barriers: HashSet<String>,
    pub pre_reads: HashMap<PathBuf, crate::dependency::Dependency>,
    checked_parents: HashSet<PathBuf>,
    /// Successful truncations whose original contents were never observed.
    pub overwrites: HashSet<PathBuf>,
    content_dependencies: HashSet<PathBuf>,
    replacements_seen: bool,
}

impl TracerState {
    pub fn new(
        init: Pid,
        hash_writes: bool,
        snapshot_dir: Option<PathBuf>,
        filter_noisy: bool,
    ) -> Self {
        Self {
            guarded_descriptors: Vec::new(),
            replay_barriers: HashSet::new(),
            live: HashSet::from([init]),
            awaiting_exit: HashSet::new(),
            last_enter: HashMap::new(),
            read_paths: HashSet::new(),
            write_paths: HashSet::new(),
            hash_writes,
            pre_hashes: HashMap::new(),
            inode_hashes: HashMap::new(),
            snapshot: Snapshot::new(snapshot_dir, filter_noisy),
            dependencies: false,
            directory_access_only: false,
            record_content_opens: false,
            content_opens: HashSet::new(),
            pre_reads: HashMap::new(),
            checked_parents: HashSet::new(),
            overwrites: HashSet::new(),
            content_dependencies: HashSet::new(),
            replacements_seen: false,
        }
    }

    pub fn record_read(&mut self, path: PathBuf) {
        if !self.overwrites.contains(&path) {
            self.content_dependencies.insert(path.clone());
        }
        self.record_write_precondition(path);
    }

    /// Optional contract: a directory stat/access probe observes accessibility,
    /// not entry timestamps. Opening the directory still records its contents.
    pub fn record_metadata_read(&mut self, path: PathBuf) {
        if self.directory_access_only
            && self.dependencies
            && std::fs::symlink_metadata(&path).is_ok_and(|metadata| metadata.is_dir())
        {
            self.record_parent_dependencies(&path);
            self.pre_reads
                .entry(path.clone())
                .or_insert_with(|| crate::dependency::Dependency::capture_parent(&path));
            self.read_paths.insert(path);
        } else {
            self.record_read(path);
        }
    }

    /// A write's implicit precondition is distinct from an actual content/stat
    /// observation. Only the former can admit our own completed overwrite state.
    pub fn record_write_precondition(&mut self, path: PathBuf) {
        if self.dependencies {
            self.record_parent_dependencies(&path);
            let dependency = self
                .pre_reads
                .entry(path.clone())
                .or_insert_with(|| crate::dependency::Dependency::capture(&path));
            if matches!(
                dependency,
                crate::dependency::Dependency::ParentDirectory { .. }
            ) {
                *dependency = crate::dependency::Dependency::capture(&path);
            }
        }
        self.read_paths.insert(path);
    }

    pub fn record_overwrite(&mut self, path: &Path) {
        if !self.replacements_seen && !self.content_dependencies.contains(path) {
            self.overwrites.insert(path.to_owned());
        }
    }

    /// Entry replacement is not a plain overwrite, even if the same pathname is
    /// truncated later. Remain conservative for commands that combine the two.
    pub fn forbid_overwrite_reuse(&mut self) {
        self.replacements_seen = true;
        self.overwrites.clear();
    }

    /// Preserve traversal permissions and parent links, including linked targets.
    /// A leaf inode alone cannot detect changed access or a retargeted parent.
    fn record_parent_dependencies(&mut self, path: &Path) {
        let Some(parent) = path.parent() else { return };
        // Every visited node schedules its ancestors. Once a prior walk is
        // complete, seeing this parent again requires no path allocation/hash
        // work for the whole chain. Dependencies retain their first state.
        if self.checked_parents.contains(parent) {
            return;
        }
        let mut pending = vec![parent.to_owned()];
        let mut followed_links = 0;
        while let Some(parent) = pending.pop() {
            if !self.checked_parents.insert(parent.clone()) {
                continue;
            }
            // Walk only the new part of this chain. A seen node already had
            // its own ancestors scheduled by the walk that first visited it.
            if let Some(ancestor) = parent.parent() {
                pending.push(ancestor.to_owned());
            }
            let dependency = crate::dependency::Dependency::capture_parent(&parent);
            let target = match &dependency {
                crate::dependency::Dependency::Symlink { target, .. } => Some(target.clone()),
                _ => None,
            };
            self.pre_reads.entry(parent.clone()).or_insert(dependency);
            self.read_paths.insert(parent.clone());
            let Some(target) = target else {
                continue;
            };
            followed_links += 1;
            if followed_links > 40 {
                self.replay_barriers
                    .insert("too many parent symlinks".to_owned());
                return;
            }
            let resolved = if target.is_absolute() {
                target
            } else {
                parent.parent().unwrap_or(Path::new("/")).join(target)
            };
            pending.push(resolved);
        }
    }

    /// Keep the command live and mark its snapshot incomplete for effects we
    /// cannot reconstruct. A diagnostic is not a synthetic filesystem path.
    pub fn record_unsupported_effect(&mut self, reason: &str) {
        self.replay_barriers.insert(reason.to_owned());
        self.snapshot.invalidate(reason);
    }

    /// Remove all bookkeeping for a pid that has exited.
    pub fn remove_pid(&mut self, pid: Pid) {
        self.live.remove(&pid);
        self.awaiting_exit.remove(&pid);
        self.last_enter.remove(&pid);
    }
}

impl Drop for TracerState {
    fn drop(&mut self) {
        use nix::sys::signal::{Signal, kill};
        use nix::sys::wait::{WaitPidFlag, WaitStatus, waitpid};
        let deadline = std::time::Instant::now() + std::time::Duration::from_millis(250);
        while !self.live.is_empty() {
            self.live.retain(|&pid| {
                match waitpid(pid, Some(WaitPidFlag::__WALL | WaitPidFlag::WNOHANG)) {
                    Ok(WaitStatus::Exited(..) | WaitStatus::Signaled(..))
                    | Err(nix::errno::Errno::ECHILD) => false,
                    _ => {
                        let _ = kill(pid, Signal::SIGKILL);
                        true
                    }
                }
            });
            if std::time::Instant::now() >= deadline {
                break;
            }
            if !self.live.is_empty() {
                std::thread::sleep(std::time::Duration::from_millis(1));
            }
        }
    }
}

#[cfg(test)]
mod dependency_tests {
    use super::*;
    use crate::dependency::Dependency;
    use std::fs;
    use std::os::unix::fs::symlink;

    #[test]
    fn repeated_parent_walk_preserves_links_and_upgrades_direct_observations() {
        let root = std::env::temp_dir().join(format!(
            "observe-parents-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(root.join("real/deeper")).unwrap();
        symlink(root.join("real"), root.join("link")).unwrap();
        let mut state = TracerState::new(Pid::this(), false, None, false);
        // This is bookkeeping, not a traced child; Drop must not kill this PID.
        state.live.clear();
        state.dependencies = true;
        state.record_read(root.join("link/deeper/missing"));
        for parent in [
            root.clone(),
            root.join("link/deeper"),
            root.join("link"),
            root.join("real"),
        ] {
            assert!(
                state.pre_reads.contains_key(&parent),
                "missing ancestor {parent:?}"
            );
        }
        assert!(matches!(
            state.pre_reads[&root.join("link")],
            Dependency::Symlink { .. }
        ));
        assert!(matches!(
            state.pre_reads[&root.join("link/deeper")],
            Dependency::ParentDirectory { .. }
        ));
        let initial = state.pre_reads.len();
        state.record_read(root.join("link/deeper/other"));
        assert_eq!(state.pre_reads.len(), initial + 1);
        // Deduplicated traversal must not skip a directory's actual stat read.
        state.record_read(root.join("link/deeper"));
        assert!(matches!(
            state.pre_reads[&root.join("link/deeper")],
            Dependency::Directory { .. }
        ));
        fs::remove_dir_all(root).unwrap();
    }
}
